#!/usr/bin/env python3
# -*- coding: utf-8 -*-


import pandas as pd
import numpy as np
import statistics

def calculate_metrics_simple(sample_hit_details_csv, hallucination_excel):

    
    print("正在读取数据...")
    
    # 读取样本详情
    df = pd.read_csv(sample_hit_details_csv)
    print(f"✓ 读取样本详情: {len(df)} 个样本")

    hallucination_df = pd.read_excel(hallucination_excel) if hallucination_excel.endswith('.xlsx') else pd.read_csv(hallucination_excel)
    print(f"✓ 读取幻觉分类: {len(hallucination_df)} 个类别\n")
    
    print("="*100)
    print(f"{'幻觉类型':<15} {'数量':<8} {'TOP1':<10} {'TOP3':<10} {'TOP5':<10} {'TOP10':<10} {'IFA':<10} {'R@1%E':<12} {'E@20%R':<12}")
    print("="*100)
    
    results = []
    

    tp_df = df[df['sample_type'] == 'TP'].copy()
    

    for idx, row in hallucination_df.iterrows():
        h_type = row.iloc[0]  # 第一列是类别名
        count = row.iloc[1]   # 第二列是数量
        top1 = row.iloc[2] if len(row) > 2 else 0
        top3 = row.iloc[3] if len(row) > 3 else 0
        top5 = row.iloc[4] if len(row) > 4 else 0
        top10 = row.iloc[5] if len(row) > 5 else 0
        

        avg_lines = tp_df['total_lines'].mean() if len(tp_df) > 0 else 20
        
        # 估算IFA：未命中比例 * 平均行数
        estimated_ifa = (1 - top10) * avg_lines

        estimated_r_at_1e = top1 * 0.8
        if top5 >= 0.8:
            estimated_e_at_20r = 0.01  # 1%
        elif top10 >= 0.8:
            estimated_e_at_20r = 0.03  # 3%
        else:
            estimated_e_at_20r = 0.1   # 10%
        
        results.append({
            '幻觉类型': h_type,
            '数量': count,
            'TOP1': f"{top1:.3f}",
            'TOP3': f"{top3:.3f}",
            'TOP5': f"{top5:.3f}",
            'TOP10': f"{top10:.3f}",
            'IFA': f"{estimated_ifa:.2f}",
            'R@1%E': f"{estimated_r_at_1e:.6f}",
            'E@20%R': f"{estimated_e_at_20r:.6f}"
        })
        
        print(f"{h_type:<15} {count:<8} {top1:<10.3f} {top3:<10.3f} {top5:<10.3f} {top10:<10.3f} "
              f"{estimated_ifa:<10.2f} {estimated_r_at_1e:<12.6f} {estimated_e_at_20r:<12.6f}")
    
    print("="*100)
    
    # 保存结果
    results_df = pd.DataFrame(results)
    output_file = 'hallucination_metrics_results.csv'
    results_df.to_csv(output_file, index=False, encoding='utf-8-sig')
    print(f"\n✓ 结果已保存到: {output_file}")
    
    return results_df

def calculate_precise_metrics(sample_hit_details_csv, sample_to_hallucination_mapping_csv):
    
    print("="*100)
    print("精确计算模式")
    print("="*100)
    
    # 读取数据
    df = pd.read_csv(sample_hit_details_csv)
    mapping_df = pd.read_csv(sample_to_hallucination_mapping_csv)
    
    # 合并数据
    df = df.merge(mapping_df, on='sample_index', how='left')
    
    # 只统计TP样本
    tp_df = df[df['sample_type'] == 'TP'].copy()
    
    # 按幻觉类型分组
    hallucination_types = tp_df['hallucination_type'].unique()
    hallucination_types = [ht for ht in hallucination_types if pd.notna(ht)]
    
    results = []
    
    print(f"\n{'幻觉类型':<15} {'数量':<8} {'TOP1':<10} {'TOP3':<10} {'TOP5':<10} {'TOP10':<10} {'IFA':<10} {'R@1%E':<12} {'E@20%R':<12}")
    print("="*100)
    
    for h_type in hallucination_types:
        type_samples = tp_df[tp_df['hallucination_type'] == h_type]
        
        if len(type_samples) == 0:
            continue
        
        # 计算TOP-K准确率
        count = len(type_samples)
        top1_acc = type_samples['hit_at_top1'].sum() / count
        top3_acc = type_samples['hit_at_top3'].sum() / count
        top5_acc = type_samples['hit_at_top5'].sum() / count
        top10_acc = type_samples['hit_at_top10'].sum() / count
        
        # 计算IFA（平均首次找到漏洞的位置）
        valid_ranks = type_samples[type_samples['min_rank'] > 0]['min_rank']
        ifa = valid_ranks.mean() - 1 if len(valid_ranks) > 0 else -1
        
        # 计算R@1%E
        total_lines = type_samples['total_lines'].sum()
        budget = int(total_lines * 0.01)
        
        # 按min_rank排序
        sorted_samples = type_samples.sort_values('min_rank')
        checked = 0
        found = 0
        for idx, row in sorted_samples.iterrows():
            if row['min_rank'] > 0:
                checked += row['min_rank']
                if checked <= budget:
                    found += 1
        
        r_at_1e = found / count if count > 0 else 0
        
        # 计算E@20%R
        target_found = int(count * 0.2)
        checked = 0
        found = 0
        for idx, row in sorted_samples.iterrows():
            if row['min_rank'] > 0:
                checked += row['min_rank']
                found += 1
            else:
                checked += row['total_lines']
            
            if found >= target_found:
                break
        
        e_at_20r = checked / total_lines if total_lines > 0 else 1.0
        
        results.append({
            '幻觉类型': h_type,
            '数量': count,
            'TOP1': f"{top1_acc:.3f}",
            'TOP3': f"{top3_acc:.3f}",
            'TOP5': f"{top5_acc:.3f}",
            'TOP10': f"{top10_acc:.3f}",
            'IFA': f"{ifa:.2f}",
            'R@1%E': f"{r_at_1e:.6f}",
            'E@20%R': f"{e_at_20r:.6f}"
        })
        
        print(f"{h_type:<15} {count:<8} {top1_acc:<10.3f} {top3_acc:<10.3f} {top5_acc:<10.3f} {top10_acc:<10.3f} "
              f"{ifa:<10.2f} {r_at_1e:<12.6f} {e_at_20r:<12.6f}")
    
    print("="*100)
    
    # 保存结果
    results_df = pd.DataFrame(results)
    output_file = 'hallucination_metrics_precise.csv'
    results_df.to_csv(output_file, index=False, encoding='utf-8-sig')
    print(f"\n✓ 精确结果已保存到: {output_file}")
    
    return results_df

def main():
    """主函数"""
    import sys
    
    print("""
╔══════════════════════════════════════════════════════════════════╗
║        幻觉类型指标计算工具                                        ║
║        计算 IFA、R@1%E、E@20%R                                    ║
╚══════════════════════════════════════════════════════════════════╝
    """)
    
    print("请选择计算模式:")
    print("  1. 简化模式 - 使用Excel表格的TOP-K准确率估算")
    print("  2. 精确模式 - 使用样本到幻觉类型的映射精确计算")
    print()
    
    mode = input("请输入模式 (1/2): ").strip()
    
    if mode == '1':
        print("\n=== 简化模式 ===")
        sample_csv = input("请输入样本命中详情CSV文件路径: ").strip()
        excel_file = input("请输入幻觉分类Excel/CSV文件路径: ").strip()
        
        calculate_metrics_simple(sample_csv, excel_file)
        
    elif mode == '2':
        print("\n=== 精确模式 ===")
        sample_csv = input("请输入样本命中详情CSV文件路径: ").strip()
        mapping_csv = input("请输入样本-幻觉类型映射CSV文件路径: ").strip()
        
        calculate_precise_metrics(sample_csv, mapping_csv)
    
    else:
        print("无效的选择！")
        sys.exit(1)

if __name__ == "__main__":
    main()

