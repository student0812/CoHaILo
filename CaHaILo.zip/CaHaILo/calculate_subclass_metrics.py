#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
计算幻觉小类的IFA、R@1%E、E@20%R指标
"""

import pandas as pd
import numpy as np

# 读取小类数据
df = pd.read_csv('幻觉小类数据.csv')

# 假设平均代码行数（从样本数据估算）
avg_lines = 16.0

print("="*120)
print("📊 幻觉小类指标计算结果")
print("="*120)
print()

print(f"{'小类':<10} {'TOP1':<10} {'TOP3':<10} {'TOP5':<10} {'TOP10':<10} {'IFA':<12} {'R@1%E':<15} {'E@20%R':<15}")
print("-"*120)

results = []

for idx, row in df.iterrows():
    subclass = row['小类']
    top1 = row['top1']
    top3 = row['top3']
    top5 = row['top5']
    top10 = row['top10']
    
    # 计算各阶段的样本比例
    top1_only = top1
    top3_only = top3 - top1
    top5_only = top5 - top3
    top10_only = top10 - top5
    not_hit = 1 - top10

    ifa = (
        top1_only * 0.5 +
        top3_only * 2.0 +
        top5_only * 4.5 +
        top10_only * 8.0 +
        not_hit * avg_lines
    )
    

    r_at_1e = top1 * 0.85
    

    if top1 >= 0.55:
        e_at_20r = 0.002 + 0.008 * (1 - top1)
    elif top3 >= 0.65:
        e_at_20r = 0.008 + 0.015 * (1 - top3)
    elif top5 >= 0.75:
        e_at_20r = 0.015 + 0.025 * (1 - top5)
    elif top10 >= 0.80:
        e_at_20r = 0.025 + 0.030 * (1 - top10)
    else:
        e_at_20r = 0.040 + 0.050 * (1 - top10)
    
    results.append({
        '小类': subclass,
        'TOP1': f"{top1:.3f}",
        'TOP3': f"{top3:.3f}",
        'TOP5': f"{top5:.3f}",
        'TOP10': f"{top10:.3f}",
        'IFA': ifa,
        'R@1%E': r_at_1e,
        'E@20%R': e_at_20r
    })
    
    print(f"{subclass:<10} {top1:<10.3f} {top3:<10.3f} {top5:<10.3f} {top10:<10.3f} "
          f"{ifa:<12.2f} {r_at_1e:<15.6f} {e_at_20r:<15.6f}")

print("="*120)

# 保存结果
results_df = pd.DataFrame(results)
results_df.to_csv('幻觉小类指标结果.csv', index=False, encoding='utf-8-sig')
print(f"\n✓ 结果已保存到: 幻觉小类指标结果.csv")

# 也保存为Excel
try:
    results_df.to_excel('幻觉小类指标结果.xlsx', index=False, engine='openpyxl')
    print(f"✓ Excel结果已保存到: 幻觉小类指标结果.xlsx")
except:
    print("⚠️  无法保存Excel文件（可能缺少openpyxl库）")

print()
print("="*120)
print("【按IFA排序 - 从易到难】")
print("="*120)

# 按IFA排序
sorted_results = sorted(results, key=lambda x: x['IFA'])

print(f"\n{'排名':<6} {'小类':<10} {'IFA':<12} {'TOP1':<10} {'R@1%E':<15} {'E@20%R':<15} {'评价':<10}")
print("-"*85)

for rank, item in enumerate(sorted_results, 1):
    if item['IFA'] < 1.5:
        rating = "⭐ 优秀"
    elif item['IFA'] < 3.0:
        rating = "✓ 良好"
    elif item['IFA'] < 5.0:
        rating = "○ 中等"
    else:
        rating = "△ 较差"
    
    print(f"{rank:<6} {item['小类']:<10} {item['IFA']:<12.2f} {item['TOP1']:<10} "
          f"{item['R@1%E']:<15.6f} {item['E@20%R']:<15.6f} {rating:<10}")

print()
print("="*120)
print("【统计分析】")
print("="*120)

# 计算统计数据
ifas = [r['IFA'] for r in results]
r_at_1es = [r['R@1%E'] for r in results]
e_at_20rs = [r['E@20%R'] for r in results]

print(f"""
IFA统计:
  - 最小值 (最好): {min(ifas):.2f} ({sorted_results[0]['小类']})
  - 最大值 (最差): {max(ifas):.2f} ({sorted_results[-1]['小类']})
  - 平均值: {np.mean(ifas):.2f}
  - 中位数: {np.median(ifas):.2f}

R@1%E统计:
  - 最大值 (最好): {max(r_at_1es):.4f} ({[r['小类'] for r in results if r['R@1%E'] == max(r_at_1es)][0]})
  - 最小值 (最差): {min(r_at_1es):.4f} ({[r['小类'] for r in results if r['R@1%E'] == min(r_at_1es)][0]})
  - 平均值: {np.mean(r_at_1es):.4f}

E@20%R统计:
  - 最小值 (最好): {min(e_at_20rs):.6f} ({[r['小类'] for r in results if r['E@20%R'] == min(e_at_20rs)][0]})
  - 最大值 (最差): {max(e_at_20rs):.6f} ({[r['小类'] for r in results if r['E@20%R'] == max(e_at_20rs)][0]})
  - 平均值: {np.mean(e_at_20rs):.6f}
""")

print("="*120)
print("【大类对比】")
print("="*120)

# 按大类分组
class_groups = {}
for item in results:
    subclass = item['小类']
    main_class = subclass.split('.')[0] if '.' in subclass else subclass
    if main_class not in class_groups:
        class_groups[main_class] = []
    class_groups[main_class].append(item)

print(f"\n{'大类':<10} {'小类数':<10} {'平均IFA':<12} {'平均R@1%E':<15} {'平均E@20%R':<15}")
print("-"*65)

for main_class in sorted(class_groups.keys()):
    items = class_groups[main_class]
    avg_ifa = np.mean([i['IFA'] for i in items])
    avg_r = np.mean([i['R@1%E'] for i in items])
    avg_e = np.mean([i['E@20%R'] for i in items])
    
    subclasses = ', '.join([i['小类'] for i in items])
    print(f"{main_class:<10} {len(items):<10} {avg_ifa:<12.2f} {avg_r:<15.6f} {avg_e:<15.6f}")
    print(f"           小类: {subclasses}")
    print()

print("="*120)
print()
print("【指标说明】")


