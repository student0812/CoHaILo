#!/usr/bin/env python3
# -*- coding: utf-8 -*-


import pandas as pd
import numpy as np
import statistics
import sys

def calculate_ifa(samples_df):

    ifa_values = []
    
    for idx, row in samples_df.iterrows():
        # 只统计TP样本
        if row['sample_type'] != 'TP':
            continue
        
        # 使用min_rank作为IFA值
        # min_rank表示真实漏洞行在预测排序中的最小排名
        min_rank = row['min_rank']
        
        if min_rank > 0:
            # 排名从1开始，IFA需要减1（变成索引）
            ifa_values.append(min_rank - 1)
    
    if len(ifa_values) > 0:
        return sum(ifa_values) / len(ifa_values)
    else:
        return 0.0

def calculate_recall_at_effort(samples_df, effort_percentage=0.01):
    tp_samples = samples_df[samples_df['sample_type'] == 'TP'].copy()
    
    if len(tp_samples) == 0:
        return 0.0
    
    # 计算总代码行数和总漏洞行数
    total_lines = tp_samples['total_lines'].sum()
    total_flaw_lines = len(tp_samples)  # 假设每个样本有1个漏洞行（简化）
    
    # 计算预算内可以检查的行数
    target_lines = int(total_lines * effort_percentage)
    
    # 按min_rank排序（从小到大，优先检查排名高的）
    tp_samples_sorted = tp_samples.sort_values('min_rank')
    
    checked_lines = 0
    found_flaws = 0
    
    for idx, row in tp_samples_sorted.iterrows():
        # 如果该样本的漏洞被找到（min_rank > 0），检查到该行就算找到
        if row['min_rank'] > 0:
            checked_lines += row['min_rank']
            if checked_lines <= target_lines:
                found_flaws += 1
            else:
                break
        else:
            # 未找到的样本，需要检查所有行
            checked_lines += row['total_lines']
    
    if total_flaw_lines > 0:
        return round(found_flaws / total_flaw_lines, 6)
    else:
        return 0.0

def calculate_effort_at_recall(samples_df, recall_target=0.2):

    tp_samples = samples_df[samples_df['sample_type'] == 'TP'].copy()
    
    if len(tp_samples) == 0:
        return 1.0
    
    # 计算总代码行数和目标漏洞数
    total_lines = tp_samples['total_lines'].sum()
    target_flaws = int(len(tp_samples) * recall_target)
    
    # 按min_rank排序（从小到大）
    tp_samples_sorted = tp_samples.sort_values('min_rank')
    
    checked_lines = 0
    found_flaws = 0
    
    for idx, row in tp_samples_sorted.iterrows():
        if row['min_rank'] > 0:
            checked_lines += row['min_rank']
            found_flaws += 1
        else:
            # 未找到的样本，需要检查所有行
            checked_lines += row['total_lines']
        
        # 达到目标召回率
        if found_flaws >= target_flaws:
            if total_lines > 0:
                return round(checked_lines / total_lines, 6)
            else:
                return 1.0
    
    return 1.0

def analyze_by_hallucination_type(csv_file, hallucination_mapping_file=None):

    print(f"正在读取数据: {csv_file}\n")
    df = pd.read_csv(csv_file)
    
    print("="*80)
    print("📊 按幻觉类型计算IFA、R@1%E、E@20%R指标")
    print("="*80)
    
    # 如果提供了幻觉类型映射文件
    if hallucination_mapping_file and pd.io.common.file_exists(hallucination_mapping_file):
        print(f"\n正在读取幻觉类型映射: {hallucination_mapping_file}")
        mapping_df = pd.read_csv(hallucination_mapping_file)
        # 合并数据
        df = df.merge(mapping_df[['sample_index', 'hallucination_type']], 
                     on='sample_index', how='left')
        
        # 按幻觉类型分组
        hallucination_types = df['hallucination_type'].unique()
        hallucination_types = [ht for ht in hallucination_types if pd.notna(ht)]
        
    else:
        print("\n⚠️  未提供幻觉类型映射文件，将提示你手动输入")
        print("请准备一个CSV文件，包含两列：sample_index, hallucination_type")
        print(f"示例格式：")
        print("sample_index,hallucination_type")
        print("2,第1类")
        print("4,第2类")
        print("7,第1类")
        print("...")
        
        # 如果没有映射文件，提供交互式输入
        response = input("\n是否要现在创建映射文件？(y/n): ")
        if response.lower() == 'y':
            create_hallucination_mapping_template(df, 'hallucination_mapping_template.csv')
            print("\n✓ 已创建模板文件: hallucination_mapping_template.csv")
            print("请编辑此文件，为每个样本分配幻觉类型，然后重新运行此脚本")
            return
        else:
            # 创建一个通用分组（所有样本一组）
            df['hallucination_type'] = '所有样本'
            hallucination_types = ['所有样本']
    
    # 计算每个幻觉类型的指标
    results = []
    
    print(f"\n{'='*80}")
    print(f"{'幻觉类型':<20} {'样本数':<10} {'IFA':<15} {'R@1%E':<15} {'E@20%R':<15}")
    print(f"{'='*80}")
    
    for h_type in hallucination_types:
        # 筛选该幻觉类型的样本
        type_samples = df[df['hallucination_type'] == h_type]
        
        if len(type_samples) == 0:
            continue
        
        # 计算指标
        ifa = calculate_ifa(type_samples)
        r_at_1e = calculate_recall_at_effort(type_samples, 0.01)
        e_at_20r = calculate_effort_at_recall(type_samples, 0.2)
        
        results.append({
            '幻觉类型': h_type,
            '样本数': len(type_samples),
            'IFA': round(ifa, 2),
            'R@1%E': r_at_1e,
            'E@20%R': e_at_20r
        })
        
        print(f"{h_type:<20} {len(type_samples):<10} {ifa:<15.2f} {r_at_1e:<15.6f} {e_at_20r:<15.6f}")
    
    print(f"{'='*80}\n")
    
    # 计算总体指标
    print(f"{'='*80}")
    print("📈 总体指标")
    print(f"{'='*80}")
    
    overall_ifa = calculate_ifa(df)
    overall_r_at_1e = calculate_recall_at_effort(df, 0.01)
    overall_e_at_20r = calculate_effort_at_recall(df, 0.2)
    
    print(f"总样本数: {len(df)}")
    print(f"IFA (Initial False Alarm): {overall_ifa:.2f}")
    print(f"R@1%E (Recall at 1% Effort): {overall_r_at_1e:.6f}")
    print(f"E@20%R (Effort at 20% Recall): {overall_e_at_20r:.6f}")
    
    # 保存结果
    results_df = pd.DataFrame(results)
    output_file = csv_file.replace('.csv', '_hallucination_metrics.csv')
    results_df.to_csv(output_file, index=False, encoding='utf-8')
    print(f"\n✓ 结果已保存到: {output_file}")
    
    return results_df

def create_hallucination_mapping_template(df, output_file):
    """
    创建幻觉类型映射模板
    """
    # 只包含TP样本
    tp_samples = df[df['sample_type'] == 'TP'][['sample_index']].copy()
    tp_samples['hallucination_type'] = ''  # 空白，待填写
    
    tp_samples.to_csv(output_file, index=False, encoding='utf-8')
    print(f"\n已创建模板文件: {output_file}")
    print(f"包含 {len(tp_samples)} 个TP样本")

def main():
    """主函数"""
    if len(sys.argv) < 2:
        print("用法:")
        print("  python calculate_hallucination_metrics.py <样本命中详情CSV文件> [幻觉类型映射CSV文件]")
        print("\n示例:")
        print("  python calculate_hallucination_metrics.py codebert_plain_sample_hit_details_00.csv")
        print("  python calculate_hallucination_metrics.py codebert_plain_sample_hit_details_00.csv hallucination_mapping.csv")
        print("\n幻觉类型映射文件格式:")
        print("  sample_index,hallucination_type")
        print("  2,第1类")
        print("  4,第2类")
        print("  ...")
        sys.exit(1)
    
    csv_file = sys.argv[1]
    hallucination_mapping_file = sys.argv[2] if len(sys.argv) > 2 else None
    
    analyze_by_hallucination_type(csv_file, hallucination_mapping_file)

if __name__ == "__main__":
    main()



