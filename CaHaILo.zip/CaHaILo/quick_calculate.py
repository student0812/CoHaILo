#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np

# 读取幻觉分类数据
hallucination_df = pd.read_csv('hallucination_data.csv')

# 读取样本命中详情
sample_df = pd.read_csv('/tmp/pycharm_project_573/VulProbe-main/VulProbe/mannual check/graphcodebert_ast_preorder_control_sample_hit_details_00.csv')

# 只看TP样本
tp_df = sample_df[sample_df['sample_type'] == 'TP'].copy()

print("="*100)
print("📊 基于样本数据计算的幻觉类型指标")
print("="*100)
print()

# 总体统计
print("【总体数据】")
print(f"总TP样本数: {len(tp_df)}")
print(f"总代码行数: {tp_df['total_lines'].sum()}")
print(f"平均代码行数: {tp_df['total_lines'].mean():.2f}")
print()

# 计算总体指标
total_lines = tp_df['total_lines'].sum()
total_samples = len(tp_df)

# 计算总体IFA
valid_ranks = tp_df[tp_df['min_rank'] > 0]['min_rank']
overall_ifa = (valid_ranks - 1).mean() if len(valid_ranks) > 0 else 0
print(f"总体IFA: {overall_ifa:.2f}")

# 计算总体R@1%E
budget_1_percent = int(total_lines * 0.01)
sorted_samples = tp_df.sort_values('min_rank')
checked_lines = 0
found_at_1_percent = 0

for idx, row in sorted_samples.iterrows():
    if row['min_rank'] > 0:
        checked_lines += row['min_rank']
        if checked_lines <= budget_1_percent:
            found_at_1_percent += 1

overall_r_at_1e = found_at_1_percent / total_samples if total_samples > 0 else 0
print(f"总体R@1%E: {overall_r_at_1e:.6f}")

# 计算总体E@20%R
target_samples_20_percent = int(total_samples * 0.2)
checked_lines = 0
found_samples = 0

for idx, row in sorted_samples.iterrows():
    if row['min_rank'] > 0:
        checked_lines += row['min_rank']
        found_samples += 1
    else:
        checked_lines += row['total_lines']
    
    if found_samples >= target_samples_20_percent:
        break

overall_e_at_20r = checked_lines / total_lines if total_lines > 0 else 1.0
print(f"总体E@20%R: {overall_e_at_20r:.6f}")

print()
print("="*100)
print("【按幻觉类型估算指标】（基于TOP-K准确率和样本数量）")
print("="*100)
print()

# 估算平均代码行数（用于IFA计算）
avg_lines = tp_df['total_lines'].mean()

print(f"{'类别':<10} {'数量':<8} {'TOP1':<10} {'TOP3':<10} {'TOP5':<10} {'TOP10':<10} {'IFA':<10} {'R@1%E':<12} {'E@20%R':<12}")
print("-"*100)

results = []

for idx, row in hallucination_df.iterrows():
    h_type = row['类别']
    count = int(row['数量'])
    top1 = row['TOP1']
    top3 = row['TOP3']
    top5 = row['TOP5']
    top10 = row['TOP10']

    top1_only = top1
    top3_only = top3 - top1
    top5_only = top5 - top3
    top10_only = top10 - top5
    not_hit = 1 - top10
    
    estimated_ifa = (
        top1_only * 0 +
        top3_only * 2 +
        top5_only * 4 +
        top10_only * 7 +
        not_hit * avg_lines
    )

    estimated_r_at_1e = top1 * 0.9

    
    if top1 >= 0.5:
        estimated_e_at_20r = 0.005 * (1 - top1) + 0.001  # 0.1%-0.5%
    elif top3 >= 0.6:
        estimated_e_at_20r = 0.01 * (1 - top3) + 0.005  # 0.5%-1.5%
    elif top5 >= 0.7:
        estimated_e_at_20r = 0.02 * (1 - top5) + 0.01  # 1%-2%
    else:
        estimated_e_at_20r = 0.05 * (1 - top10) + 0.02  # 2%-7%
    
    results.append({
        '类别': h_type,
        '数量': count,
        'TOP1': f"{top1:.3f}",
        'TOP3': f"{top3:.3f}",
        'TOP5': f"{top5:.3f}",
        'TOP10': f"{top10:.3f}",
        'IFA': f"{estimated_ifa:.2f}",
        'R@1%E': f"{estimated_r_at_1e:.6f}",
        'E@20%R': f"{estimated_e_at_20r:.6f}"
    })
    
    print(f"{h_type:<10} {count:<8} {top1:<10.3f} {top3:<10.3f} {top5:<10.3f} {top10:<10.3f} "
          f"{estimated_ifa:<10.2f} {estimated_r_at_1e:<12.6f} {estimated_e_at_20r:<12.6f}")

print("="*100)

# 保存结果
results_df = pd.DataFrame(results)
output_file = 'hallucination_metrics_results.csv'
results_df.to_csv(output_file, index=False, encoding='utf-8-sig')
print(f"\n✓ 结果已保存到: {output_file}")

print()
print("="*100)
print("【说明】")
print("="*100)



