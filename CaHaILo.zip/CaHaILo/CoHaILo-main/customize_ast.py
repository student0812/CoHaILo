# import os
# from datetime import datetime
#
# def main():
#     first_step_model_type = 'codebert'
#     # ['codebert', 'mlp', 'bilstm', 'unixcoder']:
#     # name = '00'
#     for name in ['00', '11', '22', '33', '44']:
#     # for name in ['00']:
#         first_step_model = f'model_{name}.bin'#model_{name}.bin 是保存的模型文件名
#         probe_model = f'{first_step_model_type}_c_128_model_{name}_probe_42'
#     #指定显卡与批量大小
#         device = '0'
#         batch_size = 1
#         command = f"CUDA_VISIBLE_DEVICES={device} python src/main.py --customize --probe_name {probe_model} " \
#                 f"--first_step_model {first_step_model}  " \
#                 f"--first_step_model_type {first_step_model_type} " \
#                 f"--batch_size {batch_size} " \
#                 f"--hidden 64"
#
#  #构建用于执行的命令字符串：
# #--customize: 表示执行自定义推理流程（非训练模式）
# #--probe_name: 指定探针模型的名称
# #--first_step_model: 初始模型权重文件
# #--first_step_model_type: 模型架构类型（如 codebert）
# #--batch_size: 批量大小
# #--hidden: 指定隐藏层维度（通常用于自定义的 MLP/BiLSTM 等结构）
#
#         print(command)
#         os.system(command)
#
# if __name__ == '__main__':
#     main()
#这段代码的作用是加载一个预训练的 CodeBERT 模型，执行一次自定义任务（如微调或探针训练），并自动运行模型主逻辑
import os
from datetime import datetime

def main():
    first_step_model_type = 'codet5'#codebert
    for name in ['00', '11', '22', '33', '44']:
        first_step_model = f'model_{name}.bin'
        probe_model = f'{first_step_model_type}_python_128_model_{name}_probe_42'
        device = '0'
        batch_size = 1
        command = (
            #f"CUDA_VISIBLE_DEVICES={device} python src/main.py "
            f"CUDA_VISIBLE_DEVICES={device} python -m src.main "
            f"--customize "
            f"--probe_name {probe_model} "
            f"--first_step_model {first_step_model} "
            f"--first_step_model_type {first_step_model_type} "
            f"--batch_size {batch_size} "
            f"--hidden 768"
        )
        print(command)
        os.system(command)
        # 只执行第一轮后跳出
        break

if __name__ == '__main__':
    main()
