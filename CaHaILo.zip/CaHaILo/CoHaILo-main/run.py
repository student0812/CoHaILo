import os
from datetime import datetime

def main():
    now = datetime.now()
    month_day = now.strftime("%m%d")

    # CodeBERT
    for lang in ['python']:
        model_seed = '00'
        first_step_model = f"model_{model_seed}.bin"
        #first_step_model_type = "codebert""unixcoder"--do_train--rank 128 --lr 1e-4 --epochs 100
        first_step_model_type = "codet5"
        device = '3'
        seed = '42'
        probe_name = '_'.join(['codet5', lang, '128', 'model', model_seed, 'probe', seed])#codebert
        #打印将要运行的命令（便于调试）
        print(f"python -m src.main --do_train --probe_name {probe_name} "
        #print(f"CUDA_VISIBLE_DEVICES={device} python src/main.py --do_train --probe_name {probe_name} "
                    f"--lang {lang} --first_step_model {first_step_model} "
                    f" --first_step_model_type {first_step_model_type} --rank 128 --lr 1e-4 --epochs 100 --seed {seed}")
        #通过 os.system() 实际调用训练脚本 src/main.py，并传递训练参数：
        os.system(f"python -m src.main --do_train --probe_name {probe_name} "
        #os.system(f"CUDA_VISIBLE_DEVICES={device} python src/main.py --do_train --probe_name {probe_name} "
                    f"--lang {lang} --first_step_model {first_step_model} "
                    f" --first_step_model_type {first_step_model_type} --rank 128 --lr 1e-4 --epochs 100 --seed {seed}")



if __name__ == '__main__':
    main()


