import os
import re
import statistics
import sys
import json
import logging
import argparse
import traceback

import pandas as pd
import numpy as np
from datetime import datetime
from sklearn.metrics import accuracy_score, recall_score, precision_score, f1_score
from itertools import chain
from tqdm import tqdm
from tree_sitter import Parser, Language
from datasets import load_dataset
from datasets import Dataset

# 不再需要ProgramArguments和HfArgumentParser
# from .args import ProgramArguments  
# from transformers import HfArgumentParser

logger = logging.getLogger(__name__)
#主要目的是评估模型对源代码中漏洞行的解释能力
#对模型预测的每行代码分配"可疑分数"，按分数排序，输出排名结果
#lines_result：包含函数行级得分的 DataFrame
#test_set：测试集中每个函数对应的真实缺陷行信息
#它会使用模型输出的"解释结果"（如 codebert_ast_probe_explaination_00.csv），
# 对其中的信息进行分析，从而生成一系列关键指标，衡量解释的质量
def rank_lines(lines_result, test_set):
    """
test_result（注意：未在函数参数中传入，应当是外部变量）是一个包含预测结果的 DataFrame。
tp_list：筛选出真实标签是 1（有漏洞）并且预测也是 True 的样本（即 True Positive）的索引。
fp_list：筛选出真实标签是 0（无漏洞）但预测为 True 的样本（即 False Positive）的索引。
    """
    tp_list = test_result[test_result.apply(lambda x: x['label'] == 1 and x['pred'] == True, axis=1)].index.tolist()
    fp_list = test_result[test_result.apply(lambda x: x['label'] == 0 and x['pred'] == True, axis=1)].index.tolist()

    func_idx = []#记录函数的索引编号。
    line_score = []#每行代码的得分
    is_vul = []#每行是否真实是漏洞（1 表示是，0 表示不是）
    flaw_line_idxs = []#每个函数中真实漏洞所在的行索引列表
    for row_idx, term in lines_result.iterrows():
        """
遍历 lines_result 的每一行，每一行代表一个函数的预测结果。
row_idx: 当前函数的索引。
term: 当前行的所有数据（Series）。
        """
        #只处理预测为正（TP 或 FP）的函数
        actual_index = term['index']  # 使用实际的样本索引
        if actual_index in tp_list or actual_index in fp_list:
            #获取当前函数真实的漏洞行索引（可能是列表或字符串形式）
            flaw_line_idx = test_set['flaw_line_index'][actual_index]  # 使用actual_index
            #revision() 函数对索引进行修正（如去重、排序、标准化等）——需要 args 参数（未传入，应当检查作用域）
            flaw_line_idx = revision(args, actual_index, flaw_line_idx)  # 使用actual_index
            #遍历当前函数中每行代码的得分
            for idx, score in enumerate(eval(term['lines_score'])):
                # line_statistic[idx] = score
                #记录当前函数的编号、该行的得分，以及真实缺陷行索引列表。
                func_idx.append(actual_index)  # 使用actual_index
                line_score.append(score)
                flaw_line_idxs.append(str(flaw_line_idx))
                #判断该行是否为真实漏洞行
                if idx in [int(x) for x in flaw_line_idx]:
                    is_vul.append(1)
                else:
                    is_vul.append(0)
      #构造 DataFrame 存储行级信息
    df = pd.DataFrame({'func_idx': func_idx, 'line_score': line_score, 'is_vul': is_vul, 'flaw_line_index': flaw_line_idxs})
    #将未排序的行级得分信息保存为 CSV 文件（用于后续分析）
    # 获取输出目录
    output_dir = 'VulProbe/src/study'

    # 如果目录不存在，则创建目录
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    # 保存数据框到 CSV 文件
    df.to_csv(os.path.join(output_dir, 'no_rank.csv'), index=False)
    #df.to_csv('VulProbe/src/study/no_rank.csv', index=False)
    #按得分降序排序并保存
    df = df.sort_values(by=['line_score'], ascending=False).reset_index(drop=True)
    df.to_csv('VulProbe/src/study/ranked.csv', index=False)
    
    return df
#在固定预算下发现了多少漏洞
def get_recall(lines_result, test_set, top_k_loc, flaw_line_total_num, line_total_num):
    ranked_df = rank_lines(lines_result, test_set)
    
    target_line_num = line_total_num * top_k_loc
    checked_line_num = 0
    correct_predicted_line_num = 0
    for idx, term in ranked_df.iterrows():
        checked_line_num += 1
        if term['is_vul'] == 1:
            correct_predicted_line_num += 1
        if checked_line_num >= target_line_num:
            return round(correct_predicted_line_num / flaw_line_total_num, 6)
    return 0

#为了发现一定比例的漏洞行，需要看多少比例的代码行
def get_effort(lines_result, test_set, top_k_loc, flaw_line_total_num, line_total_num):
    ranked_df = rank_lines(lines_result, test_set)#获取行级信息，对每行代码排序
    
    target_flaw_line_num = flaw_line_total_num * top_k_loc
    checked_line_num = 0#已检测的代码行
    correct_predicted_line_num = 0#正确预测为漏洞的行数
    for idx, term in ranked_df.iterrows():#遍历排序后的每一行（从高分到低分）
        checked_line_num += 1
        if term['is_vul'] == 1:
            correct_predicted_line_num += 1
        if correct_predicted_line_num >= target_flaw_line_num:
            return round(checked_line_num / line_total_num, 6)#当检查行数达到预算 target_line_num 后，返回召回率（预测出的真实漏洞数 / 总真实漏洞数）
    return 1
    

def check(ground_flaw_lines, pred_flaw_lines):
    """
    改进的check函数：检查真实漏洞行是否在预测的top-k行中
    增加更宽松的匹配条件
    """
    # 如果真实漏洞行为空，返回False
    if not ground_flaw_lines:
        return False
    
    # 检查是否有任何真实漏洞行在预测的top-k行中
    for term in ground_flaw_lines:
        if term in pred_flaw_lines:
            return True
    
    # 如果没有找到完全匹配，尝试范围匹配
    # 如果预测行包含在真实漏洞行的范围内，也算匹配
    for term in ground_flaw_lines:
        for pred in pred_flaw_lines:
            # 如果预测行在真实漏洞行的±1范围内，也算匹配
            if abs(term - pred) <= 1:
                return True
    
    return False
    
 #定义函数，用于删除 C 语言代码中的注释。注释来源于 StackOverflow 的正则表达式技巧
def remove_comments_and_docstrings_c(string):
    """Source: https://stackoverflow.com/questions/2319019/using-regex-to-remove-comments-from-source-files"""
    #匹配双引号或单引号中的字符串，匹配多行注释和单行注释
    pattern = r"(\".*?\"|\'.*?\')|(/\*.*?\*/|//[^\r\n]*$)"
    # first group captures quoted strings (double or single)
    # second group captures comments (//single-line or /* multi-line */)
    regex = re.compile(pattern, re.MULTILINE | re.DOTALL)#编译正则表达式，re.MULTILINE 支持多行模式，re.DOTALL 允许 . 匹配换行符
#定义一个内部函数，用于替换正则匹配到的内容
    def _replacer(match):
        # if the 2nd group (capturing comments) is not None,
        # it means we have captured a non-quoted (real) comment string.
        if match.group(2) is not None:#如果匹配的是注释（即第二个分组），就删除它
            return ""  # so we will return empty to remove the comment
        else:  # otherwise, we will return the 1st group
            return match.group(1)  # captured quoted-string

    return regex.sub(_replacer, string)#用 _replacer 函数替换原始代码字符串中的注释内容，返回清理后的代码。
#重计算漏洞行索引 revision
def revision(args, idx, flaw_line_idx):
    """
    改进的revision函数：增加容错性和智能匹配
    """
    # 直接返回原始索引，不做任何处理
    if isinstance(flaw_line_idx, str):
        try:
            parsed = eval(flaw_line_idx)
            if parsed:  # 如果解析成功且不为空，直接返回
                return parsed
        except:
            pass
    
    # 如果原始索引为空或无效，尝试从flaw_line字段生成索引
    try:
        flaw_line = test_set.iloc[idx]['flaw_line']
        if flaw_line and flaw_line.strip():
            # 获取代码内容
            if 'func_before' in test_set.columns:
                func = test_set.iloc[idx]['func_before']
            elif 'src' in test_set.columns:
                func = test_set.iloc[idx]['src']
            else:
                return []
            
            # 移除注释
                func = remove_comments_and_docstrings_c(func)
            
            # 获取代码行列表，过滤空行
            code_lines = []
            for line in func.split('\n'):
                line = line.strip()
                if line:  # 只保留非空行
                    code_lines.append(line)
            
            # 处理漏洞行
            flaw_lines = [x.strip() for x in flaw_line.split('/~/')]
            flaw_line_index_list = []
            
            for flaw_line_item in flaw_lines:
                if not flaw_line_item:
                    continue
                
                # 多种匹配策略
                matched = False
                for lineid, line in enumerate(code_lines):
                    # 策略1: 完全匹配
                    if flaw_line_item.strip() == line.strip():
                        flaw_line_index_list.append(lineid)
                        matched = True
                        break
                    # 策略2: 忽略空格差异
                    elif flaw_line_item.replace(' ', '') == line.replace(' ', ''):
                        flaw_line_index_list.append(lineid)
                        matched = True
                        break
                    # 策略3: 部分匹配
                    elif (flaw_line_item in line and len(flaw_line_item) > 5) or \
                         (line in flaw_line_item and len(line) > 5):
                        flaw_line_index_list.append(lineid)
                        matched = True
                        break
                
                if not matched and len(code_lines) > 0:
                    # 如果没找到匹配，使用第一个非空行作为备选
                    flaw_line_index_list.append(0)
            
            if flaw_line_index_list:
                return flaw_line_index_list
    except Exception as e:
        pass
    
    # 如果都失败了，返回空列表
    return []

def clean_flaw_line_idx(flaw_line_idx_str):
    """清理和修复flaw_line_idx字符串中的语法错误"""
    if not isinstance(flaw_line_idx_str, str):
        return flaw_line_idx_str
    
    # 移除多余的逗号和空格
    cleaned = re.sub(r',\s*,', ',', flaw_line_idx_str)  # 移除连续逗号
    cleaned = re.sub(r',\s*]', ']', cleaned)  # 移除结尾的逗号
    cleaned = re.sub(r'\[\s*,', '[', cleaned)  # 移除开头的逗号
    cleaned = re.sub(r'\s+', '', cleaned)  # 移除多余空格
    
    return cleaned

if __name__ == '__main__':
    import argparse
    
    # 创建标准的ArgumentParser而不是HfArgumentParser
    parser = argparse.ArgumentParser(description='VulProbe Explanation Evaluation')
    
    # 添加所有必要的参数
    parser.add_argument('--do_train', type=bool, default=False, help='Train the LineProbe.')
    parser.add_argument('--customize', type=bool, default=False, help='Customize the AST.')
    parser.add_argument('--graph', type=bool, default=False, help='Graph the results.')
    parser.add_argument('--lang', type=str, default='python', help='Language to be used in this experiment.')
    parser.add_argument('--first_step_model_type', type=str, default='codebert', help='Type of the first step model.')
    parser.add_argument('--first_step_model', type=str, default='/model_c.bin', help='File name of the first_step_model.')
    parser.add_argument('--probe_saved_path', type=str, default='./results/probes', help='Path where to save the trained probes.')
    parser.add_argument('--probe_name', type=str, default=None, help='Name to identify the running and logging directory of LineProbe.')
    parser.add_argument('--dataset_path', type=str, default='/tmp/pycharm_project_573/VulProbe-main/src/resource/dataset/python', help='Path to the folder that contains the dataset.')
    parser.add_argument('--layer', type=int, default=5, help='Layer used to get the embeddings.')
    parser.add_argument('--strategy', type=str, default='plain', help='Strategy of LineProbe.')
    parser.add_argument('--top_k', type=int, default=5, help='Number of top-k lines to be considered.')
    parser.add_argument('--explain_method', type=str, default='probe', help='Explanation method.')
    parser.add_argument('--lr', type=float, default=1e-3, help='The initial learning rate for AdamW.')
    parser.add_argument('--epochs', type=int, default=20, help='Number of training epochs.')
    parser.add_argument('--batch_size', type=int, default=32, help='Train and validation batch size.')
    parser.add_argument('--patience', type=int, default=5, help='Patience for early stopping.')
    parser.add_argument('--rank', type=int, default=128, help='Maximum rank of the probe.')
    parser.add_argument('--orthogonal_reg', type=float, default=5, help='Orthogonal regularized term.')
    parser.add_argument('--hidden', type=int, default=768, help='Dimension of the feature word vectors.')
    parser.add_argument('--seed', type=int, default=42, help='Seed for experiments replication.')
    parser.add_argument('--max_tokens', type=int, default=512, help='Max tokens considered.')
    parser.add_argument('--name', type=str, default='123456', help='Name of the experiment.')
    
    # 添加我们需要的特殊参数
    parser.add_argument('--control_weight', type=str, default='False', help='True or False')
    parser.add_argument('--ast_mode', type=str, default='tree', help='tree or preorder')
    
    args = parser.parse_args()
    
    # 转换control_weight为布尔值
    args.control_weight = args.control_weight.lower() in ['true', '1', 'yes']
        
    logger.info('Load test dataset from local file.')
    # 修正：不再拼接args.lang，直接使用dataset_path
    
    # 添加数据集路径调试信息
    logger.info(f"语言设置: {args.lang}")
    logger.info(f"数据集路径: {args.dataset_path}")
    
    # 检查数据集目录是否存在
    if not os.path.exists(args.dataset_path):
        logger.error(f"数据集目录不存在: {args.dataset_path}")
        logger.info("请检查数据集路径和语言设置")
        sys.exit(1)
    
    # 列出数据集目录中的文件
    dataset_files = os.listdir(args.dataset_path)
    logger.info(f"数据集目录中的文件: {dataset_files}")
    
    test_set = pd.read_json(os.path.join(args.dataset_path, 'test.jsonl'), lines=True)
    
    top_k = args.top_k#评估比例
    line_total_num = 0
    flaw_line_total_num = 0
    for idx, term in test_set.iterrows():#遍历测试集中的每一行
        code = term['src']
        #统计代码中非空行的数量，并加入 line_total_num
        line_total_num += len([line for line in code.split('\n') if len(line) > 0])
        flaw_line_idx = term['flaw_line_index']
        
        # 清理和修复flaw_line_idx中的语法错误
        flaw_line_idx = clean_flaw_line_idx(flaw_line_idx)
        
        if ',' in flaw_line_idx:  # 判断是否是多个索引
            try:
                flaw_line_total_num += len(eval(flaw_line_idx))
                test_set.at[idx, 'flaw_line_index'] = list(eval(flaw_line_idx))
            except (SyntaxError, ValueError) as e:
                logger.warning(f"无法解析flaw_line_idx: {flaw_line_idx}, 错误: {e}")
                # 如果解析失败，尝试手动解析
                try:
                    numbers = flaw_line_idx.strip('[]').split(',')
                    numbers = [int(n.strip()) for n in numbers if n.strip().isdigit()]
                    flaw_line_total_num += len(numbers)
                    test_set.at[idx, 'flaw_line_index'] = numbers
                except Exception as e2:
                    logger.error(f"手动解析也失败: {e2}, 设置为空列表")
                    flaw_line_total_num += 0
                    test_set.at[idx, 'flaw_line_index'] = []
        else:
            if len(flaw_line_idx) > 0:
                try:
                    flaw_line_total_num += 1
                    test_set.at[idx, 'flaw_line_index'] = [eval(flaw_line_idx)]
                except (SyntaxError, ValueError) as e:
                    logger.warning(f"无法解析单个flaw_line_idx: {flaw_line_idx}, 错误: {e}")
                    flaw_line_total_num += 0
                    test_set.at[idx, 'flaw_line_index'] = []

    logger.info(f"Evaluate Attention Localization Method")
    
    hit = 0 #初始化命中计数器，稍后用于统计多少漏洞行被模型在 Top-K 内成功识别

    # ifa
    line_num_to_check = list()
    
    l_ifa_line_num_to_check = list()#用于记录不同样本 IFA 结果的辅助列表
    
    base_dir = os.path.dirname(os.path.abspath(__file__))
    lines_result_path = None  # 先初始化

    # Generate control suffix for file naming
    control_suffix = "_control" if args.control_weight else ""
    ast_mode_suffix = f"_{args.ast_mode}" if args.strategy == 'ast' else ""
    
    if args.first_step_model_type == 'codebert':
        test_result = pd.read_csv(os.path.join(base_dir, 'resource', 'firstStepModels', 'BERT', f'test_result_{args.name}.csv'))
        if args.explain_method in ['deeplift_shap', 'gradient_shap', 'saliency', 'attention']:
            lines_result_path = os.path.join(base_dir, 'resource', 'firstStepModels', 'BERT', 'explaination', f'{args.explain_method}_explaination.csv')
        elif args.explain_method == 'probe':
        #lines_result_path = os.path.join(base_dir, '..', 'results', 
            #'explaination', f'{args.first_step_model_type}_{args.strategy}_
            #{args.explain_method}_explaination_{args.name}.csv')
            lines_result_path = os.path.join(base_dir, '..', 'results', 'explaination', f'{args.first_step_model_type}_{args.strategy}{ast_mode_suffix}{control_suffix}_{args.explain_method}_explaination_{args.name}.csv')
    elif args.first_step_model_type == 'graphcodebert':
        test_result = pd.read_csv(os.path.join(base_dir, 'resource', 'firstStepModels', 'GraphCodeBERT', 'test_result_0.csv'))
        if args.explain_method == 'saliency':
            lines_result_path = '/tmp/pycharm_project_420/VulProbe-main/src/resource/firstStepModels/GraphCodeBERT/explaination/saliency_explaination.csv'
        elif args.explain_method in ['deeplift', 'gradient_shap', 'attention', 'deeplift_shap']:
            lines_result_path = os.path.join(base_dir, 'resource', 'firstStepModels', 'GraphCodeBERT', 'explaination', f'{args.explain_method}_explaination.csv')
        elif args.explain_method == 'probe':
#lines_result_path = os.path.join(base_dir, '..', 'results', 
            #'explaination', f'{args.first_step_model_type}_{args.strategy}_
            #{args.explain_method}_explaination_{args.name}.csv')
            lines_result_path = os.path.join(base_dir, '..', 'results', 'explaination', f'{args.first_step_model_type}_{args.strategy}{ast_mode_suffix}{control_suffix}_{args.explain_method}_explaination_{args.name}.csv')
    elif args.first_step_model_type == 'unixcoder':
        test_result = pd.read_csv(os.path.join(base_dir, 'resource', 'firstStepModels', 'unixcoder', f'test_result_{args.name}.csv'))
        if args.explain_method in ['saliency', 'deeplift_shap','gradient_shap', 'attention']:
            lines_result_path = os.path.join(base_dir, 'resource', 'firstStepModels', 'unixcoder', 'explaination', f'{args.explain_method}_explaination.csv')
        elif args.explain_method == 'probe':
            #lines_result_path = os.path.join(base_dir, '..', 'results', 
            #'explaination', f'{args.first_step_model_type}_{args.strategy}_
            #{args.explain_method}_explaination_{args.name}.csv')
            lines_result_path = os.path.join(base_dir, '..', 'results', 'explaination', f'{args.first_step_model_type}_{args.strategy}{ast_mode_suffix}{control_suffix}_{args.explain_method}_explaination_{args.name}.csv')
    elif args.first_step_model_type == 'codet5':
        # 兼容多种可能的测试结果保存位置
        project_root = os.path.abspath(os.path.join(base_dir, '..'))
        seed = getattr(args, 'seed', 42)
        name = getattr(args, 'name', '00')
        test_candidates = [
            os.path.join(project_root, f'test_result_{seed}.csv'),
            os.path.join(base_dir, 'resource', 'firstStepModels', 'CodeT5', f'test_result_{name}.csv'),
        ]
        test_result_path = None
        for p in test_candidates:
            if os.path.exists(p):
                test_result_path = p
                break
        if not test_result_path:
            raise FileNotFoundError(f"未找到CodeT5测试结果文件，尝试路径: {test_candidates}")
        test_result = pd.read_csv(test_result_path)
        if args.explain_method in ['lig', 'deeplift', 'gradient_shap', 'saliency', 'attention']:
            lines_result_path = os.path.join(base_dir, 'resource', 'firstStepModels', 'CodeT5', 'explaination', f'{args.explain_method}_explaination.csv')
        elif args.explain_method == 'probe':
            #lines_result_path = os.path.join(base_dir, '..', 'results', 
            #'explaination', f'{args.first_step_model_type}_{args.strategy}_
            #{args.explain_method}_explaination_{args.name}.csv')
            lines_result_path = os.path.join(base_dir, '..', 'results', 'explaination', f'{args.first_step_model_type}_{args.strategy}{ast_mode_suffix}{control_suffix}_{args.explain_method}_explaination_{args.name}.csv')
    elif args.first_step_model_type == 'bilstm':
        test_result = pd.read_csv(os.path.join(base_dir, 'resource', 'firstStepModels', 'BiLSTM', f'test_result_{args.name}.csv'))
        if args.explain_method in ['lig', 'deeplift', 'gradient_shap', 'saliency']:
            lines_result_path = os.path.join(base_dir, 'resource', 'firstStepModels', 'BiLSTM', 'explaination', f'{args.explain_method}_explaination.csv')
    elif args.first_step_model_type == 'mlp':
        test_result = pd.read_csv(os.path.join(base_dir, 'resource', 'firstStepModels', 'MLP', f'test_result_{args.name}.csv'))
        if args.explain_method in ['lig', 'deeplift', 'gradient_shap', 'saliency']:
            lines_result_path = os.path.join(base_dir, 'resource', 'firstStepModels', 'MLP', 'explaination', f'{args.explain_method}_explaination.csv')
    elif args.first_step_model_type == 'LineVul' and args.explain_method == 'linevul':
        tmp_idx = args.name
        test_result = pd.read_csv(os.path.join(base_dir, '..', 'LineVul', 'linevul', f'test_result_{tmp_idx}.csv'))
        lines_result_path = os.path.join(base_dir, '..', 'LineVul', 'loc_result', f'line_att_scores_df_model_{tmp_idx}.csv')
    elif args.first_step_model_type == 'linevd':
        tmp_idx = args.name
        test_result = pd.read_csv(os.path.join(base_dir, '..', 'results', 'baseline', f'linevd_score_{tmp_idx}.csv'))
        lines_result_path = os.path.join(base_dir, '..', 'results', 'baseline', f'linevd_score_{tmp_idx}.csv')
    elif args.first_step_model_type == 'qwen':
        test_result = pd.read_csv(os.path.join(base_dir, '..', 'llm', 'qwen', 'result2.csv'))
        lines_result_path = os.path.join(base_dir, '..', 'llm', 'qwen', 'result2.csv')
    elif args.first_step_model_type == 'gpt':
        test_result = pd.read_csv(os.path.join(base_dir, '..', 'llm', 'gpt', f'result_{args.name}.csv'))
        lines_result_path = os.path.join(base_dir, '..', 'llm', 'gpt', f'result_{args.name}.csv')
    elif args.explain_method == 'probe':
        #lines_result_path = os.path.join(base_dir, '..', 'results', 
       # 'explaination', f'{args.first_step_model_type}_{args.strategy}_{args.
        #explain_method}_explaination_{args.name}.csv')
        lines_result_path = os.path.join(base_dir, '..', 'results', 'explaination', f'{args.first_step_model_type}_{args.strategy}{control_suffix}_{args.explain_method}_explaination_{args.name}.csv')

    if not lines_result_path or not os.path.exists(lines_result_path):
        logger.error(f"lines_result_path 未定义或文件不存在: {lines_result_path}")
        sys.exit(1)

    lines_result = pd.read_csv(lines_result_path)
    print(f"Load line probe result from: {lines_result_path} | shape: {lines_result.shape}")
    
    # 检查数据集和结果文件的索引匹配
    print(f"Test dataset shape: {test_set.shape}")
    print(f"Lines result shape: {lines_result.shape}")
    
    # 检查索引范围
    max_index_in_result = lines_result['index'].max() if 'index' in lines_result.columns else len(lines_result) - 1
    max_index_in_dataset = len(test_set) - 1
    
    print(f"Max index in result: {max_index_in_result}")
    print(f"Max index in dataset: {max_index_in_dataset}")
    
    if max_index_in_result > max_index_in_dataset:
        logger.warning(f"结果文件中的索引 {max_index_in_result} 超出了数据集范围 {max_index_in_dataset}")
        logger.warning("这可能是数据集不匹配的问题，请检查数据集路径和语言设置")
        
        # 过滤掉超出范围的索引
        valid_indices = lines_result['index'] <= max_index_in_dataset
        lines_result = lines_result[valid_indices].reset_index(drop=True)
        print(f"过滤后的结果文件形状: {lines_result.shape}")
    
    #如果路径中包含 'lig'（某种模型名称），将 lines_score 中的 'nan' 替换为 0，防止后续出错。
    if 'lig' in lines_result_path:
        lines_result['lines_score'] = lines_result['lines_score'].apply(lambda x: x.replace('nan', '0'))    
        """
        TP（真实是漏洞，模型也预测是漏洞）；
FP（真实不是漏洞，模型预测是漏洞）；
TN（真实不是漏洞，模型预测也不是）；
FN（真实是漏洞，模型未能检测）。
        """
    tp_list = test_result[test_result.apply(lambda x: x['label'] == 1 and x['pred'] == True, axis=1)].index.tolist()
    fp_list = test_result[test_result.apply(lambda x: x['label'] == 0 and x['pred'] == True, axis=1)].index.tolist()
    tn_list = test_result[test_result.apply(lambda x: x['label'] == 0 and x['pred'] == False, axis=1)].index.tolist()
    fn_list = test_result[test_result.apply(lambda x: x['label'] == 1 and x['pred'] == False, axis=1)].index.tolist()
    print(f"tp: {len(tp_list)} | fp: {len(fp_list)} | tn: {len(tn_list)} | fn: {len(fn_list)}")
    
    # record the hit entry
    hit_list = list()
    not_hit_list = list()
    
    # 新增：记录每个样本的详细命中情况
    sample_hit_details = []
    
    # top_k_accuracy
    # save pred top_k
    lines_result['pred'] = None
    
    # for row_idx, term in tqdm(lines_result.iterrows(), total=len(lines_result)):
    #跳过 TN、FN，因为 Top-K 排行只考虑预测为漏洞的函数（TP 或 FP）
    for row_idx, term in lines_result.iterrows():
        actual_index = term['index']
        if actual_index in tn_list or actual_index in fn_list:
            continue
        try:
            flaw_line_idx = test_set['flaw_line_index'][actual_index]
            flaw_line_idx = revision(args, actual_index, flaw_line_idx)
            if not flaw_line_idx:
                continue
            # 解析该函数中每行的分数（字符串转列表），建立 line_id -> score 的映射
            line_statistic = {}
            for idx, score in enumerate(eval(term['lines_score'])):
                line_statistic[idx] = score
            ground_flaw_lines = [int(x) for x in flaw_line_idx]
            sorted_lines = sorted(line_statistic.items(), key=lambda item: item[1], reverse=True)
            lines_index = [x[0] for x in sorted_lines]
            lines_result.at[row_idx, 'pred'] = lines_index
            pred_flaw_lines = lines_index[:top_k]
            
            # 新增：检查该样本在各个top-k位置的命中情况
            hit_at_top1 = check(ground_flaw_lines, lines_index[:1])
            hit_at_top3 = check(ground_flaw_lines, lines_index[:3])
            hit_at_top5 = check(ground_flaw_lines, lines_index[:5])
            hit_at_top10 = check(ground_flaw_lines, lines_index[:10])
            
            # 确定首次命中的位置
            first_hit_position = None
            if hit_at_top1:
                first_hit_position = 'Top-1'
            elif hit_at_top3:
                first_hit_position = 'Top-3'
            elif hit_at_top5:
                first_hit_position = 'Top-5'
            elif hit_at_top10:
                first_hit_position = 'Top-10'
            else:
                first_hit_position = 'Not Hit'
            
            # 找到真实漏洞行在预测排序中的位置
            flaw_line_ranks = []
            for flaw_line in ground_flaw_lines:
                if flaw_line in lines_index:
                    rank = lines_index.index(flaw_line) + 1  # 从1开始计数
                    flaw_line_ranks.append(rank)
                else:
                    flaw_line_ranks.append(-1)  # 未找到
            
            min_rank = min([r for r in flaw_line_ranks if r > 0]) if any(r > 0 for r in flaw_line_ranks) else -1
            
            # 记录详细信息
            sample_detail = {
                'sample_index': actual_index,
                'sample_type': 'TP' if actual_index in tp_list else 'FP',
                'true_flaw_lines': str(ground_flaw_lines),
                'predicted_top1': str(lines_index[:1]),
                'predicted_top3': str(lines_index[:3]),
                'predicted_top5': str(lines_index[:5]),
                'predicted_top10': str(lines_index[:10]),
                'hit_at_top1': hit_at_top1,
                'hit_at_top3': hit_at_top3,
                'hit_at_top5': hit_at_top5,
                'hit_at_top10': hit_at_top10,
                'first_hit_at': first_hit_position,
                'min_rank': min_rank,
                'all_flaw_line_ranks': str(flaw_line_ranks),
                'total_lines': len(lines_index)
            }
            sample_hit_details.append(sample_detail)
            
            if check(ground_flaw_lines, pred_flaw_lines):
                hit += 1
                hit_list.append(actual_index)
        except Exception as e:
            logger.warning(f"处理样本 {actual_index} 时出现异常: {e}")
            continue
            
    #test_data = pd.read_json('VulProbe/src/resource/dataset/c/test.jsonl', lines=True)
    test_data = pd.read_json('/tmp/pycharm_project_573/VulProbe-main/src/resource/dataset/python/test.jsonl', lines=True)

    # # ifa
    # # for row_idx, term in tqdm(lines_result.iterrows(), total=len(lines_result)):
    # #再次处理所有样本，构造每行的得分信息IFA计算
    # for row_idx, term in lines_result.iterrows():
    #     actual_index = term['index']
    #     try:
    #         flaw_line_idx = test_set['flaw_line_index'][actual_index]
    #         flaw_line_idx = revision(args, actual_index, flaw_line_idx)
    #         if not flaw_line_idx:
    #             continue
    #         line_statistic = {}
    #         for idx, score in enumerate(eval(term['lines_score'])):
    #             line_statistic[idx] = score
    #         # 如果是 FN（实际有漏洞但模型没检测），认为模型会检查所有行也找不到；
    #         if actual_index not in tp_list:
    #             if actual_index in fn_list:
    #                 ground_flaw_lines = [int(x) for x in flaw_line_idx]
    #                 for ground_flaw_line in ground_flaw_lines:
    #                     line_num_to_check.insert(0, len(line_statistic))
    #                 l_ifa_line_num_to_check.insert(0, len(line_statistic))
    #             continue
    #         try:
    #             for ground_flaw_line in [int(x) for x in flaw_line_idx]:
    #                 line_num_to_check.insert(0, 0)
    #                 for pred_flaw_line in [x[0] for x in sorted(line_statistic.items(), key=lambda item: item[1], reverse=True)]:
    #                     if ground_flaw_line == pred_flaw_line:
    #                         break
    #                     else:
    #                         line_num_to_check[0] += 1
    #         except Exception as e:
    #             logger.warning(f"IFA计算异常: {e}")
    #             continue
    #         pred = term['pred']
    #         if not isinstance(pred, list):
    #             pred = eval(pred)
    #         l_ifa_line_num_to_check.insert(0, 0)
    #         for rank, pred_line in enumerate(pred):
    #             if pred_line in [int(x) for x in flaw_line_idx]:
    #                 l_ifa_line_num_to_check[0] = rank
    #                 break
    #             if rank == len(pred) - 1:
    #                 l_ifa_line_num_to_check[0] = len(pred)
    #     except Exception as e:
    #         logger.warning(f"IFA处理样本 {actual_index} 时出现异常: {e}")
    #         continue
    #
    # flaw_line_total_num = flaw_line_total_num
    #
    # # ifa
    # # print(f"sum(line_num_to_check): {sum(line_num_to_check)} len(line_num_to_check): {len(line_num_to_check)}")
    # if len(line_num_to_check) > 0:
    #     avg_ifa = sum(line_num_to_check) / len(line_num_to_check)
    #     median_ifa = statistics.median(line_num_to_check)
    # else:
    #     logger.warning("line_num_to_check 列表为空，无法计算 IFA 指标")
    #     avg_ifa = 0
    #     median_ifa = 0
    #
    # # print(f'sum(l_ifa_line_num_to_check): {sum(l_ifa_line_num_to_check)} len(l_ifa_line_num_to_check): {len(l_ifa_line_num_to_check)}')
    # if len(l_ifa_line_num_to_check) > 0:
    #     linevul_ifa = sum(l_ifa_line_num_to_check) / len(l_ifa_line_num_to_check)
    # else:
    #     logger.warning("l_ifa_line_num_to_check 列表为空，无法计算 LineVul IFA 指标")
    #     linevul_ifa = 0
    #
    # # print(f'line_total_num: {line_total_num} | flaw_line_total_num: {flaw_line_total_num}')
    #
    # # Recall@1%Effort
    # # rEffort = get_recall_1_effort_avg(lines_result, test_set, args.lang, flaw_line_total_num, line_total_num)
    # rEffort = get_recall(lines_result, test_set, 0.01, flaw_line_total_num, line_total_num)
    #
    # # Effort@20%Recall
    # # eRecall = get_effort_20_recall_avg(lines_result, test_set, args.lang, flaw_line_total_num, line_total_num)
    # eRecall = get_effort(lines_result, test_set, 0.2, flaw_line_total_num, line_total_num)
    #
    # ifa
    # for row_idx, term in tqdm(lines_result.iterrows(), total=len(lines_result)):
    for row_idx, term in lines_result.iterrows():
        # 使用结果文件中的index列而不是iterrows的索引
        sample_idx = term['index']
        if sample_idx >= len(test_set):
            print(f"Warning: sample_idx {sample_idx} >= test_set length {len(test_set)}, skipping")
            continue
        flaw_line_idx = test_set['flaw_line_index'][sample_idx]
        flaw_line_idx = revision(args, sample_idx, flaw_line_idx)

        line_statistic = {}
        for idx, score in enumerate(eval(term['lines_score'])):
            line_statistic[idx] = score

        if term['index'] not in tp_list:
            if term['index'] in fn_list:
                ground_flaw_lines = [int(x) for x in flaw_line_idx]
                for ground_flaw_line in ground_flaw_lines:
                    line_num_to_check.insert(0, len(line_statistic))
                l_ifa_line_num_to_check.insert(0, len(line_statistic))
            continue

        try:
            for ground_flaw_line in [int(x) for x in flaw_line_idx]:
                line_num_to_check.insert(0, 0)
                for pred_flaw_line in [x[0] for x in
                                       sorted(line_statistic.items(), key=lambda item: item[1], reverse=True)]:
                    if ground_flaw_line == pred_flaw_line:
                        break
                    else:
                        line_num_to_check[0] += 1
        except Exception as e:
            traceback.print_exc()
            continue

        pred = term['pred']
        if not isinstance(pred, list):
            pred = eval(pred)
        l_ifa_line_num_to_check.insert(0, 0)
        for rank, pred_line in enumerate(pred):
            if pred_line in [int(x) for x in flaw_line_idx]:
                l_ifa_line_num_to_check[0] = rank
                break
            if rank == len(pred) - 1:
                l_ifa_line_num_to_check[0] = len(pred)

    flaw_line_total_num = flaw_line_total_num

    # ifa
    # print(f"sum(line_num_to_check): {sum(line_num_to_check)} len(line_num_to_check): {len(line_num_to_check)}")
    avg_ifa = sum(line_num_to_check) / len(line_num_to_check)
    median_ifa = statistics.median(line_num_to_check)
    # print(f'sum(l_ifa_line_num_to_check): {sum(l_ifa_line_num_to_check)} len(l_ifa_line_num_to_check): {len(l_ifa_line_num_to_check)}')
    linevul_ifa = sum(l_ifa_line_num_to_check) / len(l_ifa_line_num_to_check)

    # print(f'line_total_num: {line_total_num} | flaw_line_total_num: {flaw_line_total_num}')

    # Recall@1%Effort
    # rEffort = get_recall_1_effort_avg(lines_result, test_set, args.lang, flaw_line_total_num, line_total_num)
    rEffort = get_recall(lines_result, test_set, 0.01, flaw_line_total_num, line_total_num)

    # Effort@20%Recall
    # eRecall = get_effort_20_recall_avg(lines_result, test_set, args.lang, flaw_line_total_num, line_total_num)
    eRecall = get_effort(lines_result, test_set, 0.2, flaw_line_total_num, line_total_num)

    print(f"hit_num: {hit} | "
          f"top_{top_k}_accuracy: {round(hit / (len(tp_list) + len(fn_list)), 4)} | "
          f"IFA: {round(linevul_ifa, 2)} | "
          f"meanRank: {round(avg_ifa, 2)} | "
          f"Recall@1%Effort: {rEffort} | "
          f"Effort@20%Recall: {eRecall}")

    with open('VulProbe/mannual check/codebert_hit.txt', 'a+') as f:
        f.write(f"top_{top_k} hit list {len(hit_list)}:\n {hit_list}\n")
        f.write(f"top_{top_k} not hit list {len(not_hit_list)}:\n {not_hit_list}\n")
    print(f"hit_num: {hit} | "
        f"top_{top_k}_accuracy: {round(hit / (len(tp_list) + len(fn_list)), 4)} | "
        f"IFA: {round(linevul_ifa, 2)} | "
        f"meanRank: {round(avg_ifa, 2)} | "
        f"Recall@1%Effort: {rEffort} | "
        f"Effort@20%Recall: {eRecall}")
    output_dir = 'VulProbe/mannual check'
    os.makedirs(output_dir, exist_ok=True)
    with open('VulProbe/mannual check/codebert_hit.txt', 'a+') as f:
        f.write(f"top_{top_k} hit list {len(hit_list)}:\n {hit_list}\n")
        f.write(f"top_{top_k} not hit list {len(not_hit_list)}:\n {not_hit_list}\n")
    
    # 新增：保存每个样本的详细命中情况到CSV文件
    if sample_hit_details:
        hit_details_df = pd.DataFrame(sample_hit_details)
        
        # 构造输出文件名
        control_suffix = "_control" if args.control_weight else ""
        ast_mode_suffix = f"_{args.ast_mode}" if args.strategy == 'ast' else ""
        detail_output_path = os.path.join(output_dir, 
            f'{args.first_step_model_type}_{args.strategy}{ast_mode_suffix}{control_suffix}_sample_hit_details_{args.name}.csv')
        
        hit_details_df.to_csv(detail_output_path, index=False, encoding='utf-8')
        print(f"\n✓ 样本详细命中情况已保存到: {detail_output_path}")
        
        # 打印统计摘要
        print(f"\n=== 样本命中统计摘要 ===")
        print(f"总分析样本数: {len(sample_hit_details)}")
        print(f"Top-1 命中: {sum(1 for d in sample_hit_details if d['hit_at_top1'])} ({sum(1 for d in sample_hit_details if d['hit_at_top1'])/len(sample_hit_details)*100:.2f}%)")
        print(f"Top-3 命中: {sum(1 for d in sample_hit_details if d['hit_at_top3'])} ({sum(1 for d in sample_hit_details if d['hit_at_top3'])/len(sample_hit_details)*100:.2f}%)")
        print(f"Top-5 命中: {sum(1 for d in sample_hit_details if d['hit_at_top5'])} ({sum(1 for d in sample_hit_details if d['hit_at_top5'])/len(sample_hit_details)*100:.2f}%)")
        print(f"Top-10 命中: {sum(1 for d in sample_hit_details if d['hit_at_top10'])} ({sum(1 for d in sample_hit_details if d['hit_at_top10'])/len(sample_hit_details)*100:.2f}%)")
        print(f"未命中: {sum(1 for d in sample_hit_details if d['first_hit_at'] == 'Not Hit')}")
        
        # 按首次命中位置分组统计
        print(f"\n=== 按首次命中位置分组 ===")
        from collections import Counter
        first_hit_counter = Counter([d['first_hit_at'] for d in sample_hit_details])
        for position in ['Top-1', 'Top-3', 'Top-5', 'Top-10', 'Not Hit']:
            count = first_hit_counter.get(position, 0)
            print(f"{position}: {count} 个样本")
        
        # 显示前10个样本的详细信息
        print(f"\n=== 前10个样本的详细信息 ===")
        for i, detail in enumerate(sample_hit_details[:10]):
            print(f"\n样本 {detail['sample_index']} ({detail['sample_type']}):")
            print(f"  真实漏洞行: {detail['true_flaw_lines']}")
            print(f"  首次命中位置: {detail['first_hit_at']}")
            print(f"  最小排名: {detail['min_rank']}")
            print(f"  预测Top-3: {detail['predicted_top3']}")

    # 在加载lines_result后，增加调试输出
    print("\n[DEBUG] 前10个样本的lines_score分布:")
    for i in range(min(10, len(lines_result))):
        print(f"样本{i} lines_score: {lines_result.iloc[i]['lines_score']}")
    
    # 打印top_k命中样本的分数和真实标签
    print("\n[DEBUG] top_k命中样本分数和真实标签:")
    for idx in hit_list[:10]:
        try:
            print(f"样本{idx} lines_score: {lines_result.iloc[idx]['lines_score']} | flaw_line_index: {test_set.iloc[idx]['flaw_line_index']}")
        except Exception as e:
            print(f"样本{idx} 打印异常: {e}")
    
    # 打印meanRank和IFA的详细计算过程
    print(f"\n[DEBUG] meanRank计算明细: line_num_to_check={line_num_to_check}")
    print(f"[DEBUG] IFA计算明细: l_ifa_line_num_to_check={l_ifa_line_num_to_check}")
