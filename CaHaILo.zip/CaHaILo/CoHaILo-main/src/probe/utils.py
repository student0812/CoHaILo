import sys
import torch
from torch.nn.utils.rnn import pad_sequence
from torch_scatter import scatter_mean


# def get_embeddings(all_inputs, all_attentions, model, layer, model_type):
#     if model_type == 't5':
#         with torch.no_grad():
#             embs = model(input_ids=all_inputs, attention_mask=all_attentions)[1][layer][:, 1:, :]
#     else:
#         with torch.no_grad():
#             embs = model(input_ids=all_inputs, attention_mask=all_attentions)[2][layer][:, 1:, :]
#     return embs
# 定义一个函数，用来根据不同模型类型，提取输入数据 all_inputs 对应的中间表示（hidden states）。
# first_step_model_type 控制用哪种方式提取特征。func, args 是额外需要的信息
def get_embeddings(all_inputs, model, layer, first_step_model_type, func=None, args=None, tokenizer=None):
    # 返回的是模型输出的隐藏层特征 hidden_state，不是分类结果
    # 保证all_inputs和模型在同一设备
    device = next(model.parameters()).device
    all_inputs = all_inputs.to(device)
    if first_step_model_type == 'bert':
        _, hidden_state = model(all_inputs)
        return hidden_state
    elif first_step_model_type == 'mlp':
        _, hidden_state = model(all_inputs)
        return hidden_state
    # 先拿 codebert 提取初步的token嵌入表示。然后把这些嵌入喂给 BiLSTM 网络，再提取 BiLSTM 的 hidden_state。
    elif first_step_model_type == 'bilstm':
        input_embeds = model.codebert(all_inputs)[0].float()
        _, hidden_state = model(input_embeds)
        return hidden_state
    # 直接通过 LineVul模型，从指定 layer 提取隐藏特征
    elif first_step_model_type == 'LineVul':
        with torch.no_grad():
            hidden_state = model(input_ids=all_inputs, layer=layer)
        return hidden_state
    # 提取 CodeBERT 的中间层输出（outputs）
    elif first_step_model_type == 'codebert':
        with torch.no_grad():
            prob, outputs, _ = model(input_ids=all_inputs, output_attentions=True)
        return outputs
    # 导入 tree-sitter：用于语法树解析，初始化语法树解析器
    elif first_step_model_type == 'graphcodebert':
        # 恢复GraphCodeBERT的原始AST处理能力
        with torch.no_grad():
            from tree_sitter import Language, Parser
            PYTHON_LANGUAGE = Language('/tmp/pycharm_project_420/VulProbe-main/src/resource/grammars/languages.so',
                                       'python')
            parser = Parser()
            parser.set_language(PYTHON_LANGUAGE)

            # 确保输入张量在正确的设备上
            device = next(model.parameters()).device
            all_inputs = all_inputs.to(device)

            # 检查输入是否超出词汇表范围
            vocab_size = model.roberta.embeddings.word_embeddings.num_embeddings
            if all_inputs.max().item() >= vocab_size:
                print('[ERROR] GraphCodeBERT: 有非法token id:', all_inputs[all_inputs >= vocab_size])
                raise ValueError('GraphCodeBERT: input_ids中存在超出词表范围的token id')

            # 使用GraphCodeBERT的原始AST处理方式
            if func is not None and len(func) > 0:
                # 处理AST信息
                type_embeds = []
                source_embeds = []

                for f in func:
                    try:
                        # 确保f是纯代码字符串
                        pure_code = f
                        if isinstance(f, str) and f.startswith('{') and f.endswith('}'):
                            try:
                                import ast
                                parsed = ast.literal_eval(f)
                                if isinstance(parsed, dict) and 'src' in parsed:
                                    pure_code = str(parsed['src'])
                            except:
                                pass

                        # 解析AST
                        tree = parser.parse(bytes(pure_code, "utf8"))
                        root_node = tree.root_node
                        type_list = []
                        walk(root_node, type_list)

                        # 处理AST类型信息 - 不截断AST信息
                        block_size = all_inputs.size(1)
                        # 保留完整的AST信息，只在必要时截断
                        if len(type_list) > block_size - 2:
                            type_list = type_list[:block_size - 2]
                        type_list = [tokenizer.cls_token] + type_list + [tokenizer.sep_token]
                        type_ids = tokenizer.convert_tokens_to_ids(type_list)

                        # 改进词汇表处理 - 保留AST结构信息
                        if any(x >= vocab_size or x < 0 for x in type_ids):
                            # 使用更保守的替换策略，保留AST结构
                            type_ids = [tokenizer.unk_token_id if x >= vocab_size or x < 0 else x for x in type_ids]

                        padding_length = block_size - len(type_ids)
                        type_ids += [tokenizer.pad_token_id] * padding_length
                        type_ids_tensor = torch.tensor([type_ids]).to(device)
                        type_embed = model.roberta.embeddings(type_ids_tensor)
                        type_embeds.append(type_embed)

                        # 处理源代码信息 - 同样改进
                        code_tokens = tokenizer.tokenize(str(pure_code))
                        if len(code_tokens) > block_size - 2:
                            code_tokens = code_tokens[:block_size - 2]
                        source_tokens = [tokenizer.cls_token] + code_tokens + [tokenizer.sep_token]
                        source_ids = tokenizer.convert_tokens_to_ids(source_tokens)

                        # 改进源代码的词汇表处理
                        if any(x >= vocab_size or x < 0 for x in source_ids):
                            source_ids = [tokenizer.unk_token_id if x >= vocab_size or x < 0 else x for x in source_ids]

                        padding_length = block_size - len(source_ids)
                        source_ids += [tokenizer.pad_token_id] * padding_length
                        source_ids_tensor = torch.tensor([source_ids]).to(device)
                        source_embed = model.roberta.embeddings(source_ids_tensor)
                        source_embeds.append(source_embed)

                    except Exception as e:
                        print(f"[ERROR] GraphCodeBERT AST处理异常: {e}")
                        continue

                # 检查是否有有效的 embeddings
                if type_embeds and source_embeds:
                    # 组合AST和源代码信息
                    type_embeds = torch.cat(type_embeds, dim=0)
                    source_embeds = torch.cat(source_embeds, dim=0)
                    input_embed = type_embeds + source_embeds

                    # 通过完整的transformer层处理
                    outputs = model.roberta(inputs_embeds=input_embed, output_hidden_states=True)
                    return outputs.last_hidden_state
                else:
                    # 尝试使用原始AST处理方式
                    try:
                        # 直接使用AST解析结果
                        tree = parser.parse(bytes(func[0] if func else "", "utf8"))
                        root_node = tree.root_node
                        type_list = []
                        walk(root_node, type_list)

                        # 使用AST信息生成嵌入
                        block_size = all_inputs.size(1)
                        if len(type_list) > block_size - 2:
                            type_list = type_list[:block_size - 2]
                        type_list = [tokenizer.cls_token] + type_list + [tokenizer.sep_token]
                        type_ids = tokenizer.convert_tokens_to_ids(type_list)

                        # 处理词汇表问题
                        if any(x >= vocab_size or x < 0 for x in type_ids):
                            type_ids = [tokenizer.unk_token_id if x >= vocab_size or x < 0 else x for x in type_ids]

                        padding_length = block_size - len(type_ids)
                        type_ids += [tokenizer.pad_token_id] * padding_length
                        type_ids_tensor = torch.tensor([type_ids]).to(device)
                        type_embed = model.roberta.embeddings(type_ids_tensor)

                        # 使用AST嵌入
                        outputs = model.roberta(inputs_embeds=type_embed, output_hidden_states=True)
                        return outputs.last_hidden_state
                    except Exception as e:
                        print(f"[ERROR] 原始AST处理也失败: {e}")
                        print("[WARNING] GraphCodeBERT AST处理失败，使用简化版本")

            # 如果AST处理失败，使用简化版本
            outputs = model.roberta(input_ids=all_inputs, output_hidden_states=True)
            return outputs.last_hidden_state
    elif first_step_model_type == 'codet5':
        with torch.no_grad():
            # 调试信息：打印输入shape和token id范围
            # prob, outputs, _ = model(input_ids=all_inputs, output_attentions=True)
            # return outputs
            # CodeT5ForCustomClassification 的 forward 方法不接受 output_attentions 参数
            # 它返回 (loss, logits) 或 logits，我们需要获取 encoder 的输出
            # outputs = model.encoder(input_ids=all_inputs)
            # 在调用model前，确保all_inputs和model在同一设备
            device = next(model.parameters()).device
            all_inputs = to_device(all_inputs, device)
            assert getattr(all_inputs, 'device', device) == device or not hasattr(all_inputs,
                                                                                  'device'), f"输入和模型设备不一致: {getattr(all_inputs, 'device', 'non-tensor')} vs {device}"
            try:
                outputs = model.encoder(input_ids=all_inputs)
            except Exception as e:
                print("[ERROR] input_ids:", all_inputs)
                print("[ERROR] input_ids shape:", all_inputs.shape)
                raise e
            return outputs.last_hidden_state
    elif first_step_model_type == 'unixcoder':
        with torch.no_grad():
            prob, outputs, _ = model(input_ids=all_inputs, output_attentions=True)
        return outputs
    else:
        raise ValueError(f"Unknown first_step_model_type: {first_step_model_type}")
    # 遍历语法树节点对每个叶子节点，记录：叶子节点类型 + 父节点类型。用于编码更丰富的结构信息。


def walk(node, type_list):
    if node.child_count == 0:
        parent = node.parent  # 记录它的 类型#父节点类型
        if parent:  # 如果父节点存在，就将叶子节点的类型 + 父节点的类型，以字符串拼接（用#连接）后，加入到 type_list 中。
            # print(f"Leaf: {node.type} -> Parent: {parent.type}")
            type_list.append(str(node.type) + '#' + str(parent.type))
        else:  # 如果没有父节点（一般只有根节点的孩子可能出现这种情况），就用 'root' 作为父类型。
            # print(f"Leaf: {node.type} -> No Parent")
            type_list.append(str(node.type) + '#' + 'root')  # 对每一个子节点 child，递归调用 walk(child, type_list)，继续往下遍历
    else:
        for child in node.children:
            walk(child, type_list)


# 对齐不同长度的序列表示去掉最后一个token（比如[SEP]符号）
def align_function(embs, align):
    seq = []
    embs = embs[:, :-1, :]
    # print("\n")
    # print(f"embs, align: {len(embs), len(align)}")
    # print("\n")
    # print(f"embs, align: {len(embs[0]), len(align[0])}")
    # print("\n")
    # print(f"embs, align: {len(embs[0][0])}")
    # print("\n")
    for j, emb in enumerate(embs):
        # align[j] 是一个映射，把token归属到高层次的单元
        # scatter_mean 把同一组的token平均，实现局部池化/对齐
        seq.append(scatter_mean(emb, align[j], dim=0))
        # scatter_mean：把相同 align[j] index 的token特征取平均，相当于按组聚合,对每条数据对齐
    # remove the last token since it corresponds to <\s> or padding to much the lens
    return pad_sequence(seq, batch_first=True)[:, :-1, :]


# pad_sequence补齐，使得 batch里的样本长度一致。去掉最后一位

def to_device(batch, device):
    import torch
    if isinstance(batch, torch.Tensor):
        return batch.to(device)
    elif isinstance(batch, (list, tuple)):
        return type(batch)(to_device(x, device) for x in batch)
    elif isinstance(batch, dict):
        return {k: to_device(v, device) for k, v in batch.items()}
    else:
        return batch
