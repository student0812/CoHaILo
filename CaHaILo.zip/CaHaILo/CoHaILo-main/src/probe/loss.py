import torch
import torch.nn as nn

#定义一个新的损失函数类，继承自 PyTorch 的 nn.Module，这样它就能像标准的损失函数一样被调用（即支持 .forward()）
class ParserLoss(nn.Module):
    def __init__(self, loss='l1', pretrained=False):#选择损失，以及是否是预训练模式
        super(ParserLoss, self).__init__()
        self.cs = nn.CrossEntropyLoss(ignore_index=-1)#忽略标签为 -1 的样本，即无效标记
        self.loss = loss
        self.pretrained = pretrained

       #d_pred：预测的依赖距离（回归分支）scores_c：类别C的预测分数（分类分支）scores_u：类别U的预测分数（分类分支）d_real：真实的依赖距离
#c_real：类别C的真实标签u_real：类别U的真实标签length_batch：每个样本的有效长度（可能是变长的序列）
    def forward(self, d_pred, scores_c, scores_u, d_real, c_real, u_real, length_batch):
        total_sents = torch.sum(length_batch != 0).float()
        labels_1s = (d_real != -1).float()
        d_pred_masked = d_pred * labels_1s  # b x seq-1
        d_real_masked = d_real * labels_1s  # b x seq-1
        if self.loss == 'l1':
            loss_d = torch.sum(torch.abs(d_pred_masked - d_real_masked), dim=1) / (length_batch.float() - 1)
            loss_d = torch.sum(loss_d) / total_sents
        elif self.loss == 'l2':
            loss_d = torch.sum(torch.abs(d_pred_masked - d_real_masked) ** 2, dim=1) / (length_batch.float() - 1)
            loss_d = torch.sum(loss_d) / total_sents
        elif self.loss == 'rank':
            lens_d = length_batch - 1
            max_len_d = torch.max(lens_d)
            mask = torch.arange(max_len_d, device=max_len_d.device)[None, :] < lens_d[:, None]
            loss_d = rankloss(d_pred, d_real, mask, exp=False)#计算排序误差
        #将分类分支的输出压平（变成二维）后，使用交叉熵损失计算
        loss_c = self.cs(scores_c.view(-1, scores_c.shape[2]), c_real.view(-1))
        loss_u = self.cs(scores_u.view(-1, scores_u.shape[2]), u_real.view(-1))
        #如果是预训练，只优化分类任务（不关心依赖距离回归）。否则分类加回归
        if self.pretrained:
            return loss_c + loss_u
        else:
            return loss_c + loss_d + loss_u

#定义排序损失函数，分别为预测值，真实值，以及掩码矩阵，是否使用指数形式
def rankloss(input, target, mask, exp=False):
    #计算预测值两两之间的差异，得到一个差分矩阵
    diff = input[:, :, None] - input[:, None, :]
    #真实标签之间如果有顺序关系（例如 𝑖i 应该小于 j），就设为1，否则为0。
    target_diff = ((target[:, :, None] - target[:, None, :]) > 0).float()
    #结合掩码，只在有效的、且有顺序关系的位置计算loss
    mask = mask[:, :, None] * mask[:, None, :] * target_diff
    #如果启用了exp，则用指数惩罚的方式，放大不满足排序的差异
    if exp:
        loss = torch.exp(torch.relu(target_diff - diff)) - 1
        #否则用简单的ReLU形式：不满足排序要求就产生损失。
    else:
        loss = torch.relu(target_diff - diff)
        #对所有有效的位置求平均损失，1e-9 防止除零。
    loss = (loss * mask).sum() / (mask.sum() + 1e-9)
    return loss
