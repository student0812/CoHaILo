import torch.nn as nn
import torch

#一个探针模型（Probe），用于分析或辅助训练神经网络输出的中间表示（比如隐藏状态）。
class Probe(nn.Module):
    pass

#定义具体探针 ParserProbe
class ParserProbe(Probe):
    #probe_rank：降维后的维度（将高维隐向量映射到低维），hidden_dim：原始的隐藏层的维度，number_labels_c：分类标签的数量（用于分类），number_labels_u：分类标签的数量（用于分类）
    def __init__(self, probe_rank, hidden_dim, number_labels_c, number_labels_u):
        print('Constructing ParserProbe')
        super(ParserProbe, self).__init__()
        self.probe_rank = probe_rank
        self.hidden_dim = hidden_dim
        self.number_vectors_c = number_labels_c
        self.number_vectors_u = number_labels_u
        #定义一个线性投影矩阵 proj（hidden_dim → probe_rank），作为降维矩阵，可以学习
        self.proj = nn.Parameter(data=torch.zeros(self.hidden_dim, self.probe_rank))
        #将 proj 权重初始化为小范围的均匀分布随机值（避免一开始全是0）
        nn.init.uniform_(self.proj, -0.05, 0.05)
        #创建一个矩阵 vectors_c，大小是（probe_rank × 分类数），用于分类任务C的预测
        self.vectors_c = nn.Parameter(data=torch.zeros(self.probe_rank, self.number_vectors_c))
        nn.init.uniform_(self.vectors_c, -0.05, 0.05)
        self.vectors_u = nn.Parameter(data=torch.zeros(self.probe_rank, self.number_vectors_u))
        nn.init.uniform_(self.vectors_u, -0.05, 0.05)
#batch 是一批词表示（隐藏状态），形状是：(batch_size, max_seq_len, hidden_dim)
    def forward(self, batch):
        """
        Args:
            batch: a batch of word representations of the shape
                    (batch_size, max_seq_len, representation_dim)

        Returns:
            d_pred: (batch_size, max_seq_len - 1)
            scores_c: (batch_size, max_seq_len - 1, number classes_c)
            scores_u: (batch_size, max_seq_len, number classes_u)
        """
        #transformed 的形状是：(batch_size, max_seq_len, probe_rank)，通过proj降维
        transformed = torch.matmul(batch, self.proj)
        shift = transformed[:, 1:, :]#把序列向后移动一格（去掉第一个位置），作差异分析
        diffs = shift - transformed[:, :-1, :]#计算每一对相邻词之间的向量差异
        #如果有 max_seq_len 个词，就有 (max_seq_len - 1) 对相邻词。分类任务 C 的类别数，比如可能有10种连接关系（比如主谓、动宾等）
        return (diffs ** 2).sum(dim=2), torch.matmul(diffs, self.vectors_c), torch.matmul(transformed, self.vectors_u)
#第一个输出相当于计算欧氏距离的平方。输出形状：(batch_size, max_seq_len - 1)，即每对词一个标量距离预测。
#torch.matmul(diffs, self.vectors_c)：将差异向量映射到分类C的类别空间。输出形状：(batch_size, max_seq_len - 1, number_labels_c)，是每对词一个分类分数。

