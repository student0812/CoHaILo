
#├── probe/                 # 主模型相关的逻辑，比如损失函数、模型推理等
#├── resource/              # 存储模型资源、语法、数据等
#├── util/                  # 工具模块：数据预处理、评分计算、AST 处理等
#├── main.py                # 入口文件（可能是训练或推理的起点）
#├── run.py                 # 可能是完整流程的入口，比如训练 + 推理 + 评估
#├── test.py                # 测试脚本，通常用于调试或验证
"""
probe/：模型核心逻辑模块
loss.py：定义了训练时使用的损失函数。
probe.py：可能是模型前向传播的核心逻辑。
utils.py：与模型运行相关的辅助函数（可能是比如 attention、分数归一化等）。
这些文件共同构成模型的主体，主要服务于“探针（Probe）”模型的训练和推理过程。

🔹 resource/：存放资源
➤ firstStepModels/：基础模型（如 CodeBERT、BiLSTM、MLP）
存放预训练模型结构或权重，比如 BERT/、unixcoder/。
用于初始化或者对比不同模型的第一阶段结果。

➤ grammars/
__init__.py：可能初始化语法分析工具，用于将代码转 AST。
语法相关工具常与 AST 提取结合使用（参考 code2ast.py）。

➤ dataset/
存放 JSONL 格式的代码数据，模型训练/推理的数据源。

🔹 util/：功能工具模块
用于支撑主流程，包括数据加载、预处理、AST、评分计算等。
binary_tree.py：可能将代码表示为二叉语法树，用于结构化表示。
code2ast.py：将源码转换为 AST（抽象语法树）。
collator.py：为 DataLoader 整理批处理数据（padding、mask 等）。
data_loading.py：负责数据集的读取与分割。
probe_score.py：用于打分，比如 attention 分数、概率。
utils.py：常规工具，比如格式转换、路径管理等。
see.txt：调试中间输出，比如函数对比、错行查看等。
这些工具模块在 line_probe.py、do_probe_explain.py 等主流程中都会被调用。

🔹 根目录中的主要脚本
args.py：命令行参数定义，提供参数控制接口。
build_grammars.py：构建语法规则（可能用于自定义语法处理器）。
dataset_generator.py：原始数据集加工，生成训练集/测试集。
do_probe_explain.py：执行模型解释方法，核心功能实现。
explaination_evaluation.py：解释方法的评估逻辑（IFA、Recall 等）。
line_probe.py：对代码行进行评分排序，是解释方法的核心实现。
main.py：主入口，可能执行一次完整的训练或测试流程。
run.py：可能整合整个流程：数据加载 → 模型加载 → 推理 → 解释 → 评估。
test.py：测试脚本或单元测试，用于验证各模块功能是否正确。
"""

