#!/bin/bash

python bert.py \
  --model_name=model_00.bin \
  --output_dir=. \
  --model_type=roberta \
  --tokenizer_name=microsoft/codebert-base \
  --model_name_or_path=microsoft/codebert-base \
  --do_train \
  --do_test \
  --do_explaination \
  --train_data_file=/tmp/pycharm_project_573/VulProbe-main/src/resource/dataset/python/train/train.jsonl \
  --eval_data_file=/tmp/pycharm_project_573/VulProbe-main/src/resource/dataset/python/valid/valid.jsonl\
  --test_data_file=/tmp/pycharm_project_573/VulProbe-main/src/resource/dataset/python/test/test.jsonl \
  --epochs 20 \
  --block_size 512 \
  --train_batch_size 16 \
  --eval_batch_size 16 \
  --learning_rate 2e-5 \
  --max_grad_norm 1.0 \
  --evaluate_during_training \
  --seed 00\
  --explaination_method all \
  --explaination_path_dir /tmp/pycharm_project_573/VulProbe-main/src/resource/firstStepModels/BERT

#for seed in 00 11 22 33 44; do
#    python bert.py \
#        --model_name=model_${seed}.bin \
#        --seed ${seed} \
#        --explaination_path_dir /tmp/pycharm_project_420/VulProbe-main/src/resource/firstStepModels/BERT/seed${seed} \
#        # 其他参数保持不变
#done