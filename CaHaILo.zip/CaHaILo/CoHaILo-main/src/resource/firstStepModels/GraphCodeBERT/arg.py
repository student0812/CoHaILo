from dataclasses import dataclass, field
from typing import Optional


@dataclass
class Arguments:
    do_train: bool = field(
        default=False, metadata={'help': 'Train the model.'}
    )
    do_test: bool = field(
        default=False, metadata={'help': 'Test the model.'}
    )
    do_other_explain: bool = field(
        default=False, metadata={'help': 'Perform other explain methods.'}
    )
    explain_method: Optional[str] = field(
        default=None, metadata={'help': 'Method for explanation', 'choices': ['attention', 'saliency', 'deeplift_shap', 'gradient_shap', 'all']}
    )
    explaination_method: Optional[str] = field(
        default=None, metadata={'help': 'Method for explanation (alternative name)', 'choices': ['attention', 'saliency', 'deeplift_shap', 'gradient_shap', 'all']}
    )
    explaination_path_dir: Optional[str] = field(
        default=None, metadata={'help': 'Directory path for explanation files'}
    )

    train_data_path: Optional[str] = field(
        default=None, metadata={'help': 'Path to the training data file'}
    )
    eval_data_path: Optional[str] = field(
        default=None, metadata={'help': 'Path to the evaluation data file'}
    )
    test_data_path: Optional[str] = field(
        default=None, metadata={'help': 'Path to the test data file'}
    )

    seed: int = field(
        default=42, metadata={'help': 'Random seed for initialization'}
    )
    model_path: Optional[str] = field(
        default=None, metadata={'help': 'The model checkpoint for weights initialization'}
    )
    config_name: str = field(
        default="", metadata={'help': 'Optional pretrained config path'}
    )
    tokenizer_name: str = field(
        default="", metadata={'help': 'Optional pretrained tokenizer path'}
    )
    saved_dir: Optional[str] = field(
        default=None, metadata={'help': 'The directory to save the model checkpoint'}
    )
    backbone_model_type: str = field(
        default="graphcodebert", metadata={'help': 'The model type to be used'}
    )
    bin_name: str = field(
        default="model.bin", metadata={'help': 'The name of the model binary file'}
    )
    
    # Compatibility parameters for old-style run.sh
    model_name: Optional[str] = field(
        default=None, metadata={'help': 'Model name (compatibility)'}
    )
    output_dir: Optional[str] = field(
        default=None, metadata={'help': 'Output directory (compatibility)'}
    )
    model_type: Optional[str] = field(
        default=None, metadata={'help': 'Model type (compatibility)'}
    )
    model_name_or_path: Optional[str] = field(
        default=None, metadata={'help': 'Model path (compatibility)'}
    )
    train_data_file: Optional[str] = field(
        default=None, metadata={'help': 'Train data file (compatibility)'}
    )
    eval_data_file: Optional[str] = field(
        default=None, metadata={'help': 'Eval data file (compatibility)'}
    )
    test_data_file: Optional[str] = field(
        default=None, metadata={'help': 'Test data file (compatibility)'}
    )
    train_batch_size: Optional[int] = field(
        default=None, metadata={'help': 'Train batch size (compatibility)'}
    )
    eval_batch_size: Optional[int] = field(
        default=None, metadata={'help': 'Eval batch size (compatibility)'}
    )
    do_explaination: Optional[bool] = field(
        default=None, metadata={'help': 'Do explanation (compatibility)'}
    )
    evaluate_during_training: Optional[bool] = field(
        default=None, metadata={'help': 'Evaluate during training (compatibility)'}
    )
    test_results_path: Optional[str] = field(
        default='results/detection', metadata={'help': 'Path to save the test results'}
    )
    localization_results_path: Optional[str] = field(
        default='results/localization',
        metadata={'help': 'Path to save the localization results.'}
    )

    batch_size: int = field(
        default=16, metadata={'help': 'Batch size for training and evaluation'}
    )
    block_size: int = field(
        default=512, metadata={'help': 'Block size for input sequences'}
    )
    learning_rate: float = field(
        default=2e-5, metadata={'help': 'Learning rate for the optimizer'}
    )
    epochs: int = field(
        default=5, metadata={'help': 'Number of training epochs'}
    )
    max_grad_norm: float = field(
        default=1.0, metadata={'help': 'Maximum gradient norm'}
    )
    weight_decay: float = field(
        default=1e-5, metadata={'help': 'Weight decay for the optimizer'}
    )
    adam_epsilon: float = field(
        default=1e-8, metadata={'help': 'Epsilon for the Adam optimizer'}
    )
    gradient_accumulation_steps: int = field(
        default=1, metadata={'help': 'Number of steps to accumulate gradients'}
    )

    device_ids: Optional[str] = field(
        default=None, metadata={'help': 'Comma separated GPU device ids, e.g., "0,1"'}
    )


def get_device_ids(device_ids):
    if device_ids is None:
        return None
    return [int(x) for x in device_ids.split(',') if x.strip() != '']