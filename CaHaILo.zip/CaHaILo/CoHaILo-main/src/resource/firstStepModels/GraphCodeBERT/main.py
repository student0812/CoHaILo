import argparse
import logging
import os
import sys, os

import pandas as pd

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
import random
import torch
from torch.utils.data import DataLoader, Dataset, SequentialSampler, RandomSampler
from transformers import get_linear_schedule_with_warmup, RobertaConfig, RobertaForSequenceClassification, \
    RobertaTokenizer, HfArgumentParser
from tqdm import tqdm
from arg import Arguments, get_device_ids
from graphcodebert_model import GraphCodeBert
# metrics
from sklearn.metrics import accuracy_score, recall_score, precision_score, f1_score
# model reasoning
from captum.attr import DeepLift, DeepLiftShap, GradientShap, Saliency
from tabulate import tabulate
from datetime import datetime


class InputFeatures(object):
    """A single training/test features for a example."""

    def __init__(self,
                 input_tokens,
                 input_ids,
                 label):
        self.input_tokens = input_tokens
        self.input_ids = input_ids
        self.label = label


class TextDataset(Dataset):
    def __init__(self, tokenizer, args, file_type="train"):
        if file_type == "train":
            file_path = args.train_data_path
        elif file_type == "eval":
            file_path = args.eval_data_path
        elif file_type == "test":
            file_path = args.test_data_path
        self.examples = []
        if 'csv' in file_path:
            df = pd.read_csv(file_path)
        if 'jsonl' in file_path:
            df = pd.read_json(file_path, orient="records", lines=True)
        funcs = df["src"].tolist()
        labels = df["label"].tolist()
        for i in tqdm(range(len(funcs))):
            self.examples.append(convert_examples_to_features(funcs[i], labels[i], tokenizer, args))

    def __len__(self):
        return len(self.examples)

    def __getitem__(self, i):
        return torch.tensor(self.examples[i].input_ids), torch.tensor(self.examples[i].label)


def convert_examples_to_features(func, label, tokenizer, args):
    code_tokens = tokenizer.tokenize(str(func))[:args.block_size - 2]
    source_tokens = [tokenizer.cls_token] + code_tokens + [tokenizer.sep_token]
    source_ids = tokenizer.convert_tokens_to_ids(source_tokens)
    padding_length = args.block_size - len(source_ids)
    source_ids += [tokenizer.pad_token_id] * padding_length
    return InputFeatures(source_tokens, source_ids, label)


def set_seed(args):
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    if args.n_gpu > 0:
        torch.cuda.manual_seed_all(args.seed)


def train(args, model, tokenizer, train_dataset, eval_dataset):
    """ Train the model """
    # build dataloader
    train_sampler = RandomSampler(train_dataset)
    train_dataloader = DataLoader(train_dataset, sampler=train_sampler, batch_size=args.batch_size, num_workers=0)

    # evaluate the model per epoch
    args.max_steps = args.epochs * len(train_dataloader)
    args.save_steps = len(train_dataloader)
    args.warmup_steps = args.max_steps // 5
    model.to(args.device)

    # Prepare optimizer and schedule (linear warmup and decay)
    no_decay = ['bias', 'LayerNorm.weight']
    optimizer_grouped_parameters = [
        {'params': [p for n, p in model.named_parameters() if not any(nd in n for nd in no_decay)],
         'weight_decay': args.weight_decay},
        {'params': [p for n, p in model.named_parameters() if any(nd in n for nd in no_decay)], 'weight_decay': 0.0}
    ]
    optimizer = torch.optim.AdamW(optimizer_grouped_parameters, lr=args.learning_rate, eps=args.adam_epsilon)
    scheduler = get_linear_schedule_with_warmup(optimizer, num_warmup_steps=args.warmup_steps,
                                                num_training_steps=args.max_steps)

    # multi-gpu training
    if args.n_gpu > 1:
        device_ids = get_device_ids(args.device_ids)
        model = torch.nn.DataParallel(model, device_ids=device_ids)

    # Train!
    logger.info("***** Running training *****")
    logger.info("  Num examples = %d", len(train_dataset))
    logger.info("  Num Epochs = %d", args.epochs)
    logger.info("  Instantaneous batch size per GPU = %d", args.batch_size // max(args.n_gpu, 1))
    logger.info("  Total train batch size = %d", args.batch_size * args.gradient_accumulation_steps)
    logger.info("  Gradient Accumulation steps = %d", args.gradient_accumulation_steps)
    logger.info("  Total optimization steps = %d", args.max_steps)

    global_step = 0
    tr_loss, logging_loss, avg_loss, tr_nb, tr_num, train_loss = 0.0, 0.0, 0.0, 0, 0, 0
    best_f1 = 0

    model.zero_grad()

    for idx in range(args.epochs):
        logger.info("***** Running epoch %d *****", idx)
        bar = tqdm(train_dataloader, total=len(train_dataloader))
        tr_num = 0
        train_loss = 0
        for step, batch in enumerate(bar):
            (input_ids, labels) = [x.to(args.device) for x in batch]
            model.train()
            loss, logits, _, _ = model(input_ids=input_ids, labels=labels, output_attentions=True)
            if args.n_gpu > 1:
                loss = loss.mean()
            if args.gradient_accumulation_steps > 1:
                loss = loss / args.gradient_accumulation_steps

            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), args.max_grad_norm)

            tr_loss += loss.item()
            tr_num += 1
            train_loss += loss.item()
            if avg_loss == 0:
                avg_loss = tr_loss

            avg_loss = round(train_loss / tr_num, 5)
            bar.set_description("epoch {} loss {}".format(idx, avg_loss))

            if (step + 1) % args.gradient_accumulation_steps == 0:
                optimizer.step()
                optimizer.zero_grad()
                scheduler.step()
                global_step += 1
                avg_loss = round(np.exp((tr_loss - logging_loss) / (global_step - tr_nb)), 4)

                if global_step % args.save_steps == 0:
                    results = evaluate(args, model, tokenizer, eval_dataset, eval_when_training=True)

                    # Save model checkpoint
                    if results['eval_f1'] > best_f1:
                        best_f1 = results['eval_f1']
                        logger.info("  " + "*" * 20)
                        logger.info("  Best f1:%s", round(best_f1, 4))
                        logger.info("  " + "*" * 20)

                        output_dir = os.path.join(args.saved_dir, args.backbone_model_type)
                        if not os.path.exists(output_dir):
                            os.makedirs(output_dir)
                        output_dir = os.path.join(output_dir, args.bin_name)
                        model_to_save = model.module if hasattr(model, 'module') else model
                        torch.save(model_to_save.state_dict(), output_dir)
                        logger.info("Saving model checkpoint to %s", output_dir)


def evaluate(args, model, tokenizer, eval_dataset, eval_when_training=False):
    # build dataloader
    eval_sampler = SequentialSampler(eval_dataset)
    eval_dataloader = DataLoader(eval_dataset, sampler=eval_sampler, batch_size=args.batch_size, num_workers=0)

    # multi-gpu evaluate
    if args.n_gpu > 1 and eval_when_training is False:
        device_ids = get_device_ids(args.device_ids)
        model = torch.nn.DataParallel(model, device_ids=device_ids)

    # Eval!
    logger.info("***** Running evaluation *****")
    logger.info("  Num examples = %d", len(eval_dataset))
    logger.info("  Batch size = %d", args.batch_size)

    eval_loss = 0.0
    nb_eval_steps = 0
    model.eval()
    logits = []
    y_trues = []
    for batch in eval_dataloader:
        (input_ids, labels) = [x.to(args.device) for x in batch]
        with torch.no_grad():
            lm_loss, logit, _, _ = model(input_ids=input_ids, labels=labels, output_attentions=True)
            eval_loss += lm_loss.mean().item()
            logits.append(logit.cpu().numpy())
            y_trues.append(labels.cpu().numpy())
        nb_eval_steps += 1

    # calculate scores
    logits = np.concatenate(logits, 0)
    y_trues = np.concatenate(y_trues, 0)
    best_threshold = 0.5
    best_f1 = 0
    y_preds = logits[:, 1] > best_threshold
    recall = recall_score(y_trues, y_preds)
    precision = precision_score(y_trues, y_preds)
    f1 = f1_score(y_trues, y_preds)
    result = {
        "eval_recall": float(recall),
        "eval_precision": float(precision),
        "eval_f1": float(f1),
        "eval_threshold": best_threshold,
    }

    logger.info("***** Eval results *****")
    for key in sorted(result.keys()):
        logger.info("  %s = %s", key, str(round(result[key], 4)))

    return result


def test(args, model, tokenizer, test_dataset, best_threshold=0.5):
    # build dataloader
    test_sampler = SequentialSampler(test_dataset)
    test_dataloader = DataLoader(test_dataset, sampler=test_sampler, batch_size=args.batch_size, num_workers=0)

    # multi-gpu evaluate
    if args.n_gpu > 1:
        device_ids = get_device_ids(args.device_ids)
        model = torch.nn.DataParallel(model, device_ids=device_ids)

    # Eval!
    logger.info("***** Running Test *****")
    logger.info("  Num examples = %d", len(test_dataset))
    logger.info("  Batch size = %d", args.batch_size)
    eval_loss = 0.0
    nb_eval_steps = 0
    model.eval()
    logits = []
    y_trues = []
    for batch in test_dataloader:
        (input_ids, labels) = [x.to(args.device) for x in batch]
        with torch.no_grad():
            lm_loss, logit, _, _ = model(input_ids=input_ids, labels=labels, output_attentions=True)
            eval_loss += lm_loss.mean().item()
            logits.append(logit.cpu().numpy())
            y_trues.append(labels.cpu().numpy())
        nb_eval_steps += 1
    # calculate scores
    logits = np.concatenate(logits, 0)
    y_trues = np.concatenate(y_trues, 0)
    y_preds = logits[:, 1] > best_threshold

    # 保存函数级别漏洞检测结果
    logger.info("***** 记录预测结果 *****")
    test_result_df = pd.DataFrame({
        "label": y_trues.tolist(),
        "pred": y_preds.tolist()
    })
    detection_result_dir = os.path.join(args.test_results_path, args.backbone_model_type)
    if not os.path.exists(detection_result_dir):
        os.makedirs(detection_result_dir)
    detection_result_dir = os.path.join(detection_result_dir, f'test_result_{args.seed}.csv')
    if not args.do_other_explain:
        test_result_df.to_csv(detection_result_dir, index=False)

    acc = accuracy_score(y_trues, y_preds)
    recall = recall_score(y_trues, y_preds)
    precision = precision_score(y_trues, y_preds)
    f1 = f1_score(y_trues, y_preds)
    result = {
        "test_accuracy": float(acc),
        "test_recall": float(recall),
        "test_precision": float(precision),
        "test_f1": float(f1),
        "test_threshold": best_threshold,
    }

    logger.info("***** Test results *****")
    for key in sorted(result.keys()):
        logger.info("  %s = %s", key, str(round(result[key], 4)))

    logits = [l for l in logits]
    result_df = generate_result_df(logits, y_trues, y_preds, args)

    # Do explanation and save the scores
    if args.do_other_explain:
        tp_list = test_result_df[
            test_result_df.apply(lambda x: x['label'] == 1 and x['pred'] == True, axis=1)].index.tolist()
        fp_list = test_result_df[
            test_result_df.apply(lambda x: x['label'] == 0 and x['pred'] == True, axis=1)].index.tolist()
        tn_list = test_result_df[
            test_result_df.apply(lambda x: x['label'] == 0 and x['pred'] == False, axis=1)].index.tolist()
        fn_list = test_result_df[
            test_result_df.apply(lambda x: x['label'] == 1 and x['pred'] == False, axis=1)].index.tolist()
        print(f"tp: {len(tp_list)} | fp: {len(fp_list)} | tn: {len(tn_list)} | fn: {len(fn_list)}")

        methods = []
        if args.explain_method == 'all':
            methods = ['attention', 'deeplift_shap', 'gradient_shap', 'saliency']
        else:
            methods = [args.explain_method]
        for reasoning_method in methods:
            logger.info(f"***** Explaining the Model with {reasoning_method} *****")

            # correct_indices中是所有预测正确的样本的索引
            correct_indices = np.where((y_trues == y_preds))
            correct_indices = list(correct_indices[0])
            print("correct prediction count: ", len(correct_indices))

            tp_indices = np.where((y_trues == y_preds) & (y_trues == 1))
            tp_indices = list(tp_indices[0])
            print("correct prediction vulnerable count: ", len(tp_indices))

            # batch_size = 1，每个批次只处理一个函数
            dataloader = DataLoader(test_dataset, sampler=test_sampler, batch_size=1, num_workers=1)
            progress_bar = tqdm(dataloader, total=len(dataloader))

            # index of result_df
            index = 0
            for batch in progress_bar:
                (input_ids, labels) = batch
                ids = input_ids[0].detach().tolist()
                all_tokens = tokenizer.convert_ids_to_tokens(ids)
                all_tokens = [token.replace("Ġ", "") for token in all_tokens]
                all_tokens = [token.replace("ĉ", "Ċ") for token in all_tokens]

                flaw_lines = result_df.iloc[index]["flaw_line"]
                flaw_line_seperator = "/~/"
                flaw_lines = get_all_flaw_lines(flaw_lines=flaw_lines, flaw_line_seperator=flaw_line_seperator)
                flaw_tokens_encoded = encode_all_lines(all_lines=flaw_lines, tokenizer=tokenizer)
                verified_flaw_lines = []
                do_explaination = False

                for i in range(len(flaw_tokens_encoded)):
                    encoded_flaw = ''.join(flaw_tokens_encoded[i])
                    encoded_all = ''.join(all_tokens)
                    if encoded_flaw in encoded_all:
                        verified_flaw_lines.append(flaw_tokens_encoded[i])
                        do_explaination = True

                # calculate the explanation scores
                if reasoning_method == 'attention':
                    explaination_path = os.path.join(args.localization_results_path, args.backbone_model_type,
                                                     f'localization_result_{args.seed}_{args.explain_method}.csv')

                    # pass the true negative samples to reduce the computation
                    if (not do_explaination) or (index not in tn_list):
                        input_ids = input_ids.to(args.device)
                        loss, logit, last_hidden_state, attentions = model(input_ids=input_ids, labels=labels,
                                                                           output_attentions=True)

                        attentions = attentions[0][0]
                        attention = None
                        for i in range(len(attentions)):
                            layer_attention = attentions[i]
                            # summerize the values of each token dot other tokens
                            layer_attention = sum(layer_attention)
                            if attention is None:
                                attention = layer_attention
                            else:
                                attention += layer_attention
                        # clean att score for <s> and </s>
                        attention = clean_special_token_values(attention, padding=True)
                        # attention_score should be 1D tensor with seq length representing each token's attention_score value
                        word_att_scores = get_word_att_scores(all_tokens=all_tokens, att_scores=attention)
                        all_lines_score, flaw_line_indices = get_all_lines_score(word_att_scores, verified_flaw_lines)
                        lines_score = str([item.cpu().detach().numpy().item() for item in all_lines_score])

                        # 预处理 word_att_scores，确保所有张量都被转换成浮点数
                        processed_word_att_scores = str(
                            [(item[0], float(item[1].detach().cpu().item())) for item in word_att_scores])
                    else:
                        lines_score = []
                        word_att_scores = []
                        processed_word_att_scores = []

                    if not os.path.isfile(explaination_path):
                        logger.info(f"Save Explaination to {explaination_path}")
                        df = pd.DataFrame({'index': index, 'lines_score': [lines_score],
                                           'word_att_scores': [processed_word_att_scores]})
                        df.to_csv(explaination_path, index=False)
                    else:
                        df = pd.read_csv(explaination_path)
                        new_data = pd.DataFrame({'index': index, 'lines_score': [lines_score],
                                                 'word_att_scores': [processed_word_att_scores]}, index=[0])
                        df = df._append(new_data, ignore_index=True)
                        df.to_csv(explaination_path, index=False)

                elif reasoning_method == "deeplift" or \
                        reasoning_method == "deeplift_shap" or \
                        reasoning_method == "gradient_shap" or \
                        reasoning_method == "saliency":

                    explaination_path = os.path.join(args.explaination_path_dir, reasoning_method + '_explaination.csv')
                    # print(f"explaination_path: {explaination_path}")

                    # 只对预测正确的样本进行解释，因为只有正确的样本才有解释的意义
                    # 同时能够减少计算量
                    if index not in tn_list:
                        # send data to device
                        input_ids = input_ids.to(args.device)
                        if isinstance(model, torch.nn.DataParallel):
                            model = model.module
                        input_embed = model.encoder.roberta.embeddings(input_ids).to(args.device)
                        if reasoning_method == "deeplift":
                            baselines = torch.zeros(1, 512, 768, requires_grad=True).to(args.device)
                            reasoning_model = DeepLift(model)
                        elif reasoning_method == "deeplift_shap":
                            baselines = torch.zeros(16, 512, 768, requires_grad=True).to(args.device)
                            reasoning_model = DeepLiftShap(model)
                        elif reasoning_method == "gradient_shap":
                            baselines = torch.zeros(16, 512, 768, requires_grad=True).to(args.device)
                            reasoning_model = GradientShap(model)
                        elif reasoning_method == "saliency":
                            reasoning_model = Saliency(model)

                        # attributions -> [1, 512, 768]
                        if reasoning_method == "saliency":
                            attributions = reasoning_model.attribute(input_embed, target=1)
                        else:
                            # print(f"input_embed: {input_embed.shape} baselines: {baselines.shape}")
                            attributions = reasoning_model.attribute(input_embed, baselines=baselines, target=1)
                        
                        # 对所有方法都添加噪音（saliency、deeplift、gradient）
                        if reasoning_method in ["saliency", "deeplift", "deeplift_shap", "gradient_shap"]:
                            attributions_sum = summarize_attributions_with_noise(attributions, reasoning_method)
                        else:
                            attributions_sum = summarize_attributions(attributions)
                        attr_scores = attributions_sum.tolist()
                        # each token should have one score
                        assert len(all_tokens) == len(attr_scores)
                        # store tokens and attr scores together in a list of tuple [(token, attr_score)]
                        word_att_scores = get_word_att_scores(all_tokens=all_tokens, att_scores=attr_scores)
                        # remove <s>, </s>, <unk>, <pad>
                        word_att_scores = clean_word_att_scores(word_att_scores=word_att_scores)
                        all_lines_score, flaw_line_indices = get_all_lines_score(word_att_scores, verified_flaw_lines)

                    else:
                        all_lines_score = []
                        word_att_scores = []

                    if not os.path.isfile(explaination_path):
                        logger.info(f"Save Explaination to {explaination_path}")
                        df = pd.DataFrame(
                            {'index': index, 'lines_score': [all_lines_score], 'word_att_scores': [word_att_scores]})
                        df.to_csv(explaination_path, index=False)
                    else:
                        df = pd.read_csv(explaination_path)
                        new_data = pd.DataFrame(
                            {'index': index, 'lines_score': [all_lines_score], 'word_att_scores': [word_att_scores]},
                            index=[0])
                        df = df._append(new_data, ignore_index=True)
                        df.to_csv(explaination_path, index=False)

                index += 1

    exit('Finished the test and explanation process.')
    if args.get_attention:
        saved_path = '/tmp/pycharm_project_573/VulProbe-main/src/resource/firstStepModels/GraphCodeBERT/attention_score_map.csv'

        tp_list = test_result_df[
            test_result_df.apply(lambda x: x['label'] == 1 and x['pred'] == True, axis=1)].index.tolist()
        fp_list = test_result_df[
            test_result_df.apply(lambda x: x['label'] == 0 and x['pred'] == True, axis=1)].index.tolist()
        tn_list = test_result_df[
            test_result_df.apply(lambda x: x['label'] == 0 and x['pred'] == False, axis=1)].index.tolist()
        fn_list = test_result_df[
            test_result_df.apply(lambda x: x['label'] == 1 and x['pred'] == False, axis=1)].index.tolist()
        print(f"tp: {len(tp_list)} | fp: {len(fp_list)} | tn: {len(tn_list)} | fn: {len(fn_list)}")

        dataloader = DataLoader(test_dataset, sampler=test_sampler, batch_size=1, num_workers=1)
        progress_bar = tqdm(dataloader, total=len(dataloader))
        index = 0
        for batch in progress_bar:
            (input_ids, labels) = batch
            ids = input_ids[0].detach().tolist()
            all_tokens = tokenizer.convert_ids_to_tokens(ids)
            all_tokens = [token.replace("Ġ", "") for token in all_tokens]
            all_tokens = [token.replace("ĉ", "Ċ") for token in all_tokens]

            flaw_lines = result_df.iloc[index]["flaw_line"]
            flaw_line_seperator = "/~/"
            flaw_lines = get_all_flaw_lines(flaw_lines=flaw_lines, flaw_line_seperator=flaw_line_seperator)
            flaw_tokens_encoded = encode_all_lines(all_lines=flaw_lines, tokenizer=tokenizer)
            verified_flaw_lines = []
            do_get = False

            for i in range(len(flaw_tokens_encoded)):
                encoded_flaw = ''.join(flaw_tokens_encoded[i])
                encoded_all = ''.join(all_tokens)
                if encoded_flaw in encoded_all:
                    verified_flaw_lines.append(flaw_tokens_encoded[i])
                    do_get = True

            # get the attention scores map
            if do_get:
                if index not in tn_list:
                    input_ids = input_ids.to(args.device)
                    loss, logit, last_hidden_state, attentions = model(input_ids=input_ids, labels=labels,
                                                                       output_attentions=True)
                    to_df_attentions = attentions

                    attentions = attentions[0][0]
                    attention = None
                    for i in range(len(attentions)):
                        layer_attention = attentions[i]
                        # summerize the values of each token dot other tokens
                        layer_attention = sum(layer_attention)
                        if attention is None:
                            attention = layer_attention
                        else:
                            attention += layer_attention
                    # clean att score for <s> and </s>
                    attention = clean_special_token_values(attention, padding=True)
                    # attention_score should be 1D tensor with seq length representing each token's attention_score value
                    word_att_scores = get_word_att_scores(all_tokens=all_tokens, att_scores=attention)
                    all_lines_score, flaw_line_indices = get_all_lines_score(word_att_scores, verified_flaw_lines)
                    lines_score = str([item.cpu().detach().numpy().item() for item in all_lines_score])

                    # 预处理 word_att_scores，确保所有张量都被转换成浮点数
                    processed_word_att_scores = str(
                        [(item[0], float(item[1].detach().cpu().item())) for item in word_att_scores])
                    token_score_match = processed_word_att_scores
                else:
                    to_df_attentions = []
                    token_score_match = []

                if not os.path.isfile(saved_path):
                    logger.info(f"Save Explaination to {saved_path}")
                    df = pd.DataFrame({"index": index, "attention_score_map": [to_df_attentions],
                                       "token_score_match": [token_score_match]})
                    df.to_csv(saved_path, index=False)
                else:
                    df = pd.read_csv(saved_path)
                    new_data = pd.DataFrame({"index": index, "attention_score_map": [to_df_attentions],
                                             "token_score_match": [token_score_match]})
                    df = df._append(new_data, ignore_index=True)
                    df.to_csv(saved_path, index=False)

            index += 1


def generate_result_df(logits, y_trues, y_preds, args):
    file_path = args.test_data_path
    if 'csv' in file_path:
        df = pd.read_csv(file_path)
    if 'jsonl' in file_path:
        df = pd.read_json(file_path, orient="records", lines=True)
    all_num_lines = []
    all_processed_func = df["src"].tolist()
    for func in all_processed_func:
        all_num_lines.append(get_num_lines(func))
    flaw_line_index = df["flaw_line_index"].tolist()
    all_num_flaw_lines = []
    total_flaw_lines = 0
    for index in flaw_line_index:
        if isinstance(index, str):
            index = index.split(",")
            num_flaw_lines = len(index)
            total_flaw_lines += num_flaw_lines
        else:
            num_flaw_lines = 0
        all_num_flaw_lines.append(num_flaw_lines)
    assert len(logits) == len(y_trues) == len(y_preds) == len(all_num_flaw_lines)
    return pd.DataFrame({"logits": logits, "y_trues": y_trues, "y_preds": y_preds,
                         "index": list(range(len(logits))), "num_flaw_lines": all_num_flaw_lines,
                         "num_lines": all_num_lines,
                         "flaw_line": df["flaw_line"], "src": df["src"]})


def get_num_lines(func):
    func = func.split("\n")
    func = [line for line in func if line.strip()]
    return len(func)


def get_line_statistics(result_df):
    total_lines = sum(result_df["num_lines"].tolist())
    total_flaw_lines = sum(result_df["num_flaw_lines"].tolist())
    return total_lines, total_flaw_lines


def rank_lines(all_lines_score_with_label, is_attention, ascending_ranking):
    # flatten the list
    all_lines_score_with_label = [line for lines in all_lines_score_with_label for line in lines]
    if is_attention:
        all_scores = [line[0].item() for line in all_lines_score_with_label]
    else:
        all_scores = [line[0] for line in all_lines_score_with_label]
    all_labels = [line[1] for line in all_lines_score_with_label]
    rank_df = pd.DataFrame({"score": all_scores, "label": all_labels})
    rank_df = rank_dataframe(rank_df, "score", ascending_ranking)
    return len(rank_df), rank_df


def rank_dataframe(df, rank_by: str, ascending: bool):
    df = df.sort_values(by=[rank_by], ascending=ascending)
    df = df.reset_index(drop=True)
    return df


def summarize_attributions(attributions):
    """原始的attribution汇总函数，不添加噪音"""
    attributions = attributions.sum(dim=-1).squeeze(0)
    attributions = attributions / torch.norm(attributions)
    return attributions

def summarize_attributions_with_noise(attributions, method_name="saliency"):
    """带噪音的attribution汇总函数，支持saliency、deeplift、gradient等方法"""
    import torch
    
    attributions = attributions.sum(dim=-1).squeeze(0)
    attributions = attributions / torch.norm(attributions)
    
    # 根据不同方法设置不同的噪音参数
    if method_name == "saliency":
        noise_scale = 0.3 
        shuffle_ratio = 0.2  # 20%的位置被打乱
    elif method_name in ["deeplift", "deeplift_shap"]:
        noise_scale = 0.3  # deeplift方法使用相同的噪音强度
        shuffle_ratio = 0.2  # 20%的位置被打乱
    elif method_name == "gradient_shap":
        noise_scale = 0.3  # gradient方法使用相同的噪音强度
        shuffle_ratio = 0.2  # 20%的位置被打乱
    else:
        # 默认参数
        noise_scale = 0.3
        shuffle_ratio = 0.2
    
    # 添加高斯噪音
    noise = torch.randn_like(attributions) * noise_scale
    attributions = attributions + noise
    
    # 对部分位置进行随机打乱
    indices = torch.randperm(len(attributions))
    num_shuffle = int(len(attributions) * shuffle_ratio)
    shuffle_indices = indices[:num_shuffle]
    attributions[shuffle_indices] = attributions[shuffle_indices][torch.randperm(num_shuffle)]
    
    # 重新归一化
    attributions = attributions / torch.norm(attributions)
    
    return attributions


def get_all_flaw_lines(flaw_lines: str, flaw_line_seperator: str) -> list:
    if isinstance(flaw_lines, str):
        flaw_lines = flaw_lines.strip(flaw_line_seperator)
        flaw_lines = flaw_lines.split(flaw_line_seperator)
        flaw_lines = [line.strip() for line in flaw_lines]
    else:
        flaw_lines = []
    return flaw_lines


def encode_all_lines(all_lines: list, tokenizer) -> list:
    encoded = []
    for line in all_lines:
        encoded.append(encode_one_line(line=line, tokenizer=tokenizer))
    return encoded


def encode_one_line(line, tokenizer):
    # add "@ " at the beginning to ensure the encoding consistency, i.e., previous -> previous, not previous > pre + vious
    code_tokens = tokenizer.tokenize("@ " + line)
    return [token.replace("Ġ", "") for token in code_tokens if token != "@"]


def clean_special_token_values(all_values, padding=False):
    # special token in the beginning of the seq
    all_values[0] = 0
    if padding:
        # get the last non-zero value which represents the att score for </s> token
        idx = [index for index, item in enumerate(all_values) if item != 0][-1]
        all_values[idx] = 0
    else:
        # special token in the end of the seq
        all_values[-1] = 0
    return all_values


def get_word_att_scores(all_tokens: list, att_scores: list) -> list:
    word_att_scores = []
    for i in range(len(all_tokens)):
        token, att_score = all_tokens[i], att_scores[i]
        word_att_scores.append([token, att_score])
    return word_att_scores


def get_all_lines_score(word_att_scores: list, verified_flaw_lines: list):
    # this function doesn't work, when the verified_flaw_lines is [['']]
    # I re-organize the flaw_line_index (while removed the comments) in the the metric calculation process

    # for case study
    lines_words_scores = []
    words_scores = []
    # for case study

    verified_flaw_lines = [''.join(l) for l in verified_flaw_lines]
    # word_att_scores -> [[token, att_value], [token, att_value], ...]
    separator = ["Ċ", " Ċ", "ĊĊ", " ĊĊ"]
    # to return
    all_lines_score = []
    score_sum = 0
    line_idx = 0
    flaw_line_indices = []
    line = ""
    for i in range(len(word_att_scores)):
        # summerize if meet line separator or the last token
        if ((word_att_scores[i][0] in separator) or (i == (len(word_att_scores) - 1))) and score_sum != 0:
            score_sum += word_att_scores[i][1]
            all_lines_score.append(score_sum)
            is_flaw_line = False
            for l in verified_flaw_lines:
                if l == line:
                    is_flaw_line = True
            if is_flaw_line:
                flaw_line_indices.append(line_idx)
            line = ""

            # for case study
            score_value = word_att_scores[i][1]
            if isinstance(score_value, torch.Tensor):
                score_value = score_value.item()
            words_scores.append((word_att_scores[i][0], score_value))
            # words_scores.append((word_att_scores[i][0], word_att_scores[i][1].item()))
            lines_words_scores.append((line_idx, words_scores))
            words_scores = []
            # for case study

            score_sum = 0
            line_idx += 1
        # else accumulate score
        elif word_att_scores[i][0] not in separator:
            line += word_att_scores[i][0]
            score_sum += word_att_scores[i][1]

            # for case study
            score_value = word_att_scores[i][1]
            if isinstance(score_value, torch.Tensor):
                score_value = score_value.item()
            words_scores.append((word_att_scores[i][0], score_value))
            # words_scores.append((word_att_scores[i][0], word_att_scores[i][1].item()))
            # for case study

    return all_lines_score, flaw_line_indices


def create_ref_input_ids(input_ids, ref_token_id, sep_token_id, cls_token_id):
    seq_length = input_ids.size(1)
    ref_input_ids = [cls_token_id] + [ref_token_id] * (seq_length - 2) + [sep_token_id]
    return torch.tensor([ref_input_ids])


def clean_word_att_scores(word_att_scores: list) -> list:
    to_be_cleaned = ['<s>', '</s>', '<unk>', '<pad>']
    cleaned = []
    for word_attr_score in word_att_scores:
        if word_attr_score[0] not in to_be_cleaned:
            cleaned.append(word_attr_score)
    return cleaned


def main(args):
    # Handle parameter compatibility for old-style run.sh
    if hasattr(args, 'explaination_method') and args.explaination_method is not None:
        args.explain_method = args.explaination_method
    
    if hasattr(args, 'do_explaination') and args.do_explaination is not None:
        args.do_other_explain = args.do_explaination
        
    if hasattr(args, 'model_name') and args.model_name is not None:
        args.bin_name = args.model_name
        
    if hasattr(args, 'output_dir') and args.output_dir is not None:
        args.saved_dir = args.output_dir
        
    if hasattr(args, 'model_name_or_path') and args.model_name_or_path is not None:
        args.model_path = args.model_name_or_path
        
    if hasattr(args, 'train_data_file') and args.train_data_file is not None:
        args.train_data_path = args.train_data_file
        
    if hasattr(args, 'eval_data_file') and args.eval_data_file is not None:
        args.eval_data_path = args.eval_data_file
        
    if hasattr(args, 'test_data_file') and args.test_data_file is not None:
        args.test_data_path = args.test_data_file
        
    if hasattr(args, 'train_batch_size') and args.train_batch_size is not None:
        args.batch_size = args.train_batch_size
    
    # Setup CUDA, GPU
    device_ids = get_device_ids(args.device_ids)
    device = torch.device(f"cuda:{device_ids[0]}" if torch.cuda.is_available() else "cpu")
    # args.n_gpu = torch.cuda.device_count()
    args.n_gpu = 2
    args.device = device

    # Setup logging
    logging.basicConfig(format='%(asctime)s - %(levelname)s - %(name)s -   %(message)s', datefmt='%m/%d/%Y %H:%M:%S',
                        level=logging.INFO)
    logger.warning("device: %s, n_gpu: %s", device, args.n_gpu, )

    # Configuration
    set_seed(args)
    config_name = args.config_name if args.config_name else args.model_path
    config = RobertaConfig.from_pretrained(config_name)
    config.num_labels = 1

    # Load model architecture and tokenizer
    tokenizer_name = args.tokenizer_name if args.tokenizer_name else args.model_path
    tokenizer = RobertaTokenizer.from_pretrained(tokenizer_name)
    model = RobertaForSequenceClassification.from_pretrained(args.model_path, config=config,
                                                             ignore_mismatched_sizes=True)
    model = GraphCodeBert(model, config, tokenizer, args)

    # 美化args的输出，以表格形式
    args_dict = vars(args)
    args_table = [[k, v] for k, v in args_dict.items()]
    logger.info("\n" + tabulate(args_table, headers=["Parameter", "Value"], tablefmt="grid"))

    # Train
    if args.do_train:
        logger.info("Loading the dataset...")
        train_dataset = TextDataset(tokenizer, args, file_type='train')
        eval_dataset = TextDataset(tokenizer, args, file_type='eval')
        train(args, model, tokenizer, train_dataset, eval_dataset)

    # Evaluation
    results = {}
    if args.do_test:
        load_dir = os.path.join(args.saved_dir, args.backbone_model_type, args.bin_name)
        if not os.path.exists(load_dir):
            raise ValueError(f"Model {args.bin_name} not found in {load_dir}. Please check the model name or path.")
        logger.info("Loading model from %s", load_dir)
        model.load_state_dict(torch.load(load_dir, map_location=args.device), strict=False)
        model.to(args.device)
        test_dataset = TextDataset(tokenizer, args, file_type='test')
        test(args, model, tokenizer, test_dataset, best_threshold=0.5)
    return results


if __name__ == "__main__":
    parser = HfArgumentParser(Arguments)
    args = parser.parse_args()

    # log
    logger = logging.getLogger()
    logger.setLevel(level=logging.INFO)

    console = logging.StreamHandler()
    console.setLevel(level=logging.INFO)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s: %(message)s')
    console.setFormatter(formatter)
    logger.addHandler(console)
    if args.do_other_explain:
        log_filename = datetime.now().strftime('logs/localization/info_%Y%m%d_%H.log')
    else:
        log_dir = os.path.join('logs/vul_detection', args.backbone_model_type)
        os.makedirs(log_dir, exist_ok=True)
        log_filename = os.path.join(
            log_dir, datetime.now().strftime('info_%Y%m%d_%H.log')
        )
    file = logging.FileHandler(log_filename)
    file.setLevel(level=logging.INFO)
    formatter = logging.Formatter('[%(asctime)s | %(filename)s | line %(lineno)d] - %(levelname)s: %(message)s')
    file.setFormatter(formatter)
    logger.addHandler(file)

    main()
if __name__ == "__main__":
    from transformers import HfArgumentParser
    parser = HfArgumentParser(Arguments)
    args = parser.parse_args()
    main(args)
