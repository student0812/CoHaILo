import re

from .utils import remove_comments_and_docstrings_c, remove_comments_and_docstrings_java_js
from itertools import chain
#按语言对代码行进行词法拆分（tokenize）进行模型输出结果的预处理和验证
#load_customized_ast	加载模型探针生成的 AST 文件目录
#可能会根据bert里面设定的脚本进行更改，选择生成的bin文件和csv文件，目前只生成了00文件
def line2tokens(line, lang='python'):
    if lang == 'solidity':
        pattern = r'\b(?:\d+\s)?\w+\b|==|\+\+|--|\+=|-=|&&|\|\||\!=|<=|>=|\*\*|"[^"]*"|\'[^\']*\'|[^\w\s;]'
    elif lang == 'c':
        pattern = r'\d+\.\d+|\.\d+|\b(?:\d+\s)?\w+\b|==|\+\+|--|\+=|-=|->|&&|\|=|\|\||\!=|<=|>=|#\S*|\;|>>|<<|-\d+[a-zA-Z_]*|"[^"]*"|[^\w\s;]'
    elif lang == 'java':
        pattern = r'\b(?:\d+\s)?\w+\b|==|\+\+|--|\+=|-=|\!\=|&&|\|\||\!=|<=|>=|"[^"]*"|\'[^\']*\'|[^\w\s]'
    elif lang == 'python':
        pattern = (
            r'\b(?:def|class|return|if|else|elif|for|while|import|from|as|with|try|except|finally|raise|'
            r'in|is|not|and|or|lambda|pass|break|continue|yield|assert|del|global|nonlocal|True|False|None)\b'
            r'|==|!=|<=|>=|<<|>>|[-+*/%=<>&|^~]'
            r'|\b\d+\b|\b\w+\b'  # 数字、变量名等
            r'|\"[^\"]*\"|\'[^\']*\''  # 字符串
            r'|[\[\]{}():.,]'  # 括号和标点
        )
    result = re.findall(pattern, line)#使用正则从行中提取所有匹配的 token 并返回

    return result

# 简单的Python注释处理函数
def remove_comments_and_docstrings_python(code):
    """简单的Python注释和文档字符串移除函数"""
    import re
    
    # 移除多行文档字符串
    code = re.sub(r'"""[\s\S]*?"""', '', code)
    code = re.sub(r"'''[\s\S]*?'''", '', code)
    
    # 移除单行注释
    lines = code.split('\n')
    cleaned_lines = []
    for line in lines:
        # 移除#后面的内容，但保留字符串中的#
        in_string = False
        string_char = None
        cleaned_line = ""
        i = 0
        while i < len(line):
            char = line[i]
            if char in ['"', "'"]:
                if not in_string:
                    in_string = True
                    string_char = char
                elif string_char == char:
                    in_string = False
                    string_char = None
            elif char == '#' and not in_string:
                break
            cleaned_line += char
            i += 1
        cleaned_lines.append(cleaned_line)
    
    return '\n'.join(cleaned_lines)

#判断预测的缺陷行是否覆盖真实缺陷行
def check(ground_flaw_lines, pred_flaw_lines):
    # to check all ground_flaw_lines are in the pred_flaw_lines (length=10)
    # print(f'ground_flaw_lines: {ground_flaw_lines}\npred_flaw_lines: {pred_flaw_lines}\n')
    #只要有一个 ground truth 缺陷行在预测结果中，即返回 True
    for term in ground_flaw_lines:
        if term in pred_flaw_lines:
            return True
    return False
    
    # all match
    # for term in ground_flaw_lines:
    #     if term in pred_flaw_lines:
    #         continue
    #     else:
    #         return False
    # return True
#这个函数的作用是将模型输出的 token 序列 term['token_sequence'] 还原为每行的 token 列表（token_sum），
# 并与 ground_tokens 进行逐个比较，验证 token 对齐是否正确。
def token2line(term, row_idx, test_set, lang, show=False):
    code = test_set[row_idx]['src'].strip()#获取源代码
    ground_tokens = eval(term['token_sequence'])#token_sequence 是字符串形式的列表（如："['int', 'main', ...]"），用 eval 转换成列表
    token_sum = []
    
    # 根据语言选择正确的注释处理函数
    if lang == 'c':
        code = remove_comments_and_docstrings_c(code)
    elif lang == 'java':
        code = remove_comments_and_docstrings_java_js(code)
    elif lang == 'python':
        code = remove_comments_and_docstrings_python(code)
    else:
        # 默认使用C语言的注释处理
        code = remove_comments_and_docstrings_c(code)
    
    for line in [line for line in code.split('\n')]:
        line = line2tokens(line, lang)
        #对每行进行 token 拆分，结果是 token_sum: List[List[tokens]]
        token_sum.append(line)
    # 通用的token对齐修复逻辑，替代针对特定索引的硬编码修复
    def smart_token_repair(token_sum, ground_tokens):
        """智能修复token对齐问题"""
        # 1. 处理常见的操作符分割问题
        for line_idx, line_tokens in enumerate(token_sum):
            for token_idx in range(len(line_tokens)):
                token = line_tokens[token_idx]
                # 合并被意外分割的复合操作符
                if token_idx > 0:
                    prev_token = line_tokens[token_idx - 1]
                    # 处理 \0, *=, &=, +=, -=, ==, !=, <=, >= 等
                    if (prev_token in ['\\', '*', '&', '+', '-', '=', '!', '<', '>'] and 
                        token in ['0', '='] and token_idx < len(line_tokens)):
                        # 合并操作符
                        combined = prev_token + token
                        line_tokens[token_idx - 1] = combined
                        line_tokens.pop(token_idx)
                        break
                
                # 处理浮点数后缀
                if token in ['1.0', '0.0'] and token_idx + 1 < len(line_tokens):
                    next_token = line_tokens[token_idx + 1]
                    if next_token.startswith('f'):
                        # 合并浮点数后缀
                        line_tokens[token_idx] = token + 'f'
                        line_tokens.pop(token_idx + 1)
                        break
        
        return token_sum
    
    # 应用智能修复
    token_sum = smart_token_repair(token_sum, ground_tokens)
    #展平 token_sum 后直接比较是否和 ground_tokens 完全一致
    if list(chain(*token_sum)) == ground_tokens:
        return True, token_sum
    else:
        # if show:
        #     
        #     logger.info(f"different: {row_idx}")
        #     print(f"row_idx: {row_idx}")
        #     print(f"code: {code}")
        #     print(f"a = {ground_tokens}")
        #     print(f"b = {list(chain(*token_sum))}")
        #     sys.exit()
        #     with open('/ssd2/wqq/work4/LineProbe/debug.txt', '+a') as f:
        #         f.write(f"row_idx: {row_idx}\n")
        #         f.write(f"a = {ground_tokens}\n")
        #         f.write(f"b = {list(chain(*token_sum))}\n")
        #
        # 改进的token对齐逻辑，尝试多种修复策略
        def advanced_token_alignment(token_sum, ground_tokens):
            """高级token对齐修复"""
            flattened = list(chain(*token_sum))
            
            # 策略1: 移除多余的空token
            filtered_sum = []
            for line_tokens in token_sum:
                filtered_line = [t for t in line_tokens if t.strip()]
                if filtered_line:
                    filtered_sum.append(filtered_line)
            if list(chain(*filtered_sum)) == ground_tokens:
                return True, filtered_sum
            
            # 策略2: 尝试插入空字符串对齐（原有逻辑的改进版本）
            index = 0
            max_attempts = min(50, len(flattened))  # 限制尝试次数，避免无限循环
            attempts = 0
            
            for i in range(len(token_sum)):
                for j in range(len(token_sum[i])):
                    if attempts >= max_attempts:
                        break
                    if index >= len(ground_tokens):
                        break
                    if token_sum[i][j] != ground_tokens[index]:
                        # 尝试插入空字符串
                        token_sum[i].insert(j, "")
                        attempts += 1
                        if list(chain(*token_sum)) == ground_tokens:
                            return True, token_sum
                        # 如果插入失败，移除刚插入的空字符串并尝试跳过当前token
                        token_sum[i].pop(j)
                        if j + 1 < len(token_sum[i]):
                            # 尝试跳过当前token
                            temp_token = token_sum[i].pop(j)
                            if list(chain(*token_sum)) == ground_tokens:
                                return True, token_sum
                            # 恢复
                            token_sum[i].insert(j, temp_token)
                        break
                    else:
                        index += 1
                if attempts >= max_attempts:
                    break
            
            # 策略3: 如果仍然无法对齐，返回原始按行分割的结果
            return False, [line.strip() for line in code.split('\n') if line.strip()]
        
        # 应用高级对齐逻辑
        success, aligned_tokens = advanced_token_alignment(token_sum, ground_tokens)
        return success, aligned_tokens

def load_result_path(args, model_type: str, name: str, strategy: str):
    import os, sys
    model_type = model_type.lower()
    lang = args.lang  # 获取语言参数
    # 新增：自动获取项目根目录
    project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '../..'))

    if strategy in ['plain', 'frequency', 'ast']:
        if model_type == 'codebert':
            base_result_path = os.path.join(project_root, 'results', 'probes')
            probe_result_path = os.path.join(base_result_path, f"codebert_{lang}_128_model_{name}_probe_42", "multiset.csv")
            test_result_path = os.path.join(project_root, 'src', 'resource', 'firstStepModels', 'BERT', f'test_result_{name}.csv')
        elif model_type == 'unixcoder':
            probe_result_path = os.path.join(args.probe_saved_path, f"unixcoder_{lang}_128_model_{name}_probe_42/multiset.csv")
            test_result_path = os.path.join(project_root, 'src', 'resource', 'firstStepModels', 'unixcoder', f'test_result_{name}.csv')
        elif model_type == 'bilstm':
            probe_result_path = os.path.join(args.probe_saved_path, f"bilstm_{lang}_128_model_{name}_probe_42/multiset.csv")
            test_result_path = os.path.join(project_root, 'src', 'resource', 'firstStepModels', 'BiLSTM', f'test_result_{name}.csv')
        elif model_type == 'mlp':
            probe_result_path = os.path.join(args.probe_saved_path, f"mlp_{lang}_128_model_{name}_probe_42/multiset.csv")
            test_result_path = os.path.join(project_root, 'src', 'resource', 'firstStepModels', 'MLP', f'test_result_{name}.csv')
        elif model_type == 'codet5':
            # 对齐 line_probe 保存规则：results/probes/{probe_name}/multiset.csv
            # 对于未显式传入 probe_name 的情况，按统一命名：codet5_{lang}_128_model_{name}_probe_42
            candidate_dirs = [
                os.path.join(args.probe_saved_path, f"codet5_{lang}_128_model_{name}_probe_42"),
                os.path.join(args.probe_saved_path, f"codet5_{lang}_128_1215"),  # 兼容历史目录
            ]
            probe_result_path = None
            for d in candidate_dirs:
                p = os.path.join(d, 'multiset.csv')
                if os.path.exists(p):
                    probe_result_path = p
                    break
            if probe_result_path is None:
                # 默认取第一候选路径，便于错误提示
                probe_result_path = os.path.join(candidate_dirs[0], 'multiset.csv')

            # CodeT5 测试结果可能保存为 test_result_{seed}.csv（顶层目录）或按 name 保存
            seed = getattr(args, 'seed', 42)
            test_candidates = [
                os.path.join(project_root, 'src', 'resource', 'firstStepModels', 'CodeT5', f'test_result_{name}.csv'),
                os.path.join(project_root, f'test_result_{seed}.csv'),
            ]
            test_result_path = None
            for p in test_candidates:
                if os.path.exists(p):
                    test_result_path = p
                    break
            if test_result_path is None:
                # 默认给出第一个候选，便于提示
                test_result_path = test_candidates[0]
        elif model_type == 'graphcodebert':
            probe_result_path = os.path.join(args.probe_saved_path, f"graphcodebert_{lang}_128_model_00_probe_42/multiset.csv")
            test_result_path = os.path.join(project_root, 'src', 'resource', 'firstStepModels', 'GraphCodeBERT', f'test_result_0.csv')
        elif model_type == 'linevul':
            probe_result_path = os.path.join(args.probe_saved_path, f"linevul_{lang}_128_model_{name}_probe_42/multiset.csv")
            test_result_path = os.path.join(project_root, 'src', 'resource', 'firstStepModels', 'LineVul', f'test_result_{name}.csv')
        else:
            sys.exit(f"No such first step model: {model_type}.")

    if not os.path.exists(probe_result_path):
        sys.exit(f"Probe result {probe_result_path} not exists")
    if not os.path.exists(test_result_path):
        sys.exit(f"Test result {test_result_path} not exists")

    return probe_result_path, test_result_path

def load_customized_ast(args, model_type: str, name: str):
    import os, sys
    lang = args.lang  # 获取语言参数
    
    if model_type == 'codebert':
        customized_ast_path = os.path.join(args.probe_saved_path, f"codebert_{lang}_128_model_{name}_probe_42")
    elif model_type == 'unixcoder':
        customized_ast_path = os.path.join(args.probe_saved_path, f"unixcoder_{lang}_128_model_{name}_probe_42")
    elif model_type == 'bilstm':
        customized_ast_path = os.path.join(args.probe_saved_path, f"bilstm_{lang}_128_model_{name}_probe_42")
    elif model_type == 'mlp':
        customized_ast_path = os.path.join(args.probe_saved_path, f"mlp_{lang}_128_model_{name}_probe_42")
    elif model_type == 'graphcodebert':
        customized_ast_path = os.path.join(args.probe_saved_path, f"graphcodebert_{lang}_128_model_00_probe_42")
    elif model_type == 'codet5':
        customized_ast_path = os.path.join(args.probe_saved_path, f"codet5_{lang}_128_model_{name}_probe_42")
    else:
        sys.exit(f"No such first step model: {model_type}.")

    return os.path.join(customized_ast_path, 'customized_ast')
