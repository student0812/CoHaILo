import json
import logging
import os
import pathlib
import random
import re
import shutil
from collections import Counter

from tqdm import tqdm
from tree_sitter import Language, Parser

from .binary_tree import ast2binary, tree_to_distance
from .code2ast import code2ast, get_tokens_ast

logger = logging.getLogger(__name__)
#这里的语言可以添加
LANGUAGES = (
    'c',
    'java',
    'python'
)

#语法编辑器，这里都要修改，如果用python
# print(f"location: {os.getcwd()}")
# 删除重复的Language定义，使用build_grammars中的定义
# C_LANGUAGE = Language('/tmp/pycharm_project_420/VulProbe-main/src/resource/grammars/languages.so', 'c')#.so 文件包含编译好的语法树定义
# JAVA_LANGUAGE = Language('/tmp/pycharm_project_420/VulProbe-main/src/resource/grammars/languages.so', 'java')
# PYTHON_LANGUAGE = Language('/tmp/pycharm_project_420/VulProbe-main/src/resource/grammars/languages.so', 'python')
# C_LANGUAGE = Language('./src/resource/grammars/languages.so', 'c')#.so 文件包含编译好的语法树定义
# JAVA_LANGUAGE = Language('./src/resource/grammars/languages.so', 'java')
# C_LANGUAGE = Language('/ssd2/wqq/work4/for_exhibition/ast_probe/grammars/languages.so', 'c')
# JAVA_LANGUAGE = Language('/ssd2/wqq/work4/for_exhibition/ast_probe/grammars/languages.so', 'java')

# 使用build_grammars中定义的Language对象
from ..build_grammars import C_LANGUAGE, JAVA_LANGUAGE, PYTHON_LANGUAGE

C_PARSER = Parser()
C_PARSER.set_language(C_LANGUAGE)
JAVA_PARSER = Parser()
JAVA_PARSER.set_language(JAVA_LANGUAGE)
PYTHON_PARSER = Parser()
PYTHON_PARSER.set_language(PYTHON_LANGUAGE)
#将一个样本转换成用于模型训练的特征
# 新增递归提取 code 的辅助函数
# def extract_code(term):
#     # 递归提取 src 字段，直到拿到字符串
#     while isinstance(term, dict):
#         term = term.get('src', '')
#
#     # 如果term是字符串，尝试解析它是否包含嵌套的字典
#     if isinstance(term, str):
#         # 检查是否是字符串化的字典
#         if term.startswith('{') and term.endswith('}'):
#             try:
#                 import ast
#                 parsed = ast.literal_eval(term)
#                 if isinstance(parsed, dict) and 'src' in parsed:
#                     result = str(parsed['src'])
#                     return result
#             except Exception as e:
#                 print(f"[DEBUG] extract_code: 解析失败: {e}")
#         # 处理转义的字符串
#         elif term.startswith('{\'src\':') or term.startswith('{"src":'):
#             try:
#                 import ast
#                 parsed = ast.literal_eval(term)
#                 if isinstance(parsed, dict) and 'src' in parsed:
#                     result = str(parsed['src'])
#                     return result
#             except Exception as e:
#                 print(f"[DEBUG] extract_code: 解析转义字符串失败: {e}")
#         # 处理LazyRow对象
#         elif hasattr(term, '__getitem__') and 'src' in term:
#             result = str(term['src'])
#             return result
#         return term
#
#     return str(term) if term is not None else ""
#
# def convert_sample_to_features(term, parser, lang, tokenizer=None):
#     """
#     支持codet5分支：如果传入tokenizer，则用tokenizer编码代码，否则走原有AST逻辑。
#     """
#     if tokenizer is not None:
#         # 只用 extract_code，确保传递给 tokenizer 的是字符串
#         if isinstance(term, dict):
#             pass
#         code = extract_code(term)
#
#         label = term.get('label', 0) if isinstance(term, dict) else 0
#         # 移除过多调试信息
#         # 强制用新tokenizer生成input_ids并覆盖
#         inputs = tokenizer(
#             code,
#             max_length=512,
#             padding='max_length',
#             truncation=True,
#             return_tensors='pt'
#         )
#         input_ids = inputs['input_ids'].squeeze(0).tolist()
#
#         # 同时生成AST信息
#         try:
#             # 添加AST解析调试信息
#
#             # 确保传递给code2ast的是纯代码，而不是字符串化的字典
#             pure_code = code
#             if isinstance(code, str) and code.startswith('{') and code.endswith('}'):
#                 try:
#                     import ast
#                     parsed = ast.literal_eval(code)
#                     if isinstance(parsed, dict) and 'src' in parsed:
#                         pure_code = str(parsed['src'])
#                 except Exception as e:
#                     print(f"[ERROR] 解析字符串化字典失败: {e}")
#
#             G, pre_code = code2ast(pure_code, parser, lang)
#
#
#             # 检查AST节点类型分布
#             node_types = [G.nodes[n]['type'] for n in G.nodes]
#             unique_types = list(set(node_types))
#
#             binary_ast = ast2binary(G)
#             d, c, _, u = tree_to_distance(binary_ast, 0)
#             code_tokens = get_tokens_ast(G, pre_code)
#
#
#             # 检查是否有有效的AST标签
#             if not c or all(x == c[0] for x in c):
#                 print(f"[WARNING] AST标签单一化: 所有c标签都是 {c[0] if c else 'None'}")
#             if not u or all(x == u[0] for x in u):
#                 print(f"[WARNING] AST标签单一化: 所有u标签都是 {u[0] if u else 'None'}")
#
#             return {
#                 'input_ids': input_ids,  # 覆盖原有input_ids
#                 'label': label,
#                 'src': pure_code,  # 使用提取的纯代码，而不是原始的code
#                 'd': d,
#                 'c': c,
#                 'u': u,
#                 'num_tokens': len(code_tokens),
#                 'code_tokens': code_tokens
#             }
#         except Exception as e:
#             print(f"[ERROR] AST解析异常: {e}")
#             # 如果AST解析失败，返回空列表
#             return {
#                 'input_ids': input_ids,
#                 'label': label,
#                 'src': code,
#                 'd': [],
#                 'c': [],
#                 'u': [],
#                 'num_tokens': 0,
#                 'code_tokens': []
#             }
#     # 原有AST逻辑
#     if type(term) == str:
#         G, pre_code = code2ast(term, parser, lang)
#         binary_ast = ast2binary(G)
#         d, c, _, u = tree_to_distance(binary_ast, 0)
#         code_tokens = get_tokens_ast(G, pre_code)
#
#         return {
#             'd': d,
#             'c': c,
#             'u': u,
#             'num_tokens': len(code_tokens),
#             'code_tokens': code_tokens
#         }
#     else:
#         code = term['src']#修改里面的标签，不用src
#         G, pre_code = code2ast(code, parser, lang)
#         binary_ast = ast2binary(G)
#         d, c, _, u = tree_to_distance(binary_ast, 0)
#         code_tokens = get_tokens_ast(G, pre_code)
#         return {
#             'd': d,
#             'c': c,
#             'u': u,
#             'num_tokens': len(code_tokens),
#             'code_tokens': code_tokens,
#             'label': term['label'],
#             'flaw_line_index': term['flaw_line_index'],
#             'src': code#数据集中的字段
#         }
#
# def get_non_terminals_labels(train_set_labels, valid_set_labels, test_set_labels):
#     """
#     将所有训练、验证、测试标签拼接起来
# 用 Counter 保证标签顺序稳定；
# 给每个唯一标签分配一个 ID；
# 返回 {label: id} 映射字典，用于模型训练。
#     """
#     all_labels = [label for seq in train_set_labels for label in seq] + \
#                  [label for seq in valid_set_labels for label in seq] + \
#                  [label for seq in test_set_labels for label in seq]
#
#     # 添加调试信息
#     # print(f"[DEBUG] get_non_terminals_labels:")
#     # print(f"  train_set_labels样本数: {len(train_set_labels)}")
#     # print(f"  valid_set_labels样本数: {len(valid_set_labels)}")
#     # print(f"  test_set_labels样本数: {len(test_set_labels)}")
#     # print(f"  all_labels总数: {len(all_labels)}")
#     # print(f"  all_labels前10个: {all_labels[:10]}")
#
#     # use a Counter to constantly get the same order in the labels
#     ct = Counter(all_labels)
#     labels_to_ids = {}
#     for i, label in enumerate(ct):
#         labels_to_ids[label] = i
#
#     # print(f"[DEBUG] 生成的标签映射:")
#     # print(f"  唯一标签数: {len(labels_to_ids)}")
#     # print(f"  标签映射示例: {list(labels_to_ids.items())[:10]}")
#
#     return labels_to_ids
#
#
# def convert_to_ids(c, column_name, labels_to_ids):
#     """
# 接收标签序列 c；
# 用 labels_to_ids 映射每个标签为整数；
# 返回字典 {column_name: labels_ids}，便于集成到样本结构中。
#     """
#     labels_ids = []
#     if len(labels_to_ids) == 0:
#         # 如果标签映射为空，返回空列表
#         return {column_name: []}
#
#     # 获取默认标签ID（第一个标签）
#     default_label_id = list(labels_to_ids.values())[0] if labels_to_ids else 0
#
#     for label in c:
#         if label in labels_to_ids:
#             labels_ids.append(labels_to_ids[label])
#         else:
#             # 如果标签不在映射中，使用默认标签而不是-1
#             labels_ids.append(default_label_id)
#     return {column_name: labels_ids}
def convert_sample_to_features(term, parser, lang):
    if type(term) == str:
        code = term
    else:
        code = term['src']
    try:
        G, pre_code = code2ast(code, parser, lang)
        binary_ast = ast2binary(G)
        d, c, _, u = tree_to_distance(binary_ast, 0)
        code_tokens = get_tokens_ast(G, pre_code)
        result = {
            'd': d,
            'c': c,
            'u': u,
            'num_tokens': len(code_tokens),
            'code_tokens': code_tokens
        }
        if isinstance(term, dict):
            result['label'] = term.get('label')
            result['flaw_line_index'] = term.get('flaw_line_index')
            result['src'] = code
        return result
    except Exception as e:
        print(f"[ERROR] AST解析失败: {e} | code: {str(code)[:60]}")
        return {
            'd': [],
            'c': [],
            'u': [],
            'num_tokens': 0,
            'code_tokens': [],
            'label': term.get('label') if isinstance(term, dict) else None,
            'flaw_line_index': term.get('flaw_line_index') if isinstance(term, dict) else None,
            'src': code
        }


def get_non_terminals_labels(train_set_labels, valid_set_labels, test_set_labels):
    all_labels = [label for seq in train_set_labels for label in seq] + \
                 [label for seq in valid_set_labels for label in seq] + \
                 [label for seq in test_set_labels for label in seq]
    # use a Counter to constantly get the same order in the labels
    ct = Counter(all_labels)
    labels_to_ids = {}
    for i, label in enumerate(ct):
        labels_to_ids[label] = i
    return labels_to_ids


def convert_to_ids(c, column_name, labels_to_ids):
    labels_ids = []
    for label in c:
        labels_ids.append(labels_to_ids[label])
    return {column_name: labels_ids}

