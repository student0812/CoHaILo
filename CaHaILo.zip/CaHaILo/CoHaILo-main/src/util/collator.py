import numpy as np
import torch
import sys

from .utils import match_tokenized_to_untokenized_roberta

#定义一个函数，用于对输入的样本 batch 进行统一整理
def collator_fn(batch, tokenizer):
    #原始的token序列和一些特征向量
    tokens = [b['code_tokens'] for b in batch]
    cs = [b['c'] for b in batch]
    ds = [b['d'] for b in batch]
    us = [b['u'] for b in batch]
    # vulnerability info
    token_sequences = tokens
    flaw_line_idxes = [b['flaw_line_index'] for b in batch]#代表哪一行有漏洞
    labels = [b['label'] for b in batch]#每条样本的标签
    codes = [b['src'] for b in batch]#原始代码字符串
    
    # generate inputs and attention masks
    all_inputs = []
    all_attentions = []
    all_mappings = []
    for untokenized_sent in tokens:
        #返回 RoBERTa 的子 token 和对应映射
        to_convert, mapping = match_tokenized_to_untokenized_roberta(untokenized_sent, tokenizer)
        # 兼容不同模型的特殊token（如T5无CLS/SEP，则使用BOS/EOS或PAD兜底）
        cls_tok = getattr(tokenizer, 'cls_token', None) or getattr(tokenizer, 'bos_token', None) or getattr(tokenizer, 'pad_token')
        sep_tok = getattr(tokenizer, 'sep_token', None) or getattr(tokenizer, 'eos_token', None) or getattr(tokenizer, 'pad_token')
        inputs = tokenizer.convert_tokens_to_ids([cls_tok] + to_convert + [sep_tok])
        masks = [1] * len(inputs)
        all_inputs.append(inputs)
        all_attentions.append(masks)
        #把每个原 token 对应的子 token 索引加上偏移 1（因为有 [CLS]）
        all_mappings.append({x: [l + 1 for l in y] for x, y in mapping.items()})
    #找出最长的编码长度，用于 padding
    max_len_subtokens = np.max([len(m) for m in all_attentions])
    # pad sequences.对所有输入的 token id 序列进行右侧 padding，pad 成相同长度。
    all_inputs = torch.tensor(
        [inputs + tokenizer.convert_tokens_to_ids([tokenizer.pad_token] * (max_len_subtokens - len(inputs)))
         for inputs in all_inputs])
    #相应地对 attention mask 进行 padding，pad 的位置填 0
    all_attentions = torch.tensor([mask + ([0] * (max_len_subtokens - len(mask)))
                                   for mask in all_attentions])
#计算原始 token 序列的最大长度，用于后续对 c/d/u 向量做 padding
    batch_len_tokens = [len(m) for m in tokens]
    max_len_tokens = np.max(batch_len_tokens)
#这里的 -1 可能表示 padding 的无效位。注意 c 和 d 的 padding 少了 1，可能是因为与预测任务对齐的需要。
    cs = torch.tensor([c + [-1] * (max_len_tokens - 1 - len(c)) for c in cs])
    ds = torch.tensor([d + [-1] * (max_len_tokens - 1 - len(d)) for d in ds])
    us = torch.tensor([u + [-1] * (max_len_tokens - len(u)) for u in us])
    # labels = torch.tensor([[label] + [-1] * (max_len_tokens - 1) for label in labels])
    
    # generate token alignment
    alignment = []
    for mapping in all_mappings:
        j = 0
        indices = []
        """
        len(mapping[i]) 是原始第 i 个 token 被分成了多少个子 token；
用 j（当前 token 的编号）重复 len(mapping[i]) 次，表示这些子 token 都映射回原始第 j 个 token；
然后 j += 1，进入下一个 token 的编号。
        """
        for i in range(len(mapping)):
            indices += [j]*len(mapping[i])
            j += 1
            """
            max_len_subtokens：是当前 batch 中最长的子 token 序列长度；
  -1 是因为加了 [CLS]，所以实际子 token 序列长度为 len(inputs) - 1；
 这一步的作用是把 indices 填充成和最大长度一致的长度（padding）；
填的是当前 j（即最后一个 token 的编号），只是为了保持 shape 一致。
            """
        indices += [j]*(max_len_subtokens - 1 - len(indices))
        alignment.append(indices)
    alignment = torch.tensor(alignment)
    
    return token_sequences, flaw_line_idxes, labels, all_inputs, all_attentions, ds, cs, us, torch.tensor(batch_len_tokens), alignment, codes
