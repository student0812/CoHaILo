import os
import pickle
import sys
import json
import logging
import argparse
import pandas as pd
import numpy as np
from datetime import datetime
from sklearn.metrics import accuracy_score, recall_score, precision_score, f1_score
from itertools import chain
from tqdm import tqdm
from tree_sitter import Parser, Language
from datasets import load_dataset
from datasets import Dataset

from .args import ProgramArguments
from transformers import HfArgumentParser

from .util import C_LANGUAGE, JAVA_LANGUAGE
from .util.probe_score import token2line, load_result_path, load_customized_ast, line2tokens
#这段代码是一个漏洞检测模型的解释性分析工具，主要用于评估模型对代码漏洞的解释能力和定位准确性。
# 生成的结果文件包含模型对代码行的解释分数、漏洞定位结果以及统计信息，可用于分析模型性能、改进模型解释性。
"""
token2line：可能将 token 索引映射到代码行。
load_result_path：用于根据配置加载预测结果文件路径。
load_customized_ast：加载自定义 AST 树（本段代码中暂未使用）。
"""
#分析模型在代码漏洞检测任务中的结构性解释表现，特别是每一行代码被识别为"可能出错"的信心（分数）
base_dir = os.path.dirname(os.path.abspath(__file__))  # 当前文件所在目录
logger = logging.getLogger(__name__)

def calculate_tree_f1(p_ast_preorder, f_ast_preorder):
    """
    计算tree_F1指标
    Args:
        p_ast_preorder: P-AST的先序遍历节点标签序列
        f_ast_preorder: O-AST的先序遍历节点标签序列
    Returns:
        tree_f1: tree_F1分数
    """
    # 转换为集合以便计算交集
    p_ast_elements = set(p_ast_preorder)
    o_ast_elements = set(f_ast_preorder)
    
    # 计算交集
    intersection = p_ast_elements.intersection(o_ast_elements)
    
    # 计算tree_F1
    if len(p_ast_elements) + len(o_ast_elements) == 0:
        return 0.0
    
    tree_f1 = 2 * len(intersection) / (len(p_ast_elements) + len(o_ast_elements))
    
    return tree_f1

def calculate_ast_similarity_metrics(p_ast_preorders, f_ast_preorders):
    """
    计算所有样本的AST相似性指标
    Args:
        p_ast_preorders: 所有P-AST的先序遍历序列列表
        f_ast_preorders: 所有O-AST的先序遍历序列列表
    Returns:
        metrics: 包含tree_F1等指标的字典
    """
    tree_f1_scores = []
    
    for p_ast, f_ast in zip(p_ast_preorders, f_ast_preorders):
        tree_f1 = calculate_tree_f1(p_ast, f_ast)
        tree_f1_scores.append(tree_f1)
    
    # 计算统计信息
    avg_tree_f1 = sum(tree_f1_scores) / len(tree_f1_scores) if tree_f1_scores else 0
    min_tree_f1 = min(tree_f1_scores) if tree_f1_scores else 0
    max_tree_f1 = max(tree_f1_scores) if tree_f1_scores else 0
    
    metrics = {
        'tree_f1_scores': tree_f1_scores,
        'avg_tree_f1': avg_tree_f1,
        'min_tree_f1': min_tree_f1,
        'max_tree_f1': max_tree_f1,
        'total_samples': len(tree_f1_scores)
    }
    
    return metrics




if __name__ == '__main__':
    parser = HfArgumentParser(ProgramArguments)
    parser.add_argument('--ast_mode', type=str, default='tree', help='tree or preorder')
    parser.add_argument('--control_weight', type=str, default='False', help='True or False')
    args = parser.parse_args()
    args.control_weight = args.control_weight.lower() in ['true', '1', 'yes']
    
    # 添加调试输出
    print(f"\n{'='*60}")
    print(f"DEBUG: 开始执行策略 - {args.strategy}")
    print(f"DEBUG: ast_mode parameter = {args.ast_mode}")
    print(f"DEBUG: control_weight parameter = {args.control_weight}")
    print(f"DEBUG: control_weight type = {type(args.control_weight)}")
    print(f"DEBUG: 模型类型 = {args.first_step_model_type}")
    print(f"DEBUG: 语言 = {args.lang}")
    print(f"{'='*60}")
    
    # picture_ast_generation(args.first_step_model_type, args.probe_saved_path, args.lang)
            
    logger.info('Load test dataset from local file.')
    #拼接路径
   # args.dataset_path = os.path.join(args.dataset_path, args.lang)
    # 修正为绝对路径，避免找不到数据集
    args.dataset_path = '/tmp/pycharm_project_573/VulProbe-main/src/resource/dataset/python'
    data_files = {'train': os.path.join(args.dataset_path, 'train.jsonl'),
                  'valid': os.path.join(args.dataset_path, 'valid.jsonl'),
                  'test': os.path.join(args.dataset_path, 'test.jsonl')}
    test_set = load_dataset('json', data_files=data_files, split='test')
    
    model_type, name, strategy = args.first_step_model_type, args.name, args.strategy
    #probe_result_path：模型每行得分或 token 映射结果 test_result_path：模型整体预测（是否存在漏洞）结果
    probe_result_path, test_result_path = load_result_path(args, model_type, name, strategy)
    print(f"****** probe_result path: {probe_result_path} ******")
    probe_result = pd.read_csv(probe_result_path)
    #如果 flaw_line_idx 是 NaN（即无标注漏洞行），则设为空列表。否则将字符串（如 '3,4'）包装为列表 [3, 4]
    for idx, term in probe_result.iterrows():
        if pd.isna(term['flaw_line_idx']):
            probe_result.at[idx, 'flaw_line_idx'] = []
        else:
            try:
                # 清理flaw_line_idx字符串，移除多余的逗号和空格
                flaw_line_str = str(term['flaw_line_idx']).strip()
                # 移除多余的逗号
                flaw_line_str = flaw_line_str.replace(',,', ',')  # 移除双逗号
                flaw_line_str = flaw_line_str.replace(', ,', ',')  # 移除逗号+空格+逗号
                flaw_line_str = flaw_line_str.replace(' ,', ',')   # 移除空格+逗号
                flaw_line_str = flaw_line_str.replace(', ', ',')   # 移除逗号+空格
                # 移除开头和结尾的逗号
                flaw_line_str = flaw_line_str.strip(',')
                
                if flaw_line_str:
                    probe_result.at[idx, 'flaw_line_idx'] = eval('[' + flaw_line_str + ']')
                else:
                    probe_result.at[idx, 'flaw_line_idx'] = []
            except Exception as e:
                print(f"Warning: Error parsing flaw_line_idx '{term['flaw_line_idx']}' at index {idx}: {e}")
                probe_result.at[idx, 'flaw_line_idx'] = []

    logger.info(f"Select the *** {args.strategy} Strategy ***")
    
    bad_pattern_tokenization = 0
    bad_pattern_tokenization_line_num = 0 
    bad_pattern_tokenization_flaw_line_num = 0 
    nan_num = 0        
     # 读取整体预测结果（是否有漏洞）
    print(f"****** test_result_path: {test_result_path} ******")
    test_result = pd.read_csv(test_result_path)

    tp_list = test_result[test_result.apply(lambda x: x['label'] == 1 and x['pred'] == True, axis=1)].index.tolist()
    fp_list = test_result[test_result.apply(lambda x: x['label'] == 0 and x['pred'] == True, axis=1)].index.tolist()
    tn_list = test_result[test_result.apply(lambda x: x['label'] == 0 and x['pred'] == False, axis=1)].index.tolist()
    fn_list = test_result[test_result.apply(lambda x: x['label'] == 1 and x['pred'] == False, axis=1)].index.tolist()
    print(f"tp: {len(tp_list)} | fp: {len(fp_list)} | tn: {len(tn_list)} | fn: {len(fn_list)} | total: {len(probe_result)}")
    
    
    if args.strategy == 'ast':
        logger.info('Load customized ASTs.')
        """
p_ast_list：预测结果构建的 AST 树（graph 对象）
f_ast_list：真实标签构建的 AST 树（ground truth）
p_ast_preorders：预测树的先序遍历节点标签序列
f_ast_preorders：真实树的先序遍历节点标签序列
        """
        p_ast_list = []
        p_ast_preorders = []
        f_ast_list = []
        f_ast_preorders = []
        model_type, name = args.first_step_model_type, args.name
        customized_ast_path = load_customized_ast(args, model_type, name)
        print(f"****** customized_ast path: {customized_ast_path} ******")
        #遍历 AST 文件：每个样本有两个文件（预测树 + 真实树），所以总数除以 2 得到样本数
        for ast_idx in range(len(os.listdir(customized_ast_path)) // 2):
            p_ast_name = f'pred_tree_{ast_idx}.pkl'
            f_ast_name = f'ground_truth_tree_{ast_idx}.pkl'
            with open(os.path.join(customized_ast_path, p_ast_name), 'rb') as f:
                pred_tree = pickle.load(f)
            with open(os.path.join(customized_ast_path, f_ast_name), 'rb') as f:
                ground_tree = pickle.load(f)
        # 遍历预测 AST 中的每个节点，从节点属性中取出 'pre_order' 标签（先序遍历编号或标签），加入列表。
            # AST子结构表示切换
            if args.ast_mode == 'tree':
                # tree constituent 表示 - 使用节点的原始顺序（不排序）
                p_ast_preorder = [pred_tree.nodes[node]['pre_order'] for node in pred_tree.nodes]
                f_ast_preorder = [ground_tree.nodes[node]['pre_order'] for node in ground_tree.nodes]
                if ast_idx == 0:  # 只打印第一个样本的调试信息
                    print(f"DEBUG: 使用tree模式，节点数量: {len(p_ast_preorder)}")
            else:
                # preorder 表示 - 使用先序遍历顺序（按pre_order值排序）
                p_ast_preorder = [pred_tree.nodes[node]['pre_order'] for node in pred_tree.nodes]
                f_ast_preorder = [ground_tree.nodes[node]['pre_order'] for node in ground_tree.nodes]
                # 对先序遍历序列进行排序，确保按照先序遍历顺序
                p_ast_preorder.sort()
                f_ast_preorder.sort()
                if ast_idx == 0:  # 只打印第一个样本的调试信息
                    print(f"DEBUG: 使用preorder模式，节点数量: {len(p_ast_preorder)}")
                
            p_ast_list.append(pred_tree)
            f_ast_list.append(ground_tree)
            p_ast_preorders.append(p_ast_preorder)
            f_ast_preorders.append(f_ast_preorder)
        # ast_data = pd.DataFrame({'pred_tree': p_ast_list, 'ground_tree': f_ast_list, 'pred_ast_preorder': p_ast_preorders, 'ground_ast_preorder': f_ast_preorders})
        
        # one = ast_data['pred_tree'][0]
        
        # for node in one.nodes:
        #     print(one.nodes[node])
        
    if args.strategy == 'frequency':
        from .util.utils import get_frequency
        type_score = get_frequency(probe_result, test_result)
        
    if args.strategy == 'ast':
        from .util.utils import get_ast_type_frequency
        type_score = get_ast_type_frequency(p_ast_preorders, f_ast_preorders)
        
        # 计算AST相似性指标
        ast_metrics = calculate_ast_similarity_metrics(p_ast_preorders, f_ast_preorders)
        
        # 打印结果
        print(f"****** AST相似性评估结果 ******")
        print(f"平均tree_F1: {ast_metrics['avg_tree_f1']:.4f}")
        print(f"最小tree_F1: {ast_metrics['min_tree_f1']:.4f}")
        print(f"最大tree_F1: {ast_metrics['max_tree_f1']:.4f}")
        print(f"总样本数: {ast_metrics['total_samples']}")
        
        # 将结果保存到probe_result中
        probe_result['tree_f1_score'] = ast_metrics['tree_f1_scores']

    #用于存储每行样本的 token-level 统计字典，初始值为 None
    probe_result['statistic'] = None
    err_idx = set()
    
    # 添加控制结构统计
    control_structure_count = 0
    total_structure_count = 0
    
    # 添加调试信息：检查第一个样本的数据结构
    if len(probe_result) > 0:
        first_sample = probe_result.iloc[0]
        print(f"\nDEBUG: 第一个样本的数据结构:")
        print(f"  pred_multiset: {eval(first_sample['pred_multiset'])[:3]}...")  # 只显示前3个
        print(f"  ground_multiset: {eval(first_sample['ground_multiset'])[:3]}...")  # 只显示前3个
    for row_idx, term in tqdm(probe_result.iterrows(), total=len(probe_result)):
        #初始化该样本的统计结构
        token_num = len(eval(term['token_sequence'])) + 1
        """
sum[i]: 第 i 个 token 被解释的总次数
true[i]: 第 i 个 token 被正确解释的次数
false[i]: 第 i 个 token 被错误解释的次数
        """
        statistic = {
            'sum': [0 for i in range(token_num)],
            'true': [0 for i in range(token_num)],
            'false': [0 for i in range(token_num)],
        }
        
        if args.strategy == 'ast':

            p_ast_preorder = p_ast_preorders[row_idx]
            f_ast_preorder = f_ast_preorders[row_idx]
            score = 1
            #遍历预测的多重结构（pred_multiset），每个元素形式为：type-token_idx1-token_idx2-...
            #同时遍历 p_ast_preorder 中节点
            for node, ast_node in zip(eval(term['pred_multiset']), p_ast_preorder):
                if ast_node in f_ast_preorder:
                    sta = statistic['true']
                    node_type = node.split('-')[0]                    
                    # 控制结构加权
                    total_structure_count += 1
                    
                    # 打印所有节点类型用于调试
                    if total_structure_count <= 20:  # 打印前20个节点类型
                        print(f"DEBUG: 节点类型 '{node_type}', control_weight={args.control_weight}")
                    
                    # 扩展的控制结构类型列表，包含Python特有结构和变体
                    control_types = [
                        # 基础Python控制结构
                        'if', 'for', 'while', 'try', 'except', 'finally', 'with', 'break', 'continue', 'return', 'raise', 'assert',
                        # 语句形式变体
                        'if_statement', 'for_statement', 'while_statement', 'try_statement', 'except_clause', 'finally_clause',
                        'with_statement', 'break_statement', 'continue_statement', 'return_statement', 'raise_statement', 'assert_statement',
                        # 表达式和其他形式
                        'if_expr', 'for_loop', 'while_loop', 'try_except', 'with_item', 'function_def', 'class_def',
                        # Python特有的控制结构
                        'lambda', 'lambda_expr', 'lambda_function',  # lambda表达式
                        'yield', 'yield_expr', 'yield_from', 'yield_statement',  # 生成器相关
                        'async_for', 'async_with', 'async_function_def', 'async_def',  # 异步相关
                        'await', 'await_expr',  # await表达式
                        'match', 'match_statement', 'case', 'case_clause',  # Python 3.10+ match语句
                        'list_comprehension', 'dict_comprehension', 'set_comprehension', 'generator_exp',  # 推导式
                        'conditional_expression', 'ternary_operator',  # 三元运算符
                        'global', 'global_statement', 'nonlocal', 'nonlocal_statement',  # 作用域声明
                        'del', 'del_statement',  # 删除语句
                        'pass', 'pass_statement',  # pass语句
                        'import', 'import_statement', 'import_from', 'from_import',  # 导入语句
                        'exec', 'eval',  # 动态执行
                        'decorator', 'decorated',  # 装饰器
                        'context_manager', 'context_expr'  # 上下文管理器
                    ]
                    
                    if args.control_weight and node_type in control_types:
                        score = 1.5
                        control_structure_count += 1
                        if control_structure_count <= 5:  # 只打印前5个控制结构
                            print(f"DEBUG: 发现控制结构 '{node_type}', 使用权重 {score}")
                    else:
                        score = 1
                    for token_idx in node.split('-')[1:]:
                        token_idx = int(token_idx)
                    #遍历这个结构节点关联的所有 token 索引，对它们在 true 和 sum 中增加计数（带权重）
                        try:
                            sta[token_idx] += score
                            #statistic['sum'][token_idx] += 1
                            statistic['sum'][token_idx] += score  # 修复：sum也应该使用权重
                        except Exception as e:
                            if row_idx not in err_idx:
                                # print(f"row_idx: {row_idx}")
                                err_idx.add(row_idx)
                                # traceback.print_exc()
                            else:
                                break
                            
                else:
                    sta = statistic['false']
                    for token_idx in node.split('-')[1:]:
                        token_idx = int(token_idx)
                        try:
                            sta[token_idx] += 1
                            statistic['sum'][token_idx] += 1
                        except Exception as e:
                            break
            probe_result.at[row_idx, 'statistic'] = statistic
            
        elif args.strategy == 'plain':    
            score = 1
            for node in eval(term['pred_multiset']):
                if node in eval(term['ground_multiset']):
                    sta = statistic['true']
                    #将当前结构节点（如 'if_statement-5-6-7'）按 - 分隔，取第一个部分（if_statement）
                    node_type = node.split('-')[0]  
                    # 控制结构加权
                    total_structure_count += 1
                    
                    # 打印所有节点类型用于调试
                    if total_structure_count <= 20:  # 打印前20个节点类型
                        print(f"DEBUG: 节点类型 '{node_type}', control_weight={args.control_weight}")
                    
                    # 扩展的控制结构类型列表，包含Python特有结构和变体
                    control_types = [
                        # 基础Python控制结构
                        'if', 'for', 'while', 'try', 'except', 'finally', 'with', 'break', 'continue', 'return', 'raise', 'assert',
                        # 语句形式变体
                        'if_statement', 'for_statement', 'while_statement', 'try_statement', 'except_clause', 'finally_clause',
                        'with_statement', 'break_statement', 'continue_statement', 'return_statement', 'raise_statement', 'assert_statement',
                        # 表达式和其他形式
                        'if_expr', 'for_loop', 'while_loop', 'try_except', 'with_item', 'function_def', 'class_def',
                        # Python特有的控制结构
                        'lambda', 'lambda_expr', 'lambda_function',  # lambda表达式
                        'yield', 'yield_expr', 'yield_from', 'yield_statement',  # 生成器相关
                        'async_for', 'async_with', 'async_function_def', 'async_def',  # 异步相关
                        'await', 'await_expr',  # await表达式
                        'match', 'match_statement', 'case', 'case_clause',  # Python 3.10+ match语句
                        'list_comprehension', 'dict_comprehension', 'set_comprehension', 'generator_exp',  # 推导式
                        'conditional_expression', 'ternary_operator',  # 三元运算符
                        'global', 'global_statement', 'nonlocal', 'nonlocal_statement',  # 作用域声明
                        'del', 'del_statement',  # 删除语句
                        'pass', 'pass_statement',  # pass语句
                        'import', 'import_statement', 'import_from', 'from_import',  # 导入语句
                        'exec', 'eval',  # 动态执行
                        'decorator', 'decorated',  # 装饰器
                        'context_manager', 'context_expr'  # 上下文管理器
                    ]
                    
                    if args.control_weight and node_type in control_types:
                        score = 1.5
                        control_structure_count += 1
                        if control_structure_count <= 5:  # 只打印前5个控制结构
                            print(f"DEBUG: 发现控制结构 '{node_type}', 使用权重 {score}")
                    else:
                        score = 1
                    #拿到该结构节点所关联的 token 索引列表（如 'if_statement-5-6-7' → [5,6,7]），用于对每个 token 更新统计
                    for token_idx in node.split('-')[1:]:
                        token_idx = int(token_idx)
                        try:
                            sta[token_idx] += score
                            #statistic['sum'][token_idx] += 1
                            statistic['sum'][token_idx] += score  # 修复：sum也应该使用权重
                        except Exception as e:
                            if row_idx not in err_idx:
                                # print(f"row_idx: {row_idx}")
                                err_idx.add(row_idx)
                                # traceback.print_exc()
                            else:
                                break
                            
                else:
                    sta = statistic['false']
                    for token_idx in node.split('-')[1:]:
                        token_idx = int(token_idx)
                        try:
                            sta[token_idx] += 1
                            statistic['sum'][token_idx] += 1
                        except Exception as e:
                            break
            probe_result.at[row_idx, 'statistic'] = statistic

                        

            
    for idx in err_idx:
        if idx in tp_list or idx in fn_list:
            print(f"err_idx: {idx}")
    
    # 输出控制结构统计信息
    print(f"\n=== 控制结构统计 ===")
    print(f"总结构节点数: {total_structure_count}")
    print(f"控制结构节点数: {control_structure_count}")
    print(f"控制结构比例: {control_structure_count/total_structure_count*100:.2f}%" if total_structure_count > 0 else "无结构节点")
    
    # score aggregation
    probe_result['lines_score'] = None
    probe_result['index'] = None#index：保存原索引值
    for row_idx, term in tqdm(probe_result.iterrows(), total=len(probe_result)):
        #same: 是否严格对齐（tokenize 后还和原代码行一一对应）；
        #code_2_tokenized_lines: 映射关系，如第 1 行对应 token [0,1,2]，第 2 行是 [3,4,5] 等。
        same, code_2_tokenized_lines = token2line(term, row_idx, test_set, args.lang)
        
        # 添加详细的调试信息
        print(f"\n[DEBUG] 样本 {row_idx} token2line 结果:")
        print(f"  same: {same}")
        print(f"  code_2_tokenized_lines类型: {type(code_2_tokenized_lines)}")
        print(f"  code_2_tokenized_lines长度: {len(code_2_tokenized_lines)}")
        print(f"  code_2_tokenized_lines前3行: {code_2_tokenized_lines[:3] if len(code_2_tokenized_lines) >= 3 else code_2_tokenized_lines}")
        
        # 检查statistic字段
        if term['statistic'] is not None:
            print(f"  statistic['true']长度: {len(term['statistic']['true'])}")
            print(f"  statistic['true']前10个值: {term['statistic']['true'][:10]}")
        else:
            print(f"  statistic: None")
        
        line_statistic = {}
        #hit_idx: 遍历时用于按顺序取 token 的解释值。 line_statistic：每一行累计的 token 分数。
        hit_idx, hit_statistic = 0, term['statistic']['true'][1:]
        
        if same:
            """
对每一行 line，将对应 token 的 true 解释得分加总，变成 行级分数。
即：一行中多个 token 得分的总和，表示模型对这行"有问题"的信心。
            """
            print(f"  [DEBUG] 样本 {row_idx}: 严格对齐成功，开始计算行级分数")
            for line_idx, line in enumerate(code_2_tokenized_lines):
                line_statistic[line_idx] = 0
                for j in line:
                    line_statistic[line_idx] += hit_statistic[hit_idx]
                    hit_idx += 1
            print(f"  [DEBUG] 样本 {row_idx}: 行级分数计算完成，共{len(line_statistic)}行")
        else:
            print(f"  [DEBUG] 样本 {row_idx}: 对齐失败，尝试重新token分割")
            
            # 对齐失败时，尝试重新进行token分割和映射
            try:
                # 获取原始代码
                code = test_set[row_idx]['src'].strip()
                
                # 重新进行token分割
                lines = code.split('\n')
                for line_idx, line_str in enumerate(lines):
                    if line_idx < len(code_2_tokenized_lines):  # 确保索引不越界
                        if line_str.strip():  # 跳过空行
                            # 对每一行进行token分割
                            line_tokens = line2tokens(line_str, args.lang)
                            line_statistic[line_idx] = 0
                            
                            # 尝试建立token到统计分数的映射
                            # 这里使用一个简化的策略：将统计分数按比例分配给每一行
                            if len(line_tokens) > 0:
                                # 计算该行应该分配的分数比例
                                line_token_count = len(line_tokens)
                                total_tokens = len(hit_statistic)
                                
                                # 如果该行的token数量合理，分配对应的统计分数
                                if line_idx < len(hit_statistic):
                                    # 直接使用对应位置的统计分数
                                    line_statistic[line_idx] = hit_statistic[line_idx]
                                else:
                                    # 使用平均分数
                                    avg_score = sum(hit_statistic) / len(hit_statistic) if hit_statistic else 0
                                    line_statistic[line_idx] = avg_score
                            else:
                                line_statistic[line_idx] = 0
                        else:
                            line_statistic[line_idx] = 0
                    else:
                        line_statistic[line_idx] = 0
                
                print(f"  [DEBUG] 样本 {row_idx}: 重新token分割完成，共{len(line_statistic)}行")
                
            except Exception as e:
                print(f"  [DEBUG] 样本 {row_idx}: 重新token分割失败: {e}")
                # 如果重新分割也失败，使用简单的行数统计
                for line_idx in range(len(code_2_tokenized_lines)):
                    line_statistic[line_idx] = 0
                
            if row_idx in tp_list:
                token2line(term, row_idx, test_set, args.lang, show=True)
                bad_pattern_tokenization += 1
                bad_pattern_tokenization_line_num += len(code_2_tokenized_lines)
                
        # 生成lines_score
        lines_score = [x for x in line_statistic.values()]
        if len(lines_score) > 0:
            lines_score[0] = 0
        probe_result.at[row_idx, 'lines_score'] = lines_score
        probe_result.at[row_idx, 'index'] = row_idx
        
        # 添加lines_score调试信息
        print(f"  [DEBUG] 样本 {row_idx}: lines_score长度: {len(lines_score)}")
        print(f"  [DEBUG] 样本 {row_idx}: lines_score前10个值: {lines_score[:10]}")
    
    print(f"bad_pattern_tokenization: {bad_pattern_tokenization}")
    
    # 确保tree_F1列存在（如果使用AST策略）
    if args.strategy == 'ast' and 'tree_f1_score' in probe_result.columns:
        # 填充可能的NaN值
        probe_result['tree_f1_score'] = probe_result['tree_f1_score'].fillna(0)
        print(f"****** tree_F1指标已添加到结果中 ******")
    
    #它记录了模型在代码理解或漏洞检测任务中，对每一条样本的 结构性预测（结构组件）与统计分析结果explain_result_save_path = os.path.join(base_dir, '..', 'results', 
    #'explaination', f'{args.first_step_model_type}_{args.strategy}
    #_probe_explaination_{args.name}.csv')
    # Include control_weight in filename to distinguish different strategies
    control_suffix = "_control" if args.control_weight else ""
    ast_mode_suffix = f"_{args.ast_mode}" if args.strategy == 'ast' else ""
    explain_result_save_path = os.path.join(base_dir, '..', 'results', 'explaination', f'{args.first_step_model_type}_{args.strategy}{ast_mode_suffix}{control_suffix}_probe_explaination_{args.name}.csv')
    print(f"save path: {explain_result_save_path}")
    # 自动创建目录（若不存在）
    os.makedirs(os.path.dirname(explain_result_save_path), exist_ok=True)
    probe_result.to_csv(explain_result_save_path)
    """
TP：实际有漏洞，预测为有漏洞。
FP：实际无漏洞，预测为有漏洞。
TN：实际无漏洞，预测为无漏洞。
FN：实际有漏洞，预测为无漏洞。
 explain_result_save_path = f'VulProbe/results/explaination/{args.first_step_model_type}_{args.strategy}_probe_explaination_{args.name}.csv'
    """
    