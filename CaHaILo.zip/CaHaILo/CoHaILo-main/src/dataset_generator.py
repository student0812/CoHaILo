import logging
import argparse
import random
import os
import json
#from tree_sitter_languages import get_language, get_parser
import pandas as pd
import numpy as np
import networkx as nx
import torch
from transformers import AutoTokenizer
from tree_sitter import Parser
from datasets import load_dataset, Dataset
#从自定义模块中引入语言定义、代码转AST的工具函数、AST解析是否出错检测、以及token匹配函数
#from utils.tree_sitter_languages import C_LANGUAGE, PYTHON_LANGUAGE, JAVA_LANGUAGE
from .util import C_LANGUAGE,PYTHON_LANGUAGE,JAVA_LANGUAGE
from .util.code2ast import code2ast, get_tokens_ast, has_error
from .util.utils import match_tokenized_to_untokenized_roberta
#处理原始代码数据，生成干净且结构化的数据集，供后续代码分析任务（如漏洞检测模型 LineVul）使用
tokenizer_codebert = AutoTokenizer.from_pretrained('microsoft/codebert-base')

tokenizers = [tokenizer_codebert]

#定义过滤函数，对原始代码样本做质量过滤

def filter_samples(code, max_length, lang, parser):
    try:
        G, code_pre = code2ast(code=code, parser=parser, lang=lang)
        assert nx.is_tree(nx.Graph(G))
        assert nx.is_connected(nx.Graph(G))
    except:
        return False
    if has_error(G):
        return False

    for tokenizer in tokenizers:
        t, _ = match_tokenized_to_untokenized_roberta(untokenized_sent=code_pre, tokenizer=tokenizer)
        if len(t) + 2 > max_length:
            return False
    return True
#定义提取 token 函数，使用 AST 获取 token 及其所在的代码行号
#将代码解析为AST图并提取所有token及其位置信息（比如所在行号）
def code2token(code, lang):
    parser = Parser()
    if lang == 'c':
        parser.set_language(C_LANGUAGE)
    elif lang == 'java':
        parser.set_language(JAVA_LANGUAGE)
    elif lang == 'python':
        parser.set_language(PYTHON_LANGUAGE)
    G, pre_code = code2ast(code, parser, lang=lang)
    tokens = get_tokens_ast(G, pre_code)
    return tokens

if __name__ == '__main__':
    # parser = argparse.ArgumentParser(description='Script for generating the dataset for probing')
    # parser.add_argument('--dataset_dir', default='./src/resource/dataset', help='Path to save the dataset')
    # parser.add_argument('--lang', help='Language.', choices=['c', 'java'],
    #                     default='c')
    # parser.add_argument('--max_code_length', help='Maximum code length.', default=512)
    # parser.add_argument('--seed', help='seed.', type=int, default=123)
    parser = argparse.ArgumentParser(description='Script for generating the dataset for probing')
    parser.add_argument('--dataset_path', default='/autodl-fs/data/end1_HA.jsonl', help='Path to dataset')
    parser.add_argument('--dataset_dir', default='/tmp/pycharm_project_573/VulProbe-main/src/resource/dataset', help='Path to save the dataset')
    parser.add_argument('--lang', help='Language.', choices=['c', 'java', 'python'], default='python')
    parser.add_argument('--max_code_length', help='Maximum code length.', default=512)
    parser.add_argument('--seed', help='seed.', type=int, default=123)
    args = parser.parse_args()

    logger = logging.getLogger()
    logger.setLevel(level=logging.INFO)

    console = logging.StreamHandler()
    console.setLevel(level=logging.INFO)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s: %(message)s')
    console.setFormatter(formatter)
    logger.addHandler(console)

    # seed everything
    if args.seed > 0:
        random.seed(args.seed)
        np.random.seed(args.seed)
        torch.manual_seed(args.seed)
        torch.cuda.manual_seed_all(args.seed)

    # dataset_path = os.path.join(args.dataset_dir, args.lang, 'dataset.jsonl')
    #
    # if not os.path.exists(dataset_path):
    #     filename = os.listdir(os.path.join(args.dataset_dir, args.lang))[0]
    #     csv_path = os.path.join(args.dataset_dir, args.lang, filename)
    #     df = pd.read_csv(csv_path)
    #     df.to_json(dataset_path, orient='records', lines=True)
    if os.path.exists(args.dataset_path):
        dataset_path = args.dataset_path
    else:
        dataset_lang_dir = os.path.join(args.dataset_dir, args.lang)
        os.makedirs(dataset_lang_dir, exist_ok=True)

        dataset_path = os.path.join(dataset_lang_dir, 'dataset.jsonl')

        if not os.path.exists(dataset_path):
            # 查找是否有 CSV 文件
            csv_files = [f for f in os.listdir(dataset_lang_dir) if f.endswith('.csv')]
            if not csv_files:
                raise FileNotFoundError(
                    f"No dataset found at {args.dataset_path}, and no CSV found in {dataset_lang_dir}")

            csv_path = os.path.join(dataset_lang_dir, csv_files[0])
            df = pd.read_csv(csv_path)
            df.to_json(dataset_path, orient='records', lines=True)

    logger.info('Loading dataset.')
    # if 'json' in dataset_path:
    #     dataset = load_dataset('json', data_files=dataset_path, split='train')
    # elif 'csv' in dataset_path:
    #     dataset = load_dataset('csv', data_files=dataset_path)
    if 'json' in dataset_path:
        # 用 pandas 先加载 json 文件
        logger.info('Preloading JSON with pandas to remove problematic fields.')
        try:
            # 尝试直接读取JSONL格式
            df = pd.read_json(dataset_path, lines=True)
        except ValueError as e:
            logger.warning(f'Failed to read as JSONL: {e}')
            # 如果失败，尝试逐行读取并解析
            logger.info('Trying to read file line by line...')
            data = []
            with open(dataset_path, 'r', encoding='utf-8') as f:
                for line_num, line in enumerate(f, 1):
                    line = line.strip()
                    if line:  # 跳过空行
                        try:
                            json_obj = json.loads(line)
                            data.append(json_obj)
                        except json.JSONDecodeError as json_err:
                            logger.warning(f'Invalid JSON at line {line_num}: {json_err}')
                            continue
            if not data:
                raise ValueError("No valid JSON objects found in file")
            df = pd.DataFrame(data)
            logger.info(f'Successfully loaded {len(df)} records')

        # 删除引发 Arrow 错误的字段
        for col in ['hallucination', 'labeling_comments']:
            if col in df.columns:
                logger.info(f'Removing column: {col}')
                df = df.drop(columns=[col])
        # 修复 test_case 字段为 dict 导致的 pyarrow 报错
        if 'test_case' in df.columns:
            df['test_case'] = df['test_case'].apply(lambda x: json.dumps(x, ensure_ascii=False) if isinstance(x, dict) else x)
        # 修复 test_case_detail 字段为 list 导致的 pyarrow 报错
        if 'test_case_detail' in df.columns:
            df['test_case_detail'] = df['test_case_detail'].apply(lambda x: json.dumps(x, ensure_ascii=False) if isinstance(x, list) else x)
        # 修复 test_output 字段为 list 导致的 pyarrow 报错
        if 'test_output' in df.columns:
            df['test_output'] = df['test_output'].apply(lambda x: json.dumps(x, ensure_ascii=False) if isinstance(x, list) else x)
        # 修复 flaw_line_index 字段为 int/float 导致的 pyarrow 报错
        if 'flaw_line_index' in df.columns:
            df['flaw_line_index'] = df['flaw_line_index'].apply(lambda x: str(x) if isinstance(x, (int, float)) else x)
        # 转换为 HuggingFace 的 Dataset 格式
        dataset = Dataset.from_pandas(df)

    elif 'csv' in dataset_path:
        logger.info('Loading CSV file.')
        dataset = load_dataset('csv', data_files=dataset_path, split='train')

        # ⚠️ 删除字段：hallucination 和 labeling_comments
    logger.info('Removing unnecessary fields.')
    df_dataset = dataset.to_pandas()
    for col in ['hallucination', 'labeling_comments']:
        if col in df_dataset.columns:
            df_dataset = df_dataset.drop(columns=[col])
    dataset = Dataset.from_pandas(df_dataset)
    parser_lang = Parser()

    if args.lang == 'c':
        parser_lang.set_language(C_LANGUAGE)
    elif args.lang == 'java':
        parser_lang.set_language(JAVA_LANGUAGE)
    elif args.lang == 'python':
        parser_lang.set_language(PYTHON_LANGUAGE)
    else:
        raise Exception("Use C or Java!")

    # filter dataset by code length
    logger.info('Filtering dataset.')
    #调用上面的 filter_samples() 函数，删除语法错误/AST 无效/超长的代码样本

    dataset = dataset.filter(
        lambda e: filter_samples(e['src'], args.max_code_length, args.lang, parser_lang), num_proc=1)

    logger.info('Shuffling dataset.')
    dataset = dataset.shuffle(args.seed)

    # generate code_tokens from src
    logger.info('generate code_tokens')
    df_dataset = dataset.to_pandas()
    df_dataset['code_tokens'] = df_dataset['src'].apply(lambda x: code2token(x, args.lang))
    df_dataset = df_dataset[~((df_dataset['label'] == 1) & (df_dataset['flaw_line_index'].isna()))]
    dataset = Dataset.from_pandas(df_dataset)

    logger.info('Splitting dataset.')
    # train : valid : test = 8 : 1 : 1
    length = len(dataset)
    train_len = length * 8 // 10
    if (length - train_len) % 2 == 0:
        test_len, val_len = (length - train_len) // 2, (length - train_len) // 2
    else:
        train_len = train_len - 1
        test_len, val_len = (length - train_len) // 2, (length - train_len) // 2
    train_dataset = dataset.select(range(0, train_len))
    test_dataset = dataset.select(range(train_len, train_len + test_len))
    val_dataset = dataset.select(range(train_len + test_len, train_len + test_len + val_len))

    logger.info('Storing dataset.')
    train_dataset.to_json(os.path.join(args.dataset_dir, args.lang, 'train.jsonl'))
    test_dataset.to_json(os.path.join(args.dataset_dir, args.lang, 'test.jsonl'))
    val_dataset.to_json(os.path.join(args.dataset_dir, args.lang, 'valid.jsonl'))



