# import os
# from tree_sitter import Language
# #使用不同语言
# # 使用 tree-sitter 构建 C 和 Java 语言的共享库
# # 获取当前文件所在目录的路径
# current_dir = os.path.dirname(os.path.abspath(__file__))
# resource_dir = os.path.join(current_dir, 'resource', 'grammars')
#
# # 使用相对路径构建语言库
# Language.build_library(
#     os.path.join(resource_dir, 'languages.so'),
#     [
#         os.path.join(resource_dir, 'tree-sitter-c'),
#         os.path.join(resource_dir, 'tree-sitter-java'),
#         os.path.join(resource_dir, 'tree-sitter-python')
#     ],
# )
#
# # 加载构建好的共享库
# JAVA_LANGUAGE = Language(os.path.join(resource_dir, 'languages.so'), 'java')
# C_LANGUAGE = Language(os.path.join(resource_dir, 'languages.so'), 'c')
# PYTHON_LANGUAGE = Language(os.path.join(resource_dir, 'languages.so'), 'python')
import os
from tree_sitter import Language
#使用不同语言
# 使用 tree-sitter 构建 C 和 Java 语言的共享库
Language.build_library(
    '/tmp/pycharm_project_420/VulProbe-main/src/resource/grammars/languages.so',
    [
        '/tmp/pycharm_project_420/VulProbe-main/src/resource/grammars/tree-sitter-c',
        '/tmp/pycharm_project_420/VulProbe-main/src/resource/grammars/tree-sitter-java',
        '/tmp/pycharm_project_420/VulProbe-main/src/resource/grammars/tree-sitter-python'# 确保包含 Java
    ],
)

# 加载构建好的共享库
JAVA_LANGUAGE = Language('/tmp/pycharm_project_420/VulProbe-main/src/resource/grammars/languages.so', 'java')
C_LANGUAGE = Language('/tmp/pycharm_project_420/VulProbe-main/src/resource/grammars/languages.so', 'c')
PYTHON_LANGUAGE = Language('/tmp/pycharm_project_420/VulProbe-main/src/resource/grammars/languages.so', 'python')