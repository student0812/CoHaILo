import os
import logging
logger = logging.getLogger(__name__)

# VulProbe(CodeBERT): model_type = 'codebert', explain_method = 'probe'
# VulProbe(UnixCoder): model_type = 'unixcoder', explain_method = 'probe'
# VulProbe(bilstm): model_type = 'bilstm', explain_method = 'probe'
# VulProbe(mlp): model_type = 'mlp', explain_method = 'probe'

# Strategy configurations for ablation experiments:
# 'plain': tree+uni (baseline tree representation with unary nodes)
# 'plain_control': tree+control (tree representation with control structure weighting)
# 'ast': preorder+uni (preorder traversal with unary nodes)
# 'ast_control': preorder+control (preorder traversal with control structure weighting)

def main():
    model_type = 'graphcodebert'
    # ['bilstm', 'mlp', 'codebert', 'unixcoder', 'LineVul', 'linevd', 'qwen', 'gpt']
    # for name in ['00', '11', '22', '33', '44']:
    for name in ['00']:#name 表示数据集标识（可能是某个文件夹名），可替换为多个如 ['00', '11', '22', ...]

        # Four ablation strategies as shown in the paper:
        # 1. tree+uni: plain strategy without control weighting
        # 2. tree+control: plain strategy with control weighting
        # 3. preorder+uni: ast strategy without control weighting
        # 4. preorder+control: ast strategy with control weighting

        strategies_configs = [
            ('plain', False),     # tree+uni
            ('plain', True),      # tree+control
            ('ast', False),       # preorder+uni
            ('ast', True)         # preorder+control
        ]

        for strategy, use_control_weight in strategies_configs:
            #只使用 probe 方法进行消融实验
            for explain_method in ['probe']:
            # for explain_method in ['saliency', 'deeplift_shap', 'gradient_shap']:
            # for explain_method in ['qwen', 'gpt, 'linevul', 'probe', 'linevd']:
            #设置 top-K 评估指标
                for top_k in [1, 3, 5, 10]:
                # for top_k in [1]:
                #构造并执行命令，构造命令行字符串，用于运行解释方法评估代码
                    control_flag = "--control_weight True" if use_control_weight else "--control_weight False"
                    strategy_name = f"{strategy}_control" if use_control_weight else strategy

                    # 根据strategy设置ast_mode
                    ast_mode = "preorder" if strategy == "ast" else "tree"

                    print(f"\n=== Running experiment: {strategy_name} (top-{top_k}) ===")

                    #command = f"python src/expalaination_evaluation.py " \
                    command = f"python -m src.expalaination_evaluation " \
                        f"--explain_method {explain_method} " \
                        f"--top_k {top_k} " \
                        f"--first_step_model_type {model_type} " \
                        f"--strategy {strategy} " \
                        f"--ast_mode {ast_mode} " \
                        f"{control_flag} " \
                        f"--name {name} " \
                        f"--dataset_path /tmp/pycharm_project_573/VulProbe-main/src/resource/dataset/python/test/"
                    print(command)
                    os.system(command)#使用 os.system() 实际运行该命令，触发 explanation_evaluation.py 执行
        #strategy = 'plain'
        # ['plain', 'ast']
        #只使用 saliency 方法；也可以切换为 'probe', 'deeplift_shap', 'gpt',
        #'linevul' 等方法
        # for explain_method in ['gradient_shap']:
        # for explain_method in ['saliency', 'deeplift_shap', 'gradient_shap']
        # :
        # for explain_method in ['qwen', 'gpt, 'linevul', 'probe', 'linevd']:
        #设置 top-K 评估指标
           # for top_k in [1, 3, 5, 10]:
            # for top_k in [1]:
            #构造并执行命令，构造命令行字符串，用于运行解释方法评估代码
                #command = f"python src/expalaination_evaluation.py " \
                #command = f"python -m src.expalaination_evaluation " \
                   # f"--explain_method {explain_method} " \
                    #f"--top_k {top_k} " \
                    #f"--first_step_model_type {model_type} " \
                    #f"--strategy {strategy} " \
                    #f"--name {name} " \
                    #f"--dataset_path /tmp/pycharm_project_573/VulProbe-main/
                    #src/resource/dataset/python/test/"
                #print(command)
                #os.system(command)#使用 os.system() 实际运行该命令，触发
                #explanation_evaluation.py 执行

if __name__ == '__main__':
    main()
