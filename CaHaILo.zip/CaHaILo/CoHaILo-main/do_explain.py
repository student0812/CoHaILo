# import os
# import logging
# logger = logging.getLogger(__name__)
# #批量执行探针解释器（do_probe_explain.py）的运行任务
# def main():
#
#     # for name in ['00', '11', '22', '33', '44']:
#     for name in ['11', '22', '33', '44']:
#         for lang in ['c']:
#             # for model_type in ['codebert', 'unixcoder', 'mlp', 'bilstm', 'codet5', 'graphcodebert', 'unixcoder']:
#             for model_type in ['codebert']:
#                 # for strategy in ['plain', frequency', 'ast']:
#                 #指定解释策略
#                 for strategy in ['ast']:
#                     print(f"python src/do_probe_explain.py --first_step_model_type {model_type} "
#                             f"--lang {lang} --strategy {strategy} --name {name}")
#                     os.system(f"python src/do_probe_explain.py --first_step_model_type {model_type} "
#                             f"--lang {lang} --strategy {strategy} --name {name}")
#
#
# if __name__ == '__main__':
#     main()

import os
import logging

logger = logging.getLogger(__name__)


# 批量执行探针解释器（do_probe_explain.py）的运行任务
def main():
    # 只使用 '00' 进行测试
    for name in ['00']:#00
        for lang in ['python']:
            for model_type in ['codet5']:  # 只使用 'codet5' 模型
                # 实现四种策略：tree+uni, tree+control, preorder+uni, preorder+control
                #for strategy in ['ast']:  # 只使用 'ast' 策略
                    #print(f"python src/do_probe_explain.py
                    #--first_step_model_type {model_type} "
                    #print(f"python -m src.do_probe_explain
                    #--first_step_model_type {model_type} "
                         # f"--lang {lang} --strategy {strategy} --name
                          #{name}")
                    #os.system(f"python src/do_probe_explain.py
                    #--first_step_model_type {model_type} "
                    #os.system(f"python -m src.do_probe_explain
                    #--first_step_model_type {model_type} "
                             # f"--lang {lang} --strategy {strategy}
                              #--name {name}")
                for strategy in ['plain', 'ast']:  # plain=tree+uni, ast=preorder+uni
                    for control_weight in [False, True]:  # False=uni, True=control
                        control_flag = "--control_weight True" if control_weight else "--control_weight False"
                        strategy_name = f"{strategy}_{'control' if control_weight else 'uni'}"

                        # 根据strategy设置ast_mode
                        ast_mode = "preorder" if strategy == "ast" else "tree"

                        print(f"执行策略: {strategy_name}")
                        print(f"python -m src.do_probe_explain --first_step_model_type {model_type} "
                              f"--lang {lang} --strategy {strategy} --ast_mode {ast_mode} --name {name} {control_flag}")

                        os.system(f"python -m src.do_probe_explain --first_step_model_type {model_type} "
                                  f"--lang {lang} --strategy {strategy} --ast_mode {ast_mode} --name {name} {control_flag}")

                        print(f"策略 {strategy_name} 执行完成\n")


if __name__ == '__main__':
    main()

