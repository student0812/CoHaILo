#!/usr/bin/env python3
"""
脚本用于找到测试结果中的TP和FP样本，并提取它们的具体信息
"""

import pandas as pd
import json
import os
import sys

def find_tp_fp_samples(test_result_path, test_dataset_path, output_file=None):
    """
    找到TP和FP样本，并提取它们的具体信息
    
    Args:
        test_result_path: 测试结果CSV文件路径
        test_dataset_path: 测试数据集文件路径  
        output_file: 输出文件路径（可选）
    """
    
    print(f"正在读取测试结果: {test_result_path}")
    try:
        test_result = pd.read_csv(test_result_path)
        print(f"测试结果文件形状: {test_result.shape}")
        print(f"测试结果列名: {list(test_result.columns)}")
    except FileNotFoundError:
        print(f"错误: 找不到测试结果文件 {test_result_path}")
        return
    except Exception as e:
        print(f"错误: 读取测试结果文件失败 - {e}")
        return
    
    print(f"\n正在读取测试数据集: {test_dataset_path}")
    try:
        # 尝试不同的数据集格式
        if test_dataset_path.endswith('.jsonl'):
            test_dataset = pd.read_json(test_dataset_path, lines=True)
        elif test_dataset_path.endswith('.csv'):
            test_dataset = pd.read_csv(test_dataset_path)
        else:
            print(f"不支持的数据集格式: {test_dataset_path}")
            return
            
        print(f"测试数据集形状: {test_dataset.shape}")
        print(f"测试数据集列名: {list(test_dataset.columns)}")
    except FileNotFoundError:
        print(f"错误: 找不到测试数据集文件 {test_dataset_path}")
        return
    except Exception as e:
        print(f"错误: 读取测试数据集文件失败 - {e}")
        return
    
    # 确保两个数据集的长度一致
    if len(test_result) != len(test_dataset):
        print(f"警告: 测试结果长度({len(test_result)}) 与数据集长度({len(test_dataset)}) 不一致")
        min_len = min(len(test_result), len(test_dataset))
        test_result = test_result.iloc[:min_len]
        test_dataset = test_dataset.iloc[:min_len]
        print(f"已截断到最小长度: {min_len}")
    
    # 分类样本
    tp_list = test_result[test_result.apply(lambda x: x['label'] == 1 and x['pred'] == True, axis=1)].index.tolist()
    fp_list = test_result[test_result.apply(lambda x: x['label'] == 0 and x['pred'] == True, axis=1)].index.tolist()
    tn_list = test_result[test_result.apply(lambda x: x['label'] == 0 and x['pred'] == False, axis=1)].index.tolist()
    fn_list = test_result[test_result.apply(lambda x: x['label'] == 1 and x['pred'] == False, axis=1)].index.tolist()
    
    print(f"\n=== 样本分类统计 ===")
    print(f"TP (真实有漏洞，预测有漏洞): {len(tp_list)} 个")
    print(f"FP (真实无漏洞，预测有漏洞): {len(fp_list)} 个")
    print(f"TN (真实无漏洞，预测无漏洞): {len(tn_list)} 个")
    print(f"FN (真实有漏洞，预测无漏洞): {len(fn_list)} 个")
    print(f"总计: {len(tp_list) + len(fp_list) + len(tn_list) + len(fn_list)} 个")
    
    # 提取TP和FP样本的详细信息
    analyzed_samples = tp_list + fp_list
    print(f"\n=== 被分析的样本（TP + FP）===")
    print(f"总共 {len(analyzed_samples)} 个样本被用于解释分析")
    print(f"样本索引: {analyzed_samples}")
    
    # 创建详细结果
    detailed_results = []
    
    for idx in analyzed_samples:
        sample_type = "TP" if idx in tp_list else "FP"
        
        # 从测试结果中获取信息
        test_row = test_result.iloc[idx]
        
        # 从测试数据集中获取信息
        dataset_row = test_dataset.iloc[idx]
        
        sample_info = {
            'index': idx,
            'type': sample_type,
            'pred_label': test_row['pred'],
            'true_label': test_row['label'],
        }
        
        # 添加数据集中的信息
        if 'src' in dataset_row:
            sample_info['source_code'] = dataset_row['src']
        if 'flaw_line' in dataset_row:
            sample_info['flaw_line'] = dataset_row['flaw_line']
        if 'flaw_line_index' in dataset_row:
            sample_info['flaw_line_index'] = dataset_row['flaw_line_index']
        if 'func_before' in dataset_row:
            sample_info['func_before'] = dataset_row['func_before']
        
        # 添加其他可能的列
        for col in dataset_row.index:
            if col not in ['src', 'flaw_line', 'flaw_line_index', 'func_before'] and col not in sample_info:
                sample_info[col] = dataset_row[col]
        
        detailed_results.append(sample_info)
    
    # 保存结果
    if output_file:
        output_dir = os.path.dirname(output_file)
        if output_dir and not os.path.exists(output_dir):
            os.makedirs(output_dir)
        
        # 保存为JSON格式，便于查看
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(detailed_results, f, ensure_ascii=False, indent=2)
        print(f"\n详细结果已保存到: {output_file}")
        
        # 同时保存为CSV格式
        csv_file = output_file.replace('.jsonl', '.csv')
        detailed_df = pd.DataFrame(detailed_results)
        detailed_df.to_csv(csv_file, index=False, encoding='utf-8')
        print(f"CSV格式结果已保存到: {csv_file}")
    else:
        # 打印前5个样本的概要信息
        print(f"\n=== 前5个样本的概要信息 ===")
        for i, sample in enumerate(detailed_results[:5]):
            print(f"\n样本 {i+1} (索引{sample['index']}, {sample['type']}):")
            print(f"  预测标签: {sample['pred_label']}")
            print(f"  真实标签: {sample['true_label']}")
            if 'source_code' in sample:
                code_preview = sample['source_code'][:100] + "..." if len(sample['source_code']) > 100 else sample['source_code']
                print(f"  代码预览: {code_preview}")
            if 'flaw_line_index' in sample:
                print(f"  漏洞行索引: {sample['flaw_line_index']}")
    
    return detailed_results

def create_tp_fp_dataset(test_result_path, test_dataset_path, output_dataset_path):
    """
    创建只包含TP和FP样本的新数据集
    
    Args:
        test_result_path: 测试结果CSV文件路径
        test_dataset_path: 原始测试数据集文件路径  
        output_dataset_path: 输出的新数据集路径
    """
    
    print(f"正在读取测试结果: {test_result_path}")
    try:
        test_result = pd.read_csv(test_result_path)
        print(f"测试结果文件形状: {test_result.shape}")
        print(f"测试结果列名: {list(test_result.columns)}")
    except FileNotFoundError:
        print(f"错误: 找不到测试结果文件 {test_result_path}")
        return None
    except Exception as e:
        print(f"错误: 读取测试结果文件失败 - {e}")
        return None
    
    print(f"\n正在读取原始测试数据集: {test_dataset_path}")
    try:
        # 尝试不同的数据集格式
        if test_dataset_path.endswith('.jsonl'):
            test_dataset = pd.read_json(test_dataset_path, lines=True)
        elif test_dataset_path.endswith('.csv'):
            test_dataset = pd.read_csv(test_dataset_path)
        else:
            print(f"不支持的数据集格式: {test_dataset_path}")
            return None
            
        print(f"原始测试数据集形状: {test_dataset.shape}")
        print(f"原始测试数据集列名: {list(test_dataset.columns)}")
    except FileNotFoundError:
        print(f"错误: 找不到测试数据集文件 {test_dataset_path}")
        return None
    except Exception as e:
        print(f"错误: 读取测试数据集文件失败 - {e}")
        return None
    
    # 确保两个数据集的长度一致
    if len(test_result) != len(test_dataset):
        print(f"警告: 测试结果长度({len(test_result)}) 与数据集长度({len(test_dataset)}) 不一致")
        min_len = min(len(test_result), len(test_dataset))
        test_result = test_result.iloc[:min_len]
        test_dataset = test_dataset.iloc[:min_len]
        print(f"已截断到最小长度: {min_len}")
    
    # 分类样本
    tp_list = test_result[test_result.apply(lambda x: x['label'] == 1 and x['pred'] == True, axis=1)].index.tolist()
    fp_list = test_result[test_result.apply(lambda x: x['label'] == 0 and x['pred'] == True, axis=1)].index.tolist()
    tn_list = test_result[test_result.apply(lambda x: x['label'] == 0 and x['pred'] == False, axis=1)].index.tolist()
    fn_list = test_result[test_result.apply(lambda x: x['label'] == 1 and x['pred'] == False, axis=1)].index.tolist()
    
    print(f"\n=== 样本分类统计 ===")
    print(f"TP (真实有漏洞，预测有漏洞): {len(tp_list)} 个")
    print(f"FP (真实无漏洞，预测有漏洞): {len(fp_list)} 个")
    print(f"TN (真实无漏洞，预测无漏洞): {len(tn_list)} 个")
    print(f"FN (真实有漏洞，预测无漏洞): {len(fn_list)} 个")
    print(f"总计: {len(tp_list) + len(fp_list) + len(tn_list) + len(fn_list)} 个")
    
    # 提取TP和FP样本的原始数据
    analyzed_indices = tp_list + fp_list
    print(f"\n=== 创建TP+FP数据集 ===")
    print(f"将提取 {len(analyzed_indices)} 个样本 (TP: {len(tp_list)}, FP: {len(fp_list)})")
    print(f"样本索引: {analyzed_indices}")
    
    # 从原始数据集中提取TP和FP样本
    tp_fp_dataset = test_dataset.iloc[analyzed_indices].copy()
    
    # 添加预测结果信息到数据集中
    tp_fp_dataset['pred_result'] = [test_result.iloc[idx]['pred'] for idx in analyzed_indices]
    tp_fp_dataset['sample_type'] = ['TP' if idx in tp_list else 'FP' for idx in analyzed_indices]
    tp_fp_dataset['original_index'] = analyzed_indices
    
    # 重新设置索引从0开始
    tp_fp_dataset = tp_fp_dataset.reset_index(drop=True)
    
    print(f"\n新数据集形状: {tp_fp_dataset.shape}")
    print(f"新数据集列名: {list(tp_fp_dataset.columns)}")
    
    # 保存新数据集
    output_dir = os.path.dirname(output_dataset_path)
    if output_dir and not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    # 根据输出文件格式保存
    if output_dataset_path.endswith('.jsonl'):
        tp_fp_dataset.to_json(output_dataset_path, orient='records', lines=True, force_ascii=False)
        print(f"\n✓ TP+FP数据集已保存到JSONL格式: {output_dataset_path}")
    elif output_dataset_path.endswith('.csv'):
        tp_fp_dataset.to_csv(output_dataset_path, index=False, encoding='utf-8')
        print(f"\n✓ TP+FP数据集已保存到CSV格式: {output_dataset_path}")
    else:
        # 默认保存为JSONL
        tp_fp_dataset.to_json(output_dataset_path + '.jsonl', orient='records', lines=True, force_ascii=False)
        print(f"\n✓ TP+FP数据集已保存到JSONL格式: {output_dataset_path}.jsonl")
    
    # 打印统计信息
    print(f"\n=== 新数据集统计 ===")
    print(f"总样本数: {len(tp_fp_dataset)}")
    print(f"TP样本数: {len([x for x in tp_fp_dataset['sample_type'] if x == 'TP'])}")
    print(f"FP样本数: {len([x for x in tp_fp_dataset['sample_type'] if x == 'FP'])}")
    
    # 显示前几个样本的信息
    print(f"\n=== 前3个样本预览 ===")
    for i in range(min(3, len(tp_fp_dataset))):
        sample = tp_fp_dataset.iloc[i]
        print(f"\n样本 {i} ({sample['sample_type']}, 原索引: {sample['original_index']}):")
        print(f"  真实标签: {sample.get('label', 'N/A')}")
        print(f"  预测结果: {sample['pred_result']}")
        if 'src' in sample:
            code_lines = str(sample['src']).split('\n')[:3]  # 只显示前3行代码
            print(f"  代码前3行:")
            for j, line in enumerate(code_lines):
                print(f"    {j}: {line}")
        if 'flaw_line_index' in sample:
            print(f"  漏洞行索引: {sample['flaw_line_index']}")
    
    return tp_fp_dataset

def main():
    """主函数"""
    
    # 根据你的项目结构设置路径
    base_dir = "src"
    
    # 测试结果文件路径（根据你使用的模型和数据集名称调整）
    model_type = "graphcodebert"  # 你在test.py中使用的模型
    name = "0"  # 你在test.py中使用的数据集标识
    
    # 可能的测试结果文件路径
    test_result_paths = [
        f"{base_dir}/resource/firstStepModels/GraphCodeBERT/test_result_{name}.csv",
    ]
    
    test_result_path = None
    for path in test_result_paths:
        if os.path.exists(path):
            test_result_path = path
            print(f"✓ 找到测试结果文件: {path}")
            break
    
    if not test_result_path:
        print("错误: 找不到测试结果文件")
        print("请检查以下路径中是否存在测试结果文件:")
        for path in test_result_paths:
            print(f"  - {path}")
        return
    
    # 测试数据集路径
    test_dataset_paths = [
        f"{base_dir}/resource/dataset/python/test/test.jsonl",
    ]
    
    test_dataset_path = None
    for path in test_dataset_paths:
        if os.path.exists(path):
            test_dataset_path = path
            print(f"✓ 找到原始测试数据集: {path}")
            break
    
    if not test_dataset_path:
        print("错误: 找不到测试数据集文件")
        print("请检查以下路径中是否存在数据集文件:")
        for path in test_dataset_paths:
            print(f"  - {path}")
        return
    
    # 输出数据集路径
    output_dataset_path = f"tp_fp_filtered_dataset_{name}.jsonl"
    
    # 创建TP+FP数据集
    print(f"\n开始创建TP+FP数据集...")
    tp_fp_dataset = create_tp_fp_dataset(test_result_path, test_dataset_path, output_dataset_path)
    
    if tp_fp_dataset is not None:
        print(f"\n=== 创建完成 ===")
        print(f"新数据集包含 {len(tp_fp_dataset)} 个样本")
        print(f"文件保存在: {output_dataset_path}")
        print(f"这个新数据集只包含你的模型预测为有漏洞的样本（TP + FP）")

if __name__ == "__main__":
    main()