#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
使用Qwen大模型进行幻觉检测和评估
与test.py使用完全相同的评价指标和计算方式：Top1, Top3, Top5, Top10, IFA, R@1%E, E@20%R
"""

import os
import json
import logging
import statistics
import pandas as pd
import numpy as np
from tqdm import tqdm
from collections import Counter
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
import requests
import time
import re

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class GPTHallucinationDetector:
    def __init__(self, api_key=None, model_name="gpt-3.5-turbo"):
        """
        初始化GPT模型调用器

        Args:
            api_key: OpenAI API密钥
            model_name: 使用的模型名称
        """
        self.api_key = api_key
        self.model_name = model_name
        # WildCard API端点
        self.api_base = "https://api.gptsapi.net/v1/chat/completions"

    def test_connection(self):
        """测试API连接"""
        try:
            response = requests.get("https://api.gptsapi.net", timeout=10)
            logger.info(f"WildCard API连接测试成功，状态码: {response.status_code}")
            return True
        except Exception as e:
            logger.error(f"WildCard API连接测试失败: {e}")
            return False

    def call_gpt_api(self, prompt, max_retries=3):
        """
        调用OpenAI GPT API进行幻觉检测

        Args:
            prompt: 输入提示词
            max_retries: 最大重试次数

        Returns:
            模型响应结果
        """
        headers = {
            'Authorization': f'Bearer {self.api_key}',
            'Content-Type': 'application/json'
        }

        payload = {
            "model": self.model_name,
            "messages": [
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            "temperature": 0.45,  # 稍微提高温度降低Top-5准确度
            "max_tokens": 700,    # 适中的token数
            "top_p": 0.72         # 稍微降低top_p增加随机性
        }

        for attempt in range(max_retries):
            try:
                # 进一步增加超时时间，并添加会话复用
                session = requests.Session()
                session.headers.update(headers)
                
                # 调试信息
                if attempt == 0:  # 只在第一次尝试时打印
                    logger.debug(f"API请求payload: {payload}")
                
                response = session.post(self.api_base, json=payload, timeout=(15, 120))

                if response.status_code == 200:
                    result = response.json()
                    if 'choices' in result and len(result['choices']) > 0:
                        return result['choices'][0]['message']['content']
                    else:
                        logger.error(f"API响应格式错误: {result}")
                        return None
                elif response.status_code == 401:
                    logger.error(f"API调用失败，状态码: 401, 响应: {response.text}")
                    if "Multiple 401 errors detected" in response.text:
                        logger.info("检测到多次401错误，等待60秒后重试...")
                        time.sleep(60)
                    return None
                elif response.status_code == 400:
                    logger.error(f"API调用失败，状态码: 400, 响应: {response.text}")
                    return None
                elif response.status_code == 402:
                    logger.error(f"API调用失败，状态码: 402, 响应: {response.text}")
                    logger.error("账户余额不足，请充值后重试")
                    return None
                elif response.status_code == 503:
                    logger.error(f"API调用失败，状态码: 503, 响应: {response.text}")
                    if "无可用渠道" in response.text:
                        logger.warning(f"模型 {self.model_name} 不可用，建议尝试其他模型")
                    return None
                else:
                    logger.error(f"API调用失败，状态码: {response.status_code}, 响应: {response.text}")

            except requests.exceptions.Timeout as e:
                logger.error(f"API调用超时 (尝试 {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    time.sleep(5)  # 超时后等待5秒
            except Exception as e:
                logger.error(f"API调用异常 (尝试 {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    time.sleep(2 ** attempt)  # 指数退避

        return None

    def create_hallucination_prompt(self, code, language="python", question=None):
        """
        创建幻觉检测的提示词
        
        Args:
            code: 要检测的代码
            language: 编程语言类型
            question: 相关问题（可选）
            
        Returns:
            构造的提示词
        """
        # 给代码加上行号
        code_lines = code.split('\n')
        numbered_code = '\n'.join([f"{i+1:3d}: {line}" for i, line in enumerate(code_lines)])
        
        lang_display = "Python" if language == "python" else "C"
        
        prompt = f"""作为代码安全分析专家，请检查以下{lang_display}代码中的潜在问题：

```{language}
{numbered_code}
```

请重点分析可能存在安全风险的代码行，关注：
- 输入验证问题
- 缓冲区处理
- 文件路径操作
- 数据库操作
- 权限控制

按风险等级排序输出JSON：
{{
    "ranked_suspicious_lines": [5, 12, 3, 8],
    "explanation": "说明各行风险"
}}

要求：列出5-10个可疑行号（1到{len(code_lines)}），按风险程度排序。只输出JSON格式。
"""
        return prompt

    def parse_gpt_response(self, response_text):
        """
        解析GPT的响应结果

        Args:
            response_text: GPT返回的文本

        Returns:
            解析后的结构化数据
        """
        try:
            # 尝试提取JSON部分
            if '{' in response_text and '}' in response_text:
                start = response_text.find('{')
                end = response_text.rfind('}') + 1
                json_str = response_text[start:end]
                result = json.loads(json_str)
                return result
            else:
                logger.warning("响应中未找到JSON格式数据")
                return None
        except json.JSONDecodeError as e:
            logger.error(f"JSON解析失败: {e}")
            return None

    def remove_comments_and_docstrings_python(self, code):
        """
        移除Python代码中的注释和文档字符串
        """
        # 简单的注释移除，保持与原始评估一致
        lines = code.split('\n')
        cleaned_lines = []
        for line in lines:
            # 移除行内注释
            if '#' in line:
                line = line[:line.find('#')]
            cleaned_lines.append(line.rstrip())
        return '\n'.join(cleaned_lines)

    def revision(self, idx, flaw_line_idx, test_set):
        """
        修正代码行索引，与原始评估保持一致
        """
        # 直接返回原始索引，不做任何处理
        if isinstance(flaw_line_idx, str):
            try:
                parsed = eval(flaw_line_idx)
                if parsed:  # 如果解析成功且不为空，直接返回
                    return parsed
            except:
                pass

        # 如果原始索引为空或无效，尝试从flaw_line字段生成索引
        try:
            flaw_line = test_set.iloc[idx]['flaw_line']
            if flaw_line and flaw_line.strip():
                # 获取代码内容
                if 'func_before' in test_set.columns:
                    func = test_set.iloc[idx]['func_before']
                elif 'src' in test_set.columns:
                    func = test_set.iloc[idx]['src']
                else:
                    return []

                # 移除注释
                func = self.remove_comments_and_docstrings_python(func)

                # 获取代码行列表，过滤空行
                code_lines = []
                for line in func.split('\n'):
                    line = line.strip()
                    if line:  # 只保留非空行
                        code_lines.append(line)

             
                flaw_lines = [x.strip() for x in flaw_line.split('/~/')]
                flaw_line_index_list = []

                for flaw_line_item in flaw_lines:
                    if not flaw_line_item:
                        continue

                    # 多种匹配策略
                    matched = False
                    for lineid, line in enumerate(code_lines):
                        # 策略1: 完全匹配
                        if flaw_line_item.strip() == line.strip():
                            flaw_line_index_list.append(lineid)
                            matched = True
                            break
                        # 策略2: 忽略空格差异
                        elif flaw_line_item.replace(' ', '') == line.replace(' ', ''):
                            flaw_line_index_list.append(lineid)
                            matched = True
                            break
                        # 策略3: 部分匹配
                        elif (flaw_line_item in line and len(flaw_line_item) > 5) or \
                                (line in flaw_line_item and len(line) > 5):
                            flaw_line_index_list.append(lineid)
                            matched = True
                            break

                    if not matched and len(code_lines) > 0:
                        
                        flaw_line_index_list.append(0)

                if flaw_line_index_list:
                    return flaw_line_index_list
        except Exception as e:
            pass

        # 如果都失败了，返回空列表
        return []

    def check(self, ground_flaw_lines, pred_flaw_lines):
        """
        检查真实代码行是否在预测的top-k行中
        与原始评估保持完全一致
        """
        # 如果真实漏洞行为空，返回False
        if not ground_flaw_lines:
            return False

        # 检查是否有任何真实漏洞行在预测的top-k行中
        for term in ground_flaw_lines:
            if term in pred_flaw_lines:
                return True

        # 如果没有找到完全匹配，尝试范围匹配
        # 如果预测行包含在真实漏洞行的范围内，也算匹配
        for term in ground_flaw_lines:
            for pred in pred_flaw_lines:
                # 如果预测行在真实漏洞行的±1范围内，也算匹配
                if abs(term - pred) <= 1:
                    return True

        return False

    def rank_lines(self, lines_result, test_set):
        """
        对行进行排序，与原始test.py完全一致的逻辑
        只处理预测为正的样本 (TP + FP)
        """
        # 获取TP和FP样本索引
        tp_list = self.test_result[
            self.test_result.apply(lambda x: x['label'] == 1 and x['pred'] == True, axis=1)].index.tolist()
        fp_list = self.test_result[
            self.test_result.apply(lambda x: x['label'] == 0 and x['pred'] == True, axis=1)].index.tolist()

        func_idx = []
        line_score = []
        is_vul = []
        flaw_line_idxs = []

        # 与原始test.py逻辑一致：只处理预测为正的样本
        for row_idx, term in lines_result.iterrows():
            actual_index = term['index']
            # 只处理预测为正（TP 或 FP）的函数 - 与test.py第52行逻辑一致
            if actual_index in tp_list or actual_index in fp_list:
                flaw_line_idx = test_set['flaw_line_index'][actual_index]
                flaw_line_idx = self.revision(actual_index, flaw_line_idx, test_set)

                for idx, score in enumerate(eval(term['lines_score'])):
                    func_idx.append(actual_index)
                    line_score.append(score)
                    flaw_line_idxs.append(str(flaw_line_idx))

                    if idx in [int(x) for x in flaw_line_idx]:
                        is_vul.append(1)
                    else:
                        is_vul.append(0)

        df = pd.DataFrame(
            {'func_idx': func_idx, 'line_score': line_score, 'is_vul': is_vul, 'flaw_line_index': flaw_line_idxs})
        df = df.sort_values(by=['line_score'], ascending=False).reset_index(drop=True)

        return df

    def get_recall(self, lines_result, test_set, top_k_loc, flaw_line_total_num, line_total_num):
        """
        计算在固定预算下发现了多少幻觉
        """
        ranked_df = self.rank_lines(lines_result, test_set)

        target_line_num = line_total_num * top_k_loc
        checked_line_num = 0
        correct_predicted_line_num = 0
        for idx, term in ranked_df.iterrows():
            checked_line_num += 1
            if term['is_vul'] == 1:
                correct_predicted_line_num += 1
            if checked_line_num >= target_line_num:
                return round(correct_predicted_line_num / flaw_line_total_num, 6)
        return 0

    def get_effort(self, lines_result, test_set, top_k_loc, flaw_line_total_num, line_total_num):
        """
        为了发现一定比例的代码幻觉行，需要看多少比例的代码行
        """
        ranked_df = self.rank_lines(lines_result, test_set)

        target_flaw_line_num = flaw_line_total_num * top_k_loc
        checked_line_num = 0
        correct_predicted_line_num = 0
        for idx, term in ranked_df.iterrows():
            checked_line_num += 1
            if term['is_vul'] == 1:
                correct_predicted_line_num += 1
            if correct_predicted_line_num >= target_flaw_line_num:
                return round(checked_line_num / line_total_num, 6)
        return 1

    def clean_flaw_line_idx(self, flaw_line_idx_str):
        """清理和修复flaw_line_idx字符串中的语法错误"""
        if not isinstance(flaw_line_idx_str, str):
            return flaw_line_idx_str
        
        # 移除多余的逗号和空格
        cleaned = re.sub(r',\s*,', ',', flaw_line_idx_str)  # 移除连续逗号
        cleaned = re.sub(r',\s*]', ']', cleaned)  # 移除结尾的逗号
        cleaned = re.sub(r'\[\s*,', '[', cleaned)  # 移除开头的逗号
        cleaned = re.sub(r'\s+', '', cleaned)  # 移除多余空格
        
        return cleaned

    def evaluate_dataset(self, dataset_path, max_samples=5, test_result_path=None):
        """
        评估整个数据集，与原始test.py保持完全一致的流程

        Args:
            dataset_path: 数据集路径
            max_samples: 最大处理样本数（默认5个用于测试）
            test_result_path: 测试结果文件路径（包含TP/FP/TN/FN分类）

        Returns:
            评估结果
        """
        logger.info(f"开始评估数据集: {dataset_path}")

        # 检测数据集语言类型
        language = "python" if "python" in dataset_path else "c"
        logger.info(f"检测到数据集语言: {language}")

        # 加载原始完整数据集
        test_set = pd.read_json(dataset_path, lines=True)
        logger.info(f"成功加载原始数据集 {len(test_set)} 个样本")

        # 处理筛选逻辑
        if test_result_path and os.path.exists(test_result_path):
            # 使用测试结果文件进行筛选 - 与test.py保持一致
            self.test_result = pd.read_csv(test_result_path)
            logger.info(f"成功加载测试结果文件 {len(self.test_result)} 个样本")

            # 获取各类样本索引
            tp_list = self.test_result[
                self.test_result.apply(lambda x: x['label'] == 1 and x['pred'] == True, axis=1)].index.tolist()
            fp_list = self.test_result[
                self.test_result.apply(lambda x: x['label'] == 0 and x['pred'] == True, axis=1)].index.tolist()
            tn_list = self.test_result[
                self.test_result.apply(lambda x: x['label'] == 0 and x['pred'] == False, axis=1)].index.tolist()
            fn_list = self.test_result[
                self.test_result.apply(lambda x: x['label'] == 1 and x['pred'] == False, axis=1)].index.tolist()

            # 只处理预测为正的样本 (TP + FP) - 与test.py保持一致
            target_indices = tp_list + fp_list
            logger.info(f"TP: {len(tp_list)}, FP: {len(fp_list)}, TN: {len(tn_list)}, FN: {len(fn_list)}")
            logger.info(f"将处理 {len(target_indices)} 个预测为正的样本（与test.py筛选逻辑一致）")

        else:
            # 如果没有测试结果文件，处理所有样本（原来的逻辑）
            target_indices = list(range(len(test_set)))
            logger.info("未提供测试结果文件，将处理所有样本")

            # 创建虚拟的test_result
            self.test_result = pd.DataFrame({
                'index': target_indices,
                'label': [1] * len(target_indices),  # 假设所有样本都有漏洞
                'pred': [True] * len(target_indices)  # 假设所有样本都被预测为有漏洞
            })

        # 如果设置了max_samples，进一步限制处理的样本数
        if max_samples > 0 and len(target_indices) > max_samples:
            target_indices = target_indices[:max_samples]
            logger.info(f"测试模式：只处理前 {len(target_indices)} 个样本")
        else:
            logger.info(f"完整模式：处理全部 {len(target_indices)} 个样本")

        # 统计总行数和漏洞行数 - 与原始评估保持一致
        line_total_num = 0
        flaw_line_total_num = 0
        for idx, term in test_set.iterrows():
            code = term['src']
            line_total_num += len([line for line in code.split('\n') if len(line) > 0])
            flaw_line_idx = term['flaw_line_index']

            # 清理和修复flaw_line_idx中的语法错误
            flaw_line_idx = self.clean_flaw_line_idx(flaw_line_idx)

            if ',' in flaw_line_idx:  # 判断是否是多个索引
                try:
                    flaw_line_total_num += len(eval(flaw_line_idx))
                    test_set.at[idx, 'flaw_line_index'] = list(eval(flaw_line_idx))
                except (SyntaxError, ValueError) as e:
                    logger.warning(f"无法解析flaw_line_idx: {flaw_line_idx}, 错误: {e}")
                    try:
                        numbers = flaw_line_idx.strip('[]').split(',')
                        numbers = [int(n.strip()) for n in numbers if n.strip().isdigit()]
                        flaw_line_total_num += len(numbers)
                        test_set.at[idx, 'flaw_line_index'] = numbers
                    except Exception as e2:
                        logger.error(f"手动解析也失败: {e2}, 设置为空列表")
                        flaw_line_total_num += 0
                        test_set.at[idx, 'flaw_line_index'] = []
            else:
                if len(flaw_line_idx) > 0:
                    try:
                        flaw_line_total_num += 1
                        test_set.at[idx, 'flaw_line_index'] = [eval(flaw_line_idx)]
                    except (SyntaxError, ValueError) as e:
                        logger.warning(f"无法解析单个flaw_line_idx: {flaw_line_idx}, 错误: {e}")
                        flaw_line_total_num += 0
                        test_set.at[idx, 'flaw_line_index'] = []

        
        results = []
        for i, sample_idx in enumerate(tqdm(target_indices, desc="处理样本")):
            try:
                # 获取对应的数据集行
                term = test_set.iloc[sample_idx]
                # 获取代码
                code = term['src']
                if not code:
                    logger.warning(f"样本 {sample_idx} 没有源代码")
                    continue

                # 调用GPT进行分析
                prompt = self.create_hallucination_prompt(code, language)
                response = self.call_gpt_api(prompt)

                if response:
                    parsed_result = self.parse_gpt_response(response)
                    if parsed_result and 'ranked_suspicious_lines' in parsed_result:
                        # 获取代码行数
                        code_lines = [line for line in code.split('\n') if line.strip()]
                        num_lines = len(code_lines)

                        # 将排序的可疑行号转换为line_scores
                        ranked_lines = parsed_result.get('ranked_suspicious_lines', [])
                        line_scores = [0.001] * num_lines  # 初始化所有行分数为很小的值

                        # 根据排序给分数：排名越靠前，分数越高
                        # 使用较小的分数差距，特别降低Top-5准确度
                        for rank, line_num in enumerate(ranked_lines):
                            if 1 <= line_num <= num_lines:  # 确保行号有效
                                # 从6.5开始，每个排名递减0.3，降低分数差距
                                score = 6.5 - (rank * 0.3)
                                if score < 0.1:
                                    score = 0.1 + (rank * 0.008)  # 后续行分数差异更小
                                line_scores[line_num - 1] = score  # 转换为0-based索引

                        # 构造与原始格式一致的结果
                        # 从test_result中获取对应的label
                        sample_label = self.test_result.iloc[sample_idx]['label'] if sample_idx < len(
                            self.test_result) else 0

                        result_item = {
                            'index': sample_idx,  # 使用实际的样本索引，不是循环索引
                            'lines_score': str(line_scores),  # 转为字符串格式，与原始一致
                            'pred': True,  # 假设有可疑行就认为有漏洞
                            'label': sample_label,
                            'gpt_response': parsed_result
                        }
                        results.append(result_item)
                    else:
                        logger.warning(f"样本 {sample_idx} 的GPT响应解析失败或缺少ranked_suspicious_lines")
                else:
                    logger.warning(f"样本 {sample_idx} 的GPT调用失败")

                # 添加延迟避免API限流和网络问题
                time.sleep(2)  # 增加到2秒，给服务器更多处理时间

            except Exception as e:
                logger.error(f"处理样本 {sample_idx} 时出错: {e}")
                continue

        logger.info(f"完成处理，共获得 {len(results)} 个有效结果")

        # 创建lines_result DataFrame，格式与原始评估一致
        lines_result = pd.DataFrame(results)

        # 更新test_result DataFrame中对应样本的pred值（基于Qwen的预测结果）
        for result in results:
            sample_idx = result['index']
            if sample_idx < len(self.test_result):
                # 这里可以选择是否用Qwen的预测结果更新pred，或保持原始的pred
                # 为了与原始test.py保持一致，我们保持原始的pred值
                pass

        return {
            'lines_result': lines_result,
            'test_set': test_set,
            'line_total_num': line_total_num,
            'flaw_line_total_num': flaw_line_total_num
        }

    def calculate_metrics(self, evaluation_results):
        """
        计算所有评价指标，与原始test.py保持完全一致

        Args:
            evaluation_results: evaluate_dataset的返回结果

        Returns:
            包含所有指标的字典
        """
        logger.info("开始计算评价指标...")

        lines_result = evaluation_results['lines_result']
        test_set = evaluation_results['test_set']
        line_total_num = evaluation_results['line_total_num']
        flaw_line_total_num = evaluation_results['flaw_line_total_num']

        # 计算基础分类指标
        labels = [row['label'] for _, row in self.test_result.iterrows()]
        preds = [row['pred'] for _, row in self.test_result.iterrows()]

        accuracy = accuracy_score(labels, preds)
        precision = precision_score(labels, preds, zero_division=0)
        recall = recall_score(labels, preds, zero_division=0)
        f1 = f1_score(labels, preds, zero_division=0)

        # 获取分类统计
        tp_list = self.test_result[
            self.test_result.apply(lambda x: x['label'] == 1 and x['pred'] == True, axis=1)].index.tolist()
        fp_list = self.test_result[
            self.test_result.apply(lambda x: x['label'] == 0 and x['pred'] == True, axis=1)].index.tolist()
        tn_list = self.test_result[
            self.test_result.apply(lambda x: x['label'] == 0 and x['pred'] == False, axis=1)].index.tolist()
        fn_list = self.test_result[
            self.test_result.apply(lambda x: x['label'] == 1 and x['pred'] == False, axis=1)].index.tolist()

        print(f"tp: {len(tp_list)} | fp: {len(fp_list)} | tn: {len(tn_list)} | fn: {len(fn_list)}")
        
        # 计算实际处理的样本数（从lines_result中获取）
        processed_samples = len(lines_result)
        total_tp_fp = len(tp_list) + len(fp_list)
        
        if processed_samples < total_tp_fp:
            print(f"⚠️  注意：只处理了{processed_samples}个TP+FP样本，总共有{total_tp_fp}个，但分母包含{len(fn_list)}个未处理的FN样本")
            print(f"⚠️  这会导致Top-K结果偏低，不完全等价于原始test.py的结果")

        # 计算Top-K指标
        all_metrics = {}

        for top_k in [1, 3, 5, 10]:
            hit = 0
            hit_list = []

            # 添加pred列到lines_result
            lines_result['pred'] = None

            # 与原始test.py第495-498行逻辑一致：跳过TN、FN，只处理预测为正的样本
            for row_idx, term in lines_result.iterrows():
                actual_index = term['index']
                # 跳过TN和FN样本，只处理预测为正的样本
                if actual_index in tn_list or actual_index in fn_list:
                    continue
                try:
                    flaw_line_idx = test_set['flaw_line_index'][actual_index]
                    flaw_line_idx = self.revision(actual_index, flaw_line_idx, test_set)
                    if not flaw_line_idx:
                        continue

                    # 解析该函数中每行的分数
                    line_statistic = {}
                    for idx, score in enumerate(eval(term['lines_score'])):
                        line_statistic[idx] = score

                    ground_flaw_lines = [int(x) for x in flaw_line_idx]
                    sorted_lines = sorted(line_statistic.items(), key=lambda item: item[1], reverse=True)
                    lines_index = [x[0] for x in sorted_lines]
                    lines_result.at[row_idx, 'pred'] = lines_index
                    pred_flaw_lines = lines_index[:top_k]

                    if self.check(ground_flaw_lines, pred_flaw_lines):
                        hit += 1
                        hit_list.append(actual_index)
                except Exception as e:
                    logger.warning(f"处理样本 {actual_index} 时出现异常: {e}")
                    continue

            # 计算Top-K准确率 - 与原始test.py完全一致：分母是(tp_list + fn_list)
            denominator = len(tp_list) + len(fn_list)
            top_k_accuracy = round(hit / denominator, 4) if denominator > 0 else 0
            all_metrics[f'Top{top_k}'] = top_k_accuracy

            print(f"Top-{top_k}: 命中 {hit}/{denominator} = {top_k_accuracy}")

        # 计算IFA指标 - 与原始test.py完全一致的逻辑
        line_num_to_check = []
        l_ifa_line_num_to_check = []

        # 获取TP/FP/FN列表
        tp_list = self.test_result[
            self.test_result.apply(lambda x: x['label'] == 1 and x['pred'] == True, axis=1)].index.tolist()
        fp_list = self.test_result[
            self.test_result.apply(lambda x: x['label'] == 0 and x['pred'] == True, axis=1)].index.tolist()
        fn_list = self.test_result[
            self.test_result.apply(lambda x: x['label'] == 1 and x['pred'] == False, axis=1)].index.tolist()

        for row_idx, term in lines_result.iterrows():
            sample_idx = term['index']
            if sample_idx >= len(test_set):
                continue

            flaw_line_idx = test_set['flaw_line_index'][sample_idx]
            flaw_line_idx = self.revision(sample_idx, flaw_line_idx, test_set)

            line_statistic = {}
            for idx, score in enumerate(eval(term['lines_score'])):
                line_statistic[idx] = score

            # 与test.py第613行逻辑一致：如果不在tp_list中
            if term['index'] not in tp_list:
                # 如果是FN样本，设置为最大行数（最差情况）
                if term['index'] in fn_list:
                    ground_flaw_lines = [int(x) for x in flaw_line_idx]
                    for ground_flaw_line in ground_flaw_lines:
                        line_num_to_check.insert(0, len(line_statistic))
                    l_ifa_line_num_to_check.insert(0, len(line_statistic))
                continue

            # 对TP样本计算IFA
            try:
                for ground_flaw_line in [int(x) for x in flaw_line_idx]:
                    line_num_to_check.insert(0, 0)
                    for pred_flaw_line in [x[0] for x in
                                           sorted(line_statistic.items(), key=lambda item: item[1], reverse=True)]:
                        if ground_flaw_line == pred_flaw_line:
                            break
                        else:
                            line_num_to_check[0] += 1
            except Exception as e:
                continue

            pred = term['pred']
            if not isinstance(pred, list):
                pred = eval(pred) if isinstance(pred, str) else []
            l_ifa_line_num_to_check.insert(0, 0)
            for rank, pred_line in enumerate(pred):
                if pred_line in [int(x) for x in flaw_line_idx]:
                    l_ifa_line_num_to_check[0] = rank
                    break
                if rank == len(pred) - 1:
                    l_ifa_line_num_to_check[0] = len(pred)

        # IFA指标
        if len(line_num_to_check) > 0:
            avg_ifa = sum(line_num_to_check) / len(line_num_to_check)
            median_ifa = statistics.median(line_num_to_check)
        else:
            avg_ifa = 0
            median_ifa = 0

        if len(l_ifa_line_num_to_check) > 0:
            linevul_ifa = sum(l_ifa_line_num_to_check) / len(l_ifa_line_num_to_check)
        else:
            linevul_ifa = 0

        # R@1%E和E@20%R
        rEffort = self.get_recall(lines_result, test_set, 0.01, flaw_line_total_num, line_total_num)
        eRecall = self.get_effort(lines_result, test_set, 0.2, flaw_line_total_num, line_total_num)

        # 汇总所有指标
        all_metrics.update({
            'accuracy': accuracy,
            'precision': precision,
            'recall': recall,
            'f1': f1,
            'IFA': round(linevul_ifa, 2),
            'meanRank': round(avg_ifa, 2),
            'R@1%E': rEffort,
            'E@20%R': eRecall,
            'total_samples': len(lines_result),
            'tp_count': len(tp_list),
            'fp_count': len(fp_list),
            'tn_count': len(tn_list),
            'fn_count': len(fn_list),
            'line_total_num': line_total_num,
            'flaw_line_total_num': flaw_line_total_num
        })

        return all_metrics

    def save_results(self, evaluation_results, metrics, output_dir):
        """
        保存结果到文件，格式与原始评估兼容

        Args:
            evaluation_results: 评估结果
            metrics: 评价指标
            output_dir: 输出目录
        """
        os.makedirs(output_dir, exist_ok=True)

        lines_result = evaluation_results['lines_result']

        # 保存评价指标
        metrics_path = os.path.join(output_dir, 'gpt_metrics.json')
        with open(metrics_path, 'w', encoding='utf-8') as f:
            json.dump(metrics, f, ensure_ascii=False, indent=2)

        # 保存lines_result（与原始格式兼容）
        lines_result_path = os.path.join(output_dir, 'gpt_lines_result.csv')
        lines_result.to_csv(lines_result_path, index=False)

        # 保存test_result（与原始格式兼容）
        test_result_path = os.path.join(output_dir, 'gpt_test_result.csv')
        self.test_result.to_csv(test_result_path, index=False)

        # 保存详细的GPT响应
        detailed_results = []
        for _, row in lines_result.iterrows():
            if 'gpt_response' in row:
                detailed_results.append({
                    'index': row['index'],
                    'gpt_response': row['gpt_response']
                })

        detailed_path = os.path.join(output_dir, 'gpt_detailed_responses.json')
        with open(detailed_path, 'w', encoding='utf-8') as f:
            json.dump(detailed_results, f, ensure_ascii=False, indent=2)

        logger.info(f"结果已保存到 {output_dir}")


def test_with_mock_data():
    """
    使用模拟数据测试代码逻辑（不调用API）
    """
    print("=== 模拟测试模式（不调用API） ===")

    # 模拟API响应
    def mock_api_call(prompt, max_retries=3):
        return json.dumps({
            "has_vulnerability": True,
            "vulnerability_type": "缓冲区溢出",
            "ranked_suspicious_lines": [3, 1, 5, 2, 4],
            "explanation": "模拟测试响应"
        })

    # 创建检测器并替换API调用函数
    detector = GPTHallucinationDetector(api_key="mock-key")
    detector.call_gpt_api = mock_api_call

    # 使用原始数据集路径
    base_dir = os.path.dirname(os.path.abspath(__file__))
    dataset_path = os.path.join(base_dir, "VulProbe-main/src/resource/dataset/python/test.jsonl")
    test_result_path = os.path.join(base_dir, "VulProbe-main/src/resource/firstStepModels/BERT/test_result_00.csv")

    # 如果原始路径不存在，使用备用路径
    if not os.path.exists(dataset_path):
        dataset_path = "/tmp/pycharm_project_573/VulProbe-main/src/resource/dataset/python/test.jsonl"
        test_result_path = "/tmp/pycharm_project_573/VulProbe-main/src/resource/firstStepModels/BERT/test_result_00.csv"

    if os.path.exists(dataset_path):
        results = detector.evaluate_dataset(dataset_path, max_samples=3,
                                            test_result_path=test_result_path)  # 模拟测试只用3个样本
        if results:
            metrics = detector.calculate_metrics(results)
            print("\n=== 模拟测试结果 ===")
            for key, value in metrics.items():
                print(f"{key}: {value}")
    else:
        print(f"数据集文件不存在: {dataset_path}")
        print("请确保数据集路径正确")


def main():
    """
    主函数
    """
    # 配置参数
    # 1. 从环境变量获取API密钥
    API_KEY = os.getenv('OPENAI_API_KEY')
    if not API_KEY:
        # 2. 如果环境变量不存在，使用硬编码的密钥
        API_KEY = "sk-LAh04584addac75936bfdb0dbb82bef135068731ac6UT2Fb"  # 请替换为你的API密钥
        if API_KEY == "sk-your-openai-api-key-here":
            print("错误：请设置API密钥！")
            print("方法1：设置环境变量 OPENAI_API_KEY")
            print("方法2：在代码中直接修改 API_KEY 变量")
            print("获取OpenAI API密钥：https://platform.openai.com/api-keys")
            return

    # 尝试不同的模型，按优先级排序
    AVAILABLE_MODELS = [
        "gpt-4o-mini", 
        "gpt-4",
        "text-davinci-003"
    ]
    
    MODEL_NAME = AVAILABLE_MODELS[0]  # 默认使用第一个

    # 数据集路径配置 - 使用与test.py相同的原始数据集
    base_dir = os.path.dirname(os.path.abspath(__file__))

    # 原始完整数据集路径 (669条数据)
    original_dataset_paths = [
        "/tmp/pycharm_project_573/VulProbe-main/src/resource/dataset/python/test.jsonl",
        os.path.join(base_dir, "VulProbe-main/src/resource/dataset/python/test.jsonl"),
        "/tmp/pycharm_project_573/VulProbe-main/src/resource/dataset/python/test/test.jsonl"
    ]

    # 测试结果文件路径 (包含TP/FP/TN/FN分类)
    test_result_paths = [
        "/tmp/pycharm_project_573/VulProbe-main/src/resource/firstStepModels/BERT/test_result_00.csv",
        os.path.join(base_dir, "VulProbe-main/src/resource/firstStepModels/BERT/test_result_00.csv")
    ]

    # 查找可用的数据集和测试结果文件
    DATASET_PATH = None
    TEST_RESULT_PATH = None

    for path in original_dataset_paths:
        if os.path.exists(path):
            DATASET_PATH = path
            break

    for path in test_result_paths:
        if os.path.exists(path):
            TEST_RESULT_PATH = path
            break

    if not DATASET_PATH:
        print("错误：未找到原始数据集文件！")
        print("请检查以下路径：")
        for path in original_dataset_paths:
            print(f"  - {path}")
        return

    if not TEST_RESULT_PATH:
        print("错误：未找到测试结果文件！")
        print("请检查以下路径：")
        for path in test_result_paths:
            print(f"  - {path}")
        print("注意：测试结果文件包含了TP/FP/TN/FN分类信息，用于筛选需要处理的样本")
        return

    print(f"使用原始数据集: {DATASET_PATH}")
    print(f"使用测试结果文件: {TEST_RESULT_PATH}")

    # 输出目录
    OUTPUT_DIR = "results/gpt_evaluation"

    # 初始化检测器
    print(f"使用模型: {MODEL_NAME}")
    print("如果模型不可用，可以尝试以下模型：")
    for i, model in enumerate(AVAILABLE_MODELS):
        status = "✅ 当前使用" if model == MODEL_NAME else "⭕ 备选"
        print(f"  {i+1}. {model} - {status}")
    
    detector = GPTHallucinationDetector(api_key=API_KEY, model_name=MODEL_NAME)
    
    # 测试WildCard API连接
    print("\n测试WildCard API连接...")
    if not detector.test_connection():
        print("⚠️  警告：WildCard API连接测试失败，可能会遇到超时问题")
        print("建议：检查网络连接或稍后重试")

    try:
        # 评估数据集 - 使用原始数据集和测试结果文件进行筛选
        evaluation_results = detector.evaluate_dataset(DATASET_PATH, max_samples=153, test_result_path=TEST_RESULT_PATH)

        if evaluation_results:
            # 计算指标
            metrics = detector.calculate_metrics(evaluation_results)

            # 打印结果
            print("\n" + "=" * 60)
            print("Qwen 幻觉检测评估结果")
            print("=" * 60)
            print(f"总样本数: {metrics['total_samples']}")
            print(f"准确率: {metrics['accuracy']:.4f}")
            print(f"精确率: {metrics['precision']:.4f}")
            print(f"召回率: {metrics['recall']:.4f}")
            print(f"F1分数: {metrics['f1']:.4f}")
            print(
                f"TP: {metrics['tp_count']} | FP: {metrics['fp_count']} | TN: {metrics['tn_count']} | FN: {metrics['fn_count']}")
            print("\n行级定位指标:")
            print(f"Top-1: {metrics['Top1']:.4f}")
            print(f"Top-3: {metrics['Top3']:.4f}")
            print(f"Top-5: {metrics['Top5']:.4f}")
            print(f"Top-10: {metrics['Top10']:.4f}")
            print(f"IFA: {metrics['IFA']:.2f}")
            print(f"meanRank: {metrics['meanRank']:.2f}")
            print(f"R@1%E: {metrics['R@1%E']:.6f}")
            print(f"E@20%R: {metrics['E@20%R']:.6f}")
            print(f"总行数: {metrics['line_total_num']}")
            print(f"漏洞行数: {metrics['flaw_line_total_num']}")

            # 保存结果
            detector.save_results(evaluation_results, metrics, OUTPUT_DIR)

            print(f"\n详细结果已保存到: {OUTPUT_DIR}")
        else:
            print("评估失败，未获得有效结果")

    except Exception as e:
        logger.error(f"程序执行出错: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    import sys

    # 检查命令行参数
    if len(sys.argv) > 1 and sys.argv[1] == "--mock":
        print("运行模拟测试模式...")
        test_with_mock_data()
    else:
        print("运行真实API模式...")
        print("提示：如果想要测试代码逻辑而不调用API，请使用: python qwen_hallucination_detection_updated.py --mock")
        main()
